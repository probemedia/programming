# -*- coding: utf-8 -*-

'''Basic Grammar - ch02.py'''
'''2. 파이썬 개요'''
'''(2) 파이썬 스크립트 작성과 구성순서'''
'''1) 파이썬 스크립트 작성 및 실행 '''
# %%
# 2-(2)-1)-1

print("Hello World")
# %%
'''2) 스크립트 구성순서 및 코드 작성규칙'''
# 2-(2)-2)-1
# -*- coding: utf-8 -*-
"""
x + y + math.pow(x, y) 계산
"""

import math


def my_fun(x, y):  # my_fun()함수 정의
    return x + y + math.pow(x, y)


if __name__ == '__main__':
    x, y = 5.0, 3.0
    print("my_fun(x, y) = %d" % my_fun(x, y))

# %%
# 2-(2)-2)-2
# 모듈로 사용
from script_config import my_fun

print("모듈로 사용 : my_fun(x, y) = %d" % my_fun(5.0, 3.0))
