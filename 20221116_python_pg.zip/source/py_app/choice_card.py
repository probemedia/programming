# -*- coding: utf-8 -*-
# %%
from random import choice


def choice_face():
    card_face = ["hearts", "diamonds", "clubs", "spades"]
    return choice(card_face)


def chice_num():
    card_num = ["jack", "queen", "king"]
    return choice(card_num)
