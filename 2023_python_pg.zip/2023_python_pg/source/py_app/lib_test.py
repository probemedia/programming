# -*- coding: utf-8 -*-

# 8-(6)-2)-1
# 사용자 정의 모듈


def my_val():
    return 10


def my_mul(a, b):
    return a * b
