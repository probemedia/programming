# -*- coding: utf-8 -*-
# %%
'''Basic Grammar - ch09.py'''
'''9. 클래스'''
'''(2) 클래스 정의 및 객체 생성'''
# %%
'''1) 클래스 정의'''
# 9-(2)-1)-1


class MemberInfo(object):
    def __init__(self, idx, passd, name):
        self.idx = idx
        self.passd = passd
        self.name = name

    def getMember(self):
        return self.idx + ', ' + self.passd + ', ' + self.name


# %%
'''문제해결 9-1-1)'''
# 9-(2)-1)-2


class Car(object):  # 순서1
    def __init__(self, displ, drv):  # 순서2
        self.displ = displ
        self.drv = drv

    def info(self):  # 순서3
        print("자동차 정보 : ({0}, {1}구동)".format(self.displ, self.drv))


# %%
'''문제해결 9-1-2)'''
# 9-(2)-1)-3


class IdInfo(object):  # 순서1
    def __init__(self, idx, passd):  # 순서2
        self.idx = idx
        self.passd = passd

    def getIdInfo(self):  # 순서3
        return dict(idx=self.idx, passd=self.passd)


# %%
'''2) 객체생성'''
# 9-(2)-2)-1

# 순서1
my_member = MemberInfo("kingdora", "123456", "김대붕")

# 순서2
print("사용자 정보:", my_member.getMember())
print("사용자 아이디:", my_member.idx)
# %%
'''문제해결 9-2-1)'''
# 9-(2)-2)-2

# 순서1
car_obj = Car(3000, "4륜")

# 순서2
car_obj.info()
# %%
'''문제해결 9-2-2)'''
# 9-(2)-2)-3

# 순서1
idinfo_obj = IdInfo("winterbear", "19951230")

# 순서2
print(idinfo_obj.getIdInfo())
# %%
'''3) 객체 제거'''
# 9-(2)-3)-1


def is_exist_obj(obj):
    if obj:
        print("객체 있음")
    else:
        print("객체 없음. 생성 필요")


is_exist_obj(my_member)

# del my_member  # 객체 자체 제거
my_member = ""
is_exist_obj(my_member)
# %%
'''(3) 정보은닉'''
# 9-(3)-1


class IHCar(object):
    def __init__(self, displ, drv):
        self.__displ = displ
        self.__drv = drv

    def move(self, speed):
        print("자동차 이동 속도 : 시속 {0}km".format(speed))

    def info(self):
        print("자동차 정보 : ({0}, {1}구동)".format(self.__displ, self.__drv))


car1 = IHCar(3000, "4륜")
car1.info()
car1.move(60)
print(car1.__displ)  # 에러 발생. 정보은닉된 프로퍼티에 접근
