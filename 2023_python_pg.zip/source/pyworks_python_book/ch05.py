# -*- coding: utf-8 -*-
# %%
'''Basic Grammar - ch05.py'''
''' 5. 기본 데이터 타입과 포맷팅 – 값의 타입별 처리방식과 화면 표시방법'''
'''(2) 숫자타입 - 정수, 부동소수점, 복소수'''
# %%
'''1) 정수(고정소수점) : int'''
# 5-(2)-1)-1
user_age = 30
user_age
# %%
'''문제해결 5-2-1)'''
# 5-(2)-1)-2

# 순서1
int_var1 = 10
int_var2 = 0

# 순서2
print(int_var1, int_var2)
# %%
'''문제해결 5-2-2)'''
# 5-(2)-1)-3

# 순서1
rec_width = 7
rec_height = 8

# 순서2
print("사각형의 둘레 :", 2 * (rec_width + rec_height))
print("사각형의 넓이 :", rec_width * rec_height)
# %%
'''2) 실수(부동소수점) : float'''
# 5-(2)-2)-1
pi = 3.14
pi
# %%
'''문제해결 5-2-3)'''
# 5-(2)-2)-2

# 순서1
r = 5
pi = 3.14

# 순서2
print("원의 둘레 : ", 2 * pi * r)
print("원의 넓이 : ", r * r * pi)
# %%
'''3) 복소수타입 : complex'''
# 5-(2)-3)-1
cmp_var = 3 + 2j
cmp_var
# %%
'''4) 숫자타입 처리 함수'''
# 5-(2)-4)-1
import math
print(math.pi)
# %%
# 5-(2)-4)-2
print(max(10, 90, 55))
print(min(10, 90, 55))
# %%
# 5-(2)-4)-3
print(pow(2, 4))
# %%
# 5-(2)-4)-4
print(abs(-1230))
# %%
# 5-(2)-4)-5
import math
print(math.ceil(44.1))
print(math.floor(44.9))
# %%
# 5-(2)-4)-6
import math
print(math.sqrt(16))
# %%
'''(3) 문자열 타입'''
'''1) 문자열 타입 : str'''
# 5-(3)-1)-1
user_id = "abcd"
user_id
# %%
# 5-(3)-1)-2
user_id = "abcd"
user_pass = "A12#"
user_name = '킹도라'
print(user_id, user_pass, user_name)
# %%
'''문제해결 5-3-1)'''
# 5-(3)-1)-3

# 순서1
addr_sido = input("시도명 입력: ")
addr_gu = input("구명 입력: ")
addr_dong = input("동명 입력: ")

# 순서2
print("시도명 : " + addr_sido, ", 구명 : " + addr_gu, ", 동명 : " + addr_dong)
# %%
# 5-(3)-1)-4
kh_str = """En taro Adun! : For Adun's name!
En taro Tassadar! : For Tassadar's name!
En var! : For honor!"""
kh_str
# %%
# 5-(3)-1)-5
kh_str = """En taro Adun! : For Adun's name!
En taro Tassadar! : For Tassadar's name!
En var! : For honor!"""
print(kh_str)
# %%
'''2) 문자열 결합 : +'''
# 5-(3)-2)-1
"김" + "왕쌍"
# %%
# 5-(3)-2)-2
name = "김왕쌍"
jum = 100
print("이름 : " + name)
print("점수 : " + str(jum) + "점")
# %%
'''문제해결 5-3-2)'''
# 5-(3)-2)-3

# 순서1
wp_date = input("관측일 입력: ")
wp_place = input("관측지점 입력: ")
wp_bod = float(input("BOD 값 입력: "))
wp_cod = float(input("COD 값 입력: "))

# 순서2
print(wp_date + "," + wp_place + "," + str(wp_bod) + "," + str(wp_cod))
# %%
'''3) 문자열 반복 : *'''
# 5-(3)-3)-1
"apple" * 3
# %%
# 5-(3)-3)-2
print("*" * 15)
print("apple" * 3)
# %%
'''문제해결 5-3-3)'''
# 5-(3)-3)-3

# 순서1
input_str = input("반복할 문자열 입력: ")
re_cnt = int(input("횟수 입력: "))

# 순서2
print(input_str * re_cnt)
# %%
'''4) 문자열 포함여부 : in, not in'''
# 5-(3)-4)-1
print("korea" in "republic korea")
print("of" in "republic korea")
# %%
# 5-(3)-4)-2
print("korea" not in "republic korea")
print("of" not in "republic korea")
# %%
'''5) 문자열 슬라이싱'''
# 5-(3)-5)-1
str1 = "blue & grey"

print(str1[2:8])
print(str1[:4])
print(str1[7:])
# %%
'''문제해결 5-3-4)'''
# 5-(3)-5)-2

# 순서1
data_str = "Spring Summer Fall Winter"

# 순서2
index_sta = int(input("시작 인덱스(0 ~ 24) 입력: "))
index_end = int(input("끝 인덱스(1 ~ 25) 입력: "))

# 순서3
print(data_str[index_sta:index_end])
# %%
'''6) 문자열처리 함수'''
# 5-(3)-6)-1
print(len("singularity"))
# %%
# 5-(3)-6)-2
print("-".join("ABC"))
# %%
# 5-(3)-6)-3
bear_list = ["Singularity", "Secnery", "Winter Bear", "4 o'clock"]
print(", ".join(bear_list))
# %%
# 5-(3)-6)-4
print("a.jpg".split("."))
# %%
# 5-(3)-6)-5
print("Singularity Secnery Winter Bear".split())
# %%
# 5-(3)-6)-6
print("https://www.python.org/".strip("https://"))
# %%
# 5-(3)-6)-7
print("  Winter Bear ".strip())
# %%
# 5-(3)-6)-8
print("https://www.python.org/".replace("python.org", "anaconda.com"))
# %%
# 5-(3)-6)-9
print("https://www.anaconda.com/".find("anaconda"))
print("test.png".find("jpg"))
# %%
'''(4) 불리언 타입 – bool'''
# 5-(4)-1
bool_val = True
bool_val
# %%
# 5-(4)-2
print(bool(1))
print(bool(0))
print(bool("test"))
print(bool(""))
# %%
'''(5) 타입 확인 및 타입 변환 함수'''
# 5-(5)-1
int_val = 100
str_val = "test"
print(type(int_val))
print(type(str_val))
# %%
# 5-(5)-2
temp_val = -12.1
print(str(temp_val) + "도")
# %%
# 5-(5)-3
t1 = 23.7
print(int(t1))
print(int("127"))
# %%
# 5-(5)-4
t2 = 100
print(float(t2))
print(float("1995.123"))
# %%
'''(6) 포맷팅 : %연산자, format()메소드'''
# 5-(6)-1
"%d" % (123)
# %%
# 5-(6)-2
"%7d" % (1234)
# %%
# 5-(6)-3
"%7s" % ("Var en nas : Honor for you.")
# %%
# 5-(6)-1)-1
print("%d" % (123))
print("%5d" % (123))
# %%
# 5-(6)-1)-2
print("%f" % (12345.175))
print("%.2f" % (12345.175))
# %%
# 5-(6)-1)-3
print("%s" % ("Secnery"))
print("%5s" % ("Winter Bear"))
# %%
# 5-(6)-1)-4
print("{0}".format(123))
print("{}".format(123))
# %%
# 5-(6)-1)-5
print("{0:d}".format(123))
print("{0:}".format(123))
print("{0:d}, {1:.1f}".format(123, 123.45))
# %%
# 5-(6)-2)-1
print("이 %s 노트북 가격은 %d 만원" % ("ultra", 200))
print("이 {0:s} 노트북 가격은 {1:d} 만원".format("울트라", 200))
