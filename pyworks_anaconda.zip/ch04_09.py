# -*- coding: utf-8 -*-
"""
Created on Sun Aug 12 09:56:01 2018

@author: KEO
"""

'''4.9.1'''
print("\n4.9.1 define function")


def my_add(a, b):
    '''간단한 덧셈을 수행하는 함수'''
    print("인자는 %s와 %s\n" % (a, b))
    return a + b


ans = my_add(3, 4)
print("my_add(3, 4) = ", ans)

print(my_add('abc', 'def'))

print(my_add(3.2, 1.5))

'''4.9.2'''
print("\n4.9.2")


def my_add2(a, b=5):
    print("인자는 %s와 %s\n" % (a, b))
    return a + b


print(my_add2(3))

print("\n")


def list_append(a, mylist=[]):
    mylist.append(a)
    return mylist


print(list_append(1))
print(list_append(2))
print(list_append(3))


def list_append2(a, mylist=None):
    if mylist is None:
        mylist = []
    mylist.append(a)
    return mylist


print(list_append2(1))
print(list_append2(2))

'''4.9.3'''
print("\n4.9.3")


def func_varg(a, b, *args, **kwargs):
    print(a, b, args, kwargs)


print(func_varg(3, 'best', 5, 6.2, num=3, hight='high'))


'''4.9.4'''
print("\n4.9.4")

mylamf = (lambda x, y: x * x + y)
print(mylamf(3, 4))

xy = [[3, 5, 1], [4, 2, 9]]
ans = list(map(lambda x, y: x * x + y, *xy))
print(ans)


'''4.9.5'''
print("\n4.9.5")


def count_down(m):
    print("키운트다운 %d부터 시작" % m)
    while m > 0:
        if m == 3:
            print('m = 3')
        yield m
        m -= 1
    print("카운트다운 끝")
    return


cnt = count_down(5)
print(next(cnt))


'''4.9.6'''
print("\n4.9.6")
'''decorator_1.py'''
