# -*- coding: utf-8 -*-
"""
Created on Sat Aug 11 16:00:45 2018

@author: KEO
"""

'''4.7.1'''
print("\n4.7.1")
x = True
y = False

print("x or y : ", x or y)
print("x and y : ", x and y)

'''4.7.3'''
print("\n4.7.3")
print(22 / 5)
print(22 // 5)
print(22.0 // 5.0)
print(-22 // 5)
print(-(22 // 5))
