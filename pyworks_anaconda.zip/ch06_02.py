# -*- coding: utf-8 -*-
"""
Created on Sun Aug 19 15:11:21 2018

@author: KEO
"""

'''6.2'''
print("\n6.2 Input/Output File")

a = ['Scientific ', 'computing ', 'in Python.']
with open('textfile.txt', 'w', encoding='utf-8') as f:
    f.write('Stay hungry, stay foolish.\n')
    f.writelines(a)

with open('textfile.txt', 'r', encoding='utf-8') as f:
    whole_file = f.read()
    print(whole_file)
