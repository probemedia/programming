# -*- coding: utf-8 -*-
"""
Created on Thu Aug 30 14:42:08 2018

@author: KEO
"""
import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
# %%
'''9.1'''
print("\n9.1 matplotlib")
'''9.1.2'''
print(mpl.rcParams)

'''9.2'''
print("\n9.2 matplotlib")

mpl.rcParams['lines.linewidth'] = 10
mpl.rcParams['lines.linestyle'] = '--'
mpl.rc('lines', linewidth=10,  linestyle='--')

t = np.arange(0, 2*np.pi, 0.1)
plt.figure(1)
plt.plot(t, np.sin(t))
plt.show()

'''9.2.2'''
mpl.get_configdir()
mpl.matplotlib_fname()

'''9.2.3'''
print(plt.style.available)
plt.style.use('ggplot')

'''import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np'''
x = np.arange(0, np.pi, 0.01)
with plt.style.context('dark_background'):
    plt.plot(x, np.sin(x))
# %%
'''9.2.4'''

import matplotlib as mpl
import matplotlib.pyplot as plt
import matplotlib.font_manager as fm

font_path = 'C:/Windows/Fonts/NanumGothic.ttf'
font_prop = fm.FontProperties(fname=font_path)
font_prop.set_style('normal')
font_prop.set_size('16')
plt.figure(1)
plt.plot([1,2,3],[2,5,9])
plt.xlabel('x축', fontproperties=font_prop)
plt.ylabel('y축', fontproperties=font_prop)
plt.show()

