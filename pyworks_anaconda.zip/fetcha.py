# -*- coding: utf-8 -*-
"""
Created on Sun Aug 12 11:36:12 2018

@author: KEO
"""

a = 3


def fetch_a():
    return a


if __name__ == "__main__":
    a = 5
    print(fetch_a())
