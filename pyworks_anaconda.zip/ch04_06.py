# -*- coding: utf-8 -*-
"""
Created on Sat Aug 11 15:31:04 2018

@author: KEO
"""
import copy

'''4.6.1'''
print("\n4.6.1")

a = [1, 2, 3, 4]
b = copy.copy(a)
print(a is b)

print("\n")
b[0] = 100
print("a = ", a)
print("b = ", b)

print("\n")
a = [1, 2, [30, 40]]
b = copy.copy(a)
b[0] = 100
print("a = ", a)
print("b = ", b)
b[2][0] = 200
print("b = ", b)
print("a = ", a)
print(a[2] is b[2])

'''4.6.2'''
print("\n4.6.2")
a = [0, 1, [20, 30], 4]
b = copy.deepcopy(a)
print("a = ", a)
print("b = ", b)
print(id(a), id(b))

b[0] = -5
b[2][0] = 100
print("a = ", a)
print("b = ", b)
