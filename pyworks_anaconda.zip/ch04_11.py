# -*- coding: utf-8 -*-
"""
Created on Sun Aug 12 11:22:53 2018

@author: KEO
"""

'''4.11.3'''
print("\n4.11.3")

a, b = 3, 7


def foo():
    a = 5
    print('(a,b) = (%d, %d)' % (a, b))


print(foo())
print(a)

print("\n")

a, b = 3, 7


def foo():
    global a
    a = 5
    print('(a,b) = (%d, %d)' % (a, b))


foo()
print(a)
