# -*- coding: utf-8 -*-
"""
Created on Sun Aug 19 16:21:58 2018

@author: KEO
"""
import numpy as np
import pandas as pd

'''6.4'''
print("\n6.4 Input/Output pandas")

df = pd.DataFrame(np.random.randn(1000000, 2), columns=list('AB'))
df.info()

'''6.4.3'''
print("\n6.4.3 Input/Output pandas")
dat = pd.read_csv('veldat.csv', encoding='cp949')

dat = pd.read_csv('veldat.csv',
                  encoding='cp949',
                  skiprows=1,
                  header=0,
                  sep=';')

dat = pd.read_csv('veldat.csv',
                  encoding='cp949',
                  header=0,
                  sep=';')

dat = pd.read_csv('veldat.csv',
                  encoding='cp949',
                  header=0,
                  sep=';',
                  skipinitialspace=True)

dat = pd.read_csv('veldat.csv',
                  encoding='cp949',
                  header=0,
                  sep=';',
                  skipinitialspace=True,
                  names=['t', 'stat', 'h', 'vel'])

dat = pd.read_csv('veldat.csv',
                  encoding='cp949',
                  header=0,
                  sep=';',
                  skipinitialspace=True,
                  names=['t', 'stat', 'h', 'vel'],
                  index_col='t')
