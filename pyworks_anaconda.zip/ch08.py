# -*- coding: utf-8 -*-
"""
Created on Sun Aug 26 15:42:49 2018

@author: KEO
"""
import scipy as sp
import numpy as np
import scipy.fftpack

'''8.1'''
print("\n8.1 SciPy")
'''8.1.2'''
np.polyfit is sp.polyfit

'''8.1.3'''
np.fft.fft is scipy.fftpack.fft

y = sp.randn(2**16)

'''
%timeit Y = np.fft.fft(y)
547 µs ± 6.67 µs per loop (mean ± std. dev. of 7 runs, 1000 loops each)

%timeit Y = scipy.fftpack.fft(y)
1.02 ms ± 12.8 µs per loop (mean ± std. dev. of 7 runs, 1000 loops each)
'''

'''8.2'''
print("\n8.2 SciPy")
'''8.2.6'''
'''
A = sp.random.randn(4, 4)
Q, R = np.linalg.qr(A)
np.allclose(A, np.dot(Q, R))
'''
from scipy import random, linalg, allclose

A = random.randn(4, 4)
Q, R = linalg.qr(A)
allclose(A, np.dot(Q, R))

A = random.randn(4, 4)
P, L, U = linalg.lu(A)
allclose(A, P.dot(L.dot(U)))

from scipy import array, linalg, dot

A = array([[3,-1.2j],[1.2j,1]])
L = linalg.cholesky(A, lower=True)
allclose(A, dot(L,L.T.conj()))
