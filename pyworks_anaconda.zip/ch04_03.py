# -*- coding: utf-8 -*-
"""
Created on Sat Aug 11 13:09:20 2018

@author: KEO
"""
print("4.3 sequence")
print("4.3.1 indexing")

mylist = [1, 10, 'name', [3, 4]]
print(mylist[0])
print(mylist[1])
print(mylist[-1])
print(mylist[3][0])
print(mylist[-2])

'''4.3.2'''
print("\n4.3.2 inexing")

a = [0, 1, 2, 3, 4, 5]
print(a[0:3])
print(a[2:-1])
print(a[-3:-1])
print(a[-2:-4])
print(a[:-3])
print(a[2:])
print(a[0:3:2])
print(a[1::2])

'''4.3.3'''
print("\n4.3.3 change data")

a = [0, 1, 2, 3, 4, 5]
a[1] = 10
print(a)
a[2:4] = [200, 300]
print(a)

print("\n")
a = [0, 10, 20, 30, 3]
a.append(11)
print(a)
a.remove(3)
print(a)

'''4.3.4'''
print("\n4.3.3 list comprehension")

mylist = []
mylist = [2*x*x for x in range(5)]
print(mylist)

print("\n")
a = [x*y+y for x, y in zip(range(10), range(10, 30, 2))]
print(a)

print("\n")
b = [2*x+y for x in range(4) for y in range(3)]
print(b)

print("\n")
c = [x for x in range(10) if x % 3 == 0]
print(c)



