# -*- coding: utf-8 -*-
"""
Created on Sat Aug 11 14:15:12 2018

@author: KEO
"""

'''4.4.1'''
print("\n4.4.1 set type")

setA = {'a', 'b', 'c', 'd'}
setB = {'c', 'd', 'e', 'f'}
print(setA.union(setB))
print(setA.intersection(setB))
print(setA.difference(setB))
print(setA.symmetric_difference(setB))

print("\n")
a = {2*x % 6 for x in range(10)}
print(a)

'''4.4.2'''
print("\n4.4.2 dictionary type")

mydicA = dict([('kenji', 41), ('yasuko', 38), ('saori', 1)])
print("mydicA : ", mydicA)
mydicB = dict(kenji=41, yasuko=38, saori=1)
print(mydicB)
mydicC = {x: x**3 for x in (1, 2, 4)}
print(mydicC)

print(sorted(mydicA.keys()))
print(list(mydicA.keys()))
