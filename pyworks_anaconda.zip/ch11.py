# -*- coding: utf-8 -*-
"""
Created on Sat Sep  1 16:04:13 2018

@author: KEO
"""
import scipy as sp
import numpy as np
import time
# %%
'''11.2'''
print("\n11.2 Optimize")
'''11.2.2'''
%timeit x = 1213; x = x * 2
%timeit x = 1213; x = x << 1
%timeit x = 1213; x = x + x


'''11.2.3'''

a = np.random.randn(100000)
print('original identity : %s' % id(a))
ts = time.process_time()
a *= 2
te = time.process_time()
print('inplalce : identity = %s, 실행시간 = %.5f [s]' % (id(a), (te - ts)))

ts = time.process_time()
a = a * 2
te = time.process_time()
print('inplalce : identity = %s, 실행시간 = %.5f [s]' % (id(a), (te - ts)))

'''https://wikidocs.net/10780 참조해서
get_data_base(arr)함수와 def arrays_share_data(x, y)함수 얻어냄'''


def get_data_base(arr):
    """For a given Numpy array, finds the
    base array that "owns" the actual data."""
    base = arr
    while isinstance(base.base, np.ndarray):
        base = base.base
    return base

def arrays_share_data(x, y):
    return get_data_base(x) is get_data_base(y)

a = np.arange(100).reshape(10, 10)
b = a.reshape(1, -1)
c = a.T.reshape(1, -1)
print('a 와 b가 같은 데이터 저장 : %s' % arrays_share_data(a, b))
print('a 와 c가 같은 데이터 저장 : %s' % arrays_share_data(a, c))

%timeit a.reshape(1, -1)
%timeit a.T.reshape(1, -1)

d = a.flatten()
e = a.ravel()
print('a 와 d가 같은 데이터 저장 : %s' % arrays_share_data(a, d))
print('a 와 e가 같은 데이터 저장 : %s' % arrays_share_data(a, e))
%timeit a.flatten()
%timeit a.ravel()

n, d = 1000, 100
a = np.random.random_sample((n, d))
b1 = a[::10]
b2 = a[np.arange(0, n, 10)]
print('b1 is b2? : %s' % np.array_equal(b1, b2))
print('a 와 b1가 같은 데이터 공유 : %s' % arrays_share_data(a, b1))
print('a 와 b2가 같은 데이터 공유 : %s' % arrays_share_data(a, b2))
%timeit a[::10]
%timeit a[np.arange(0, n, 10)]

'''11.2.4'''




