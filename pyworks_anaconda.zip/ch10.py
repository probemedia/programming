# -*- coding: utf-8 -*-
"""
Created on Fri Aug 31 16:57:07 2018

@author: KEO
"""
import scipy as sp
import numpy as np
import pandas as pd

'''10.2'''
print("\n10.2 pandas")

'''10.2.2 Series'''
dat = pd.Series([1, 3, 6, 12])
dat
dat.values
dat2 = pd.Series(np.array([1, 3, np.nan, 12]))
dat3 = pd.Series(['aa', 'bb', 'c', 'd'])
dat4 = pd.Series([1, 'aa', 2.34, 'd'])
dat5 = pd.Series([1, 3, 6, 12], index=[1, 10, 20, 33])
dat6 = pd.Series([1, 3, 6, 12], index=['a', 'b', 'c', 'd'])
dat7 = pd.Series({'a': 1, 'b': 3, 'c': 6, 'd': 12})
dat2.index = ['un', 'due', 'trois', 'quatre']

'''10.2.3 DataFrame'''
fruit_dat = {'c_지자체': ['예산', '영주', '청송', '횡성', '나주', '보성',
                       '함안', '영월', '상주'],
             'a_과일': ['복숭아', '복숭아', '복숭아', '딸기', '딸기', '딸기',
                        '사과', '사과', '사과'],
             'b_수확량순위': [1, 2, 3, 1, 2, 3, 1, 2, 3]
}
d = pd.DataFrame(fruit_dat)
d.columns

d2 = pd.DataFrame(fruit_dat, columns=['a_과일', 'c_지자체', 'b_수확량순위'])
d2

d3 = pd.DataFrame(fruit_dat,
                  columns=['a_과일', 'c_지자체', 'b_수확량순위', 'd_수확량점유율'])
d3

s1 = d['c_지자체']
s1

df = pd.DataFrame(np.random.rand(4, 4),
                  index=[['x', 'x', 'y', 'y'], [0, 1, 0, 1]],
                  columns=['Time_a', 'Time_b', 'Vel_a', 'Vel_b'])

df

a = df.xs(0, level=1, axis=0)
a

df.columns = pd.MultiIndex.from_tuples(
        [tuple(c.split('_')) for c in df.columns])


df

'''10.2.4 '''
data = {'Item1': pd.DataFrame(np.random.randn(3, 2)),
        'Item2': pd.DataFrame(np.random.randn(3, 2))}

pp1 = pd.Panel(data)

pp1
pp1.Item1

pp2 = pd.Panel(np.random.randn(2, 4, 3), items=['Item1', 'Item2'],
               major_axis=pd.date_range('2/1/2016', periods=4),
               minor_axis=['one', 'two', 'three'])

pp2
pp2.major_axis
pp2.Item1.index
pp2.major_axis is pp2.Item1.index


'''10.3'''
print("\n10.3 pandas")

df = pd.DataFrame(np.random.randn(3, 4))
df
np.fabs(df)
na = np.array(df)

'''10.3.3'''
df = pd.DataFrame(np.arange(12).reshape(3, 4),
                  index=list('xyz'),
                  columns=list('abcd'))

df
df.at['y', 'b']
df.at['y', 'b'] = 10
'''
%timeit df.at['x', 'a']
%timeit df.ix['x', 'a']
'''
'''10.3.4'''
ser1 = pd.Series(np.arange(4), index=list('abcd'))
ser2 = pd.Series(np.arange(10, 14), index=list('abcd'))

ser1
ser2
ser_a1 = ser1 + ser2
ser_s1 = ser1 - ser2
ser_m1 = ser1 * ser2
ser_d1 = ser1 / ser2

ser_a2 = ser1.add(ser2)
ser_s2 = ser1.sub(ser2)
ser_m2 = ser1.mul(ser2)
ser_d2 = ser1.div(ser2)


ser1 = pd.Series([1, 2, np.nan, 4])
ser2 = pd.Series([10, np.nan, 30, 40])
ser1 + ser2

ser1.add(ser2, fill_value=0)

ser1 = pd.Series([1, 2, np.nan, 4])
ser2 = pd.Series([10, np.nan, 30, 40], index=list('abcd'))
ser1 + ser2
ser1.add(ser2, fill_value=0)
ser1.add(ser2.values, fill_value=0)

df1 = pd.DataFrame(np.arange(6).reshape(2, 3), columns=list('xyz'))
df2 = pd.DataFrame(np.arange(12).reshape(3, 4), columns=list('wxyz'))
df1 + df2
df1.add(df2, fill_value=0)

'''10.3.5'''
df1.lt(df2)
df1.lt([1, 2, 3], axis='columns')
df1.lt(4)
df1[df1.lt(4)]

'''10.3.6'''
ser = pd.Series(np.random.rand(5)*10, dtype=int)
ser
m = ser.mean()
m
ser.var()
ser.var(ddof=0)

'''10.3.7'''
s = pd.Series(np.arange(4), index=['zero', 'one', 'two', 'three'])
s
dic = {1: 10, 2: 20, 3: 30}
dic
s.map(dic)

s = pd.Series(np.arange(4), index=['zero', 'one', 'two', 'three'])
map_rule = pd.Series(['even', 'odd', 'even', 'odd'])
s.map(map_rule)

map_rule = pd.Series(['even', 'odd', 'even', 'odd'], index=list('abcd'))
s.map(map_rule)


def f(x):
    return np.exp(x+1) + 2*x


s.map(f)
s.map(lambda x: np.exp(x+1) + 2*x)


def fn(x):
    return np.fabs(x.min())


df = pd.DataFrame(np.random.randn(3, 4),
                  index=['zero', 'one', 'two'],
                  columns=list('abcd'))
df
df.apply(fn, axis=1)
df.applymap(lambda x: np.exp(x+1) + 2*x)

'''10.3.8'''
df = pd.DataFrame({'int': [2, 4, 9, np.nan],
                   'flt': [1.25, -3.51, np.nan, 0.269],
                   'str': [np.nan, 'apple', 'peach', 'melon']})
df
df.dropna(subset=['flt'])
df.dropna()
df.dropna(axis=1, subset=[2, 3])

df = pd.DataFrame(np.random.randn(5, 3))
df
df.iloc[1:, 0] = np.nan
df
df.iloc[1:4, 2] = np.nan
df
df.fillna(0)
df
df.fillna(method='ffill', limit=2)
df
df.fillna(method='bfill')
df
df.isnull()
df.notnull()
df.isnull().any(axis=0)

'''10.3.9'''
'''10.3.10'''
df
df2 = df.copy()