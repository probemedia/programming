# 파일명 : module_1.py """
print("module_1 is imported.")
wgt = 60.5  # 초기체중 [kg]


def teacher(x):
    if x > 60:
        print("과다체중입니다")
    else:
        print("적정체중입니다")


def run(weight):
    print("달리기로 체중을 1kg 감량합니다.")
    weight -= 1
    return weight
