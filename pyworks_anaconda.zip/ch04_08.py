# -*- coding: utf-8 -*-
"""
Created on Sat Aug 11 16:09:11 2018

@author: KEO
"""

'''4.8.1'''
print("\n4.8.1 if")
if 3 < 5:
    print("3 is smaller than 5.")

'''4.8.2'''
print("\n4.8.2 for")
a = 8
if a < 5:
    print('a is smaller than 5.')
elif a > 10:
    print('a is bigger than 10.')
elif a > 8:
    print('a is bigger than 8.')
else:
    print('5 <= a <= 8')

'''4.8.3'''
print("\n4.8.2 while")
fib = [0, 1]
while fib[-1] < 30:
    tmp = fib[-2] + fib[-1]
    fib = fib + [tmp]
else:
    print(fib)

'''4.8.4'''
print("\n4.8.4 try")
try:
    file_in = open('no_file.txt')
    for line in file_in:
        print(line)
    file_in.close
except:
    print('error')

'''4.8.5'''
print("\n4.8.4 with")

with open('science.txt', 'tw') as f:
    f.write("Let's use Python for scientific calculations.")
