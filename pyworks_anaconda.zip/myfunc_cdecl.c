/* myfunc_cdelc.c */
int myadd(int x, int y) {
	return x + y;
}
