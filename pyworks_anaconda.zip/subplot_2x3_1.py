import matplotlib.pyplot as plt

indexs = [1, 2, 3, 4, 5, 6]
datas = ['subplot(2,3,1)', 'subplot(2,3,2)', 'subplot(2,3,3)',
         'subplot(2,3,4)', 'subplot(2,3,5)', 'subplot(2,3,6)']

plt.figure(1), plt.clf()

for i in indexs:
    "홀수번째와 짝수번째일때 배경색 다름"
    """홀수번째와 짝수번째일때 
    배경색 다름"""
    if i % 2:
        plt.style.use('dark_background')
    else:
        plt.style.use('classic')

    plt.subplots_adjust(wspace=0, hspace=0)  # 서브 플롯 간격 0
    plt.subplot(2, 3, i), plt.xticks([]), plt.yticks([])
    plt.text(0.5, 0.5, datas[i-1], ha='center', va='center', size=15)


# 전체 플롯을 파일로 저장
plt.savefig('subplot2.png')
# 전체 플롯을 화면에 표시
plt.show()
