# -*- coding: utf-8 -*-
"""
Created on Sat Aug 25 14:55:27 2018

@author: KEO
"""
import numpy as np
import copy

'''7.2'''
print("\n7.2 Numpy Data type")
'''7.2.2'''
a = np.uint16(34)
b = np.complex128([3.2, 4.2+1.09j])
c = np.array([2334.432, 2.23], dtype=np.single)
'''7.2.3'''
a = np.int64(33)
a.flags

'''7.3'''
print("\n7.3 ndarray")
'''7.3.2'''
matA = [[3, 1, 9], [2, 5, 8], [4, 7, 6]]
matA
matA[0][2]

matB = np.array([[3, 1, 9], [2, 5, 8], [4, 7, 6]])
matC = np.array(((3, 1, 9), (2, 5, 8), (4, 7, 6)))
matB
matB[0][2]
matC
matC[0][2]

np.zeros((2, 3))
np.arange(10, 20, 2)

np.arange(0.1, 0.4, 0.1)
np.arange(1, 4, 1)

'''7.3.3'''
dt = np.dtype('float')
x = np.array([1.1, 2.1, 3.1], dtype=dt)
x = np.array([1.1, 2.1, 3.1], dtype='float')

'''7.3.4'''
matB = np.array([[3, 1, 9], [2, 5, 8], [4, 7, 6]])
matB.shape
matB.dtype

'''7.3.6'''
'''A = [[-2, 1], [1.5, -0.5]]'''
A = [[1, 2], [3, 4]]
A_1 = np.linalg.inv(A)
np.linalg.inv(A_1)
np.linalg.det(A)
np.linalg.det(A_1)

np.linalg.matrix_rank(A)

a, b = np.array([2, -4, 1]), np.array([3, 1, -2])
np.inner(a, b)
np.cross(a, b)

'''7.3.7'''
x2d = np.arange(12).reshape(3, 4)
x2d

a = x2d[1][1:]  # a = x2d[1, 1:]  # 이것이 더 빠름
a
a[0] = -1
x2d

x2d[0, 2]
b = x2d[1:, 2:]
b
b[:, :] = 20
x2d

dat = np.random.rand(2, 3)
dat

bmask = dat > 0.5
bmask

highd = dat[bmask]
highd

highd[0] = 10
highd
dat

nda = np.arange(10)
ndb = nda[1:4]
ndc = nda[[1, 2, 3]]
ndb == ndc

nda = np.arange(12).reshape(3, 4)
nda
ndb = nda[[0, 2, 1], [2, 0, 3]]
ndb

nda[np.ix_([0, 2], [1, 3])]

'''7.3.8'''
a = np.array([-0.1, np.ones((3,))], 'O')
b = a.copy()

b[1][0] = 100
a

c = copy.deepcopy(a)
c[1][0] = -1
a

'''7.3.9'''
nda = np.arange(12).reshape(4, 3, order='F')
nda

ndb = np.zeros((3, 3), order='C')
ndb

'''7.4'''
print("\n7.4 universal function")
'''7.4.1'''
nda = np.arange(12).reshape(2, 6)
nda
np.square(nda)

'''7.4.2'''
hex_array = np.frompyfunc(hex, 1, 1)
hex_array(np.array((10, 30, 100)))
np.array((hex(10), hex(30), hex(100)))

'''7.5'''
'''7.5.1'''
nda = np.array([1, 2, 3])
nda + 1

'''7.5.2'''
nda = np.arange(24).reshape(4, 3, 2)
nda
ndb = np.arange(6).reshape(3, 2)
ndb
ndc = np.arange(3).reshape(3, 1)
ndc

nda + ndb - ndc

'''7.5.3'''
nda = np.arange(12).reshape(3, 4)
nda
ndb = np.arange(4)
ndb
nda + ndb

nda = np.arange(12).reshape(4, 3)
ndb = np.arange(4).reshape(4, 1)
nda + ndb
