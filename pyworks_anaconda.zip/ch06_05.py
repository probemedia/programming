# -*- coding: utf-8 -*-
"""
Created on Sun Aug 19 16:29:29 2018

@author: KEO
"""

import urllib.request

'''6.5'''
print("\n6.5 Read web data")

response = urllib.request.urlopen('https://www.python.org/')
html = response.read()
print(html)
