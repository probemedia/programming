# -*- coding: utf-8 -*-
"""
Created on Thu Aug 30 18:23:45 2018

@author: KEO
"""

import platform
platform.platform()

import sys
sys.version_info

import matplotlib

print ('버전: ', matplotlib.__version__)
print ('설치위치: ', matplotlib.__file__)
print ('설정: ', matplotlib.get_configdir())
print ('캐시: ', matplotlib.get_cachedir())

fm.fontManager.ttflist
[(f.name, f.fname) for f in fm.fontManager.ttflist if 'GyeonggiBatang' in f.name]