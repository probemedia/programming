# -*- coding: utf-8 -*-
"""
Created on Thu Aug 30 18:01:58 2018

@author: KEO
"""
'''9.2.4'''
import matplotlib.pyplot as plt
import matplotlib.font_manager as fm
import numpy as np

data = np.random.randint(-100, 100, 50).cumsum()

font_path = 'C:/Windows/Fonts/경기천년바탕_Regular.ttf'
fontprop = fm.FontProperties(fname=font_path, size=18)

plt.ylabel('가격', fontproperties=fontprop)
plt.title('가격변동 추이', fontproperties=fontprop)
plt.plot(range(50), data, 'r')
plt.show()
