# -*- coding: utf-8 -*-
"""
Created on Thu Aug 30 18:29:32 2018

@author: KEO
"""
import matplotlib as mpl
import matplotlib.pyplot as plt
import matplotlib.font_manager as fm

font_path = 'C:/Windows/Fonts/경기천년바탕_Regular.ttf'
fontprop = fm.FontProperties(fname=font_path, size=16)

mpl.rc('lines', linewidth=3,  linestyle='-')

plt.figure(1)
plt.plot([1, 2, 3], [2, 5, 9])
plt.xlabel('x축', fontproperties=fontprop)
plt.ylabel('y축', fontproperties=fontprop)
plt.show()
