# -*- coding: utf-8 -*-
"""
Created on Fri Aug 10 15:26:04 2018

@author: KEO
"""

import math


def myfun(x, y):
    a = math.cos(3 * (x - 1)) + \
        math.sin(3 * (y - 1))
    return a


x, y = 2.0, 5.0
print("myfun(x,y) = %f" % myfun(x, y))
