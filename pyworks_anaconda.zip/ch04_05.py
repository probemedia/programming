# -*- coding: utf-8 -*-
"""
Created on Sat Aug 11 14:44:18 2018

@author: KEO
"""

'''4.5.1'''
print("\n4.5.1 create new variable")
a = 2
b = a
c = 5

print(id(a))
print(id(b))
print(id(c))

'''4.5.2'''
print("\n4.5.2")
a, c = 7, 8
print(id(a))
print(id(b))
print(id(c))

'''4.5.3'''
print("\n4.5.3")
a = [0, 1, 2, 3]
b = a
print(id(a))
print(id(b))

b[2] = 100
print(a)
print(id(a), id(b))
print(a is b)

print("\n")
a = [0, 1, 2, 3]
b = a
print(a, b)
print(id(a), id(b))

b = [0.0, 1.1, 2.2, 3.3]
print(a, b)
print(id(a), id(b))
print(a is b)

print("\n")
b = a
print(a, b)
print(id(a), id(b))
b[:] = [0.0, 0.1, 2.2, 3.3]
print(a, b)
print(id(a), id(b))

print("\n")
a = [0, 1, 2, 3]
b = [0, 1, 2, 3]

print(a == b)
print(a is b)
print([id(k) for k in a])
print([id(k) for k in b])
print(id(a), id(b))
