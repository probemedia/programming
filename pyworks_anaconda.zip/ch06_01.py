# -*- coding: utf-8 -*-
"""
Created on Sun Aug 19 14:35:03 2018

@author: KEO
"""

'''6.1'''
print("\n6.1 Input console")

buf = input('좋아하는 문구 입력 : ')
print(buf)

buf = input('마음에 드는 정수 입력 : ')
print(type(buf))
int_a = int(buf)
print(type(int_a))
print(int_a)
