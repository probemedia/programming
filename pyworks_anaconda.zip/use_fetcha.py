# -*- coding: utf-8 -*-
"""
Created on Sun Aug 12 11:38:12 2018

@author: KEO
"""

from fetcha import fetch_a

a = 7
print(fetch_a())
