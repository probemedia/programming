# -*- coding: utf-8 -*-
"""
Created on Fri Aug 10 15:45:08 2018

@author: KEO
"""


def myfunc(n, b):
    x = n % b
    if x == 0:
        return 1
    else:
        return 0


n = 123456
b = 3

print(myfunc(n, b))
