# -*- coding: utf-8 -*-
"""
Created on Sun Aug 12 11:13:38 2018

@author: KEO
"""

'''4.10.1'''
print("\n4.10.1")
'''module1.py
   module2.py'''
