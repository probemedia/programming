# -*- coding: utf-8 -*-
"""
Created on Thu Jul 11 10:20:21 2019

@author: KEO
"""

''' ch03 '''
print("Hello World!")

a, b = 2, 3
a + b

b = dict(saori=5, kenji=63, yasuko=47)


def my_add(x, y):
    '''
    두수를 더한다.

    입력
    ---
    x: 첫번째 수
    y: 두번째 수

    출력
    ---
    out: x + y의 계산 결과
    '''
    out = x + y
    return out


''' 86p
import scipy as sp
sp.linalg?
import numpy as np
np.linalg?
'''

'''88p
%timeit x = np.arange(10000)
%%timeit x = np.arange(10000)
y = x ** 2
z = y - 1
'''

'''
!ping localhost

%history -no 7-9

5 + 4
d = _ + 2.5
d
'''

mingv_ver = 3.25
mikan = 'orange'

mylist = [2.3, 4.5, 6.2]

'''
%time a = [x*x for x in np.random.randn(100000)]

%timeit a = [x*x for x in np.random.randn(100000)]

%run -t ch04_01.py

%run -p -s cumulative prun1.py

import prun1
%prun [a, b] = prun1.func_both()


from fc import *

%load_ext line_profiler
%lprun -f func_c func_c()

%load_ext memory_profiler
%memit a = [x for x in range(1000000)]

import fc
mprun -f fc.func_c fc.func_c()

run prun2


'''
