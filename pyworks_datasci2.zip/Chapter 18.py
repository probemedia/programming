
# coding: utf-8

# # 18장. 확률
import numpy as np
import scipy as sp
import pandas as pd
from matplotlib import pyplot as plt
from matplotlib import font_manager, rc
import platform

plt.rcParams['axes.unicode_minus'] = False

if platform.system() == 'Darwin':
    rc('font', family='AppleGothic')
elif platform.system() == 'Windows':
    path = "c:/Windows/Fonts/malgun.ttf"
    font_name = font_manager.FontProperties(fname=path).get_name()
    rc('font', family=font_name)
else:
    print("Unknown System OS")
# In[3]:


# import matplotlib
# matplotlib.rc('font', family="NanumBarunGothicOTF")

# get_ipython().run_line_magic('matplotlib', 'inline')


# In[4]:
'''18.4'''

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

z = np.zeros(1000)
x = np.random.exponential(size=1000)
data = np.concatenate([z, x])
pd.Series(data).hist(bins=100)
plt.title("Huge Spike at Zero")

D = pd.Series(data)
X = pd.Series(x)
D.hist(bins=100)  # 별다른 처리 없이 히스토그램을 그린다.
plt.show()
# 0과 나머지 값의 비율을 파이 차트로 그린다.
(D > 0).value_counts().rename(
        {True: '> 0', False: '= 0'}).plot(kind='pie')
plt.title('Breakdown by equal/greater than Zero')
plt.show()
X.hist(bins=100)  # 0이 아닌 값의 히스토그램을 그린다.

plt.title("Distribution When > 0")
plt.show()


# # 18.7

# In[5]:

'''18.7'''
import numpy as np
import matplotlib.pyplot as plt
np.random.seed(10)
means = []
sum = 0.0
for i in range(1, 1000):
    # 파레토 분포에서 표본을 추출한다.
    sum += np.random.pareto(1)
    means.append(sum / i)
plt.plot(means)
plt.title("N개 샘플의 평균")
plt.xlabel("N")
