# -*- coding: utf-8 -*-
"""
Created on Thu Sep  5 22:38:51 2019

@author: KEO
"""
# 소스출처- https://datascienceschool.net/view-notebook/70ce46db4ced4a999c6ec349df0f4eb0/ 
# 소스출처- https://konlpy-ko.readthedocs.io/ko/v0.4.3/
import warnings
warnings.simplefilter("ignore")

import konlpy
konlpy.__version__

# %%
from konlpy.tag import Kkma
from konlpy.utils import pprint
kkma = Kkma()
pprint(kkma.sentences(u'네, 안녕하세요. 반갑습니다.'))

# %%

from konlpy.corpus import kolaw
kolaw.fileids()

c = kolaw.open('constitution.txt').read()
print(c[:40])

# %%
from konlpy.corpus import kobill
kobill.fileids()
d = kobill.open('1809890.txt').read()
print(d[:40])

# %%
from konlpy.tag import *

hannanum = Hannanum()
kkma = Kkma()
komoran = Komoran()
#mecab = Mecab()
okt = Okt()

hannanum.nouns(c[:40])

hannanum.morphs(c[:40])

hannanum.pos(c[:40])

# %%
from matplotlib import pyplot as plt
from matplotlib import font_manager, rc
import platform

# matplotlib 한글꺠짐 처리
plt.rcParams['axes.unicode_minus'] = False

if platform.system() == 'Darwin':
    rc('font', family='AppleGothic')
elif platform.system() == 'Windows':
    path = "c:/Windows/Fonts/malgun.ttf"
    font_name = font_manager.FontProperties(fname=path).get_name()
    rc('font', family=font_name)
else:
    print("Unknown System OS")
# %%
from nltk import Text

kolaw = Text(okt.nouns(c), name="kolaw")
kolaw.plot(30)
plt.show()
#%%
from wordcloud import WordCloud

# 자신의 컴퓨터 환경에 맞는 한글 폰트 경로를 설정
font_path = "c:/Windows/Fonts/malgun.ttf"

wc = WordCloud(width = 1000, height = 600, background_color="white", \
                font_path=font_path)
fig = plt.figure(figsize=(12, 12))
plt.imshow(wc.generate_from_frequencies(kolaw.vocab()), interpolation="bilinear")
fig.savefig("wordcloud.png")
plt.show()
