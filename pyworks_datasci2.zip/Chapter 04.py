
# coding: utf-8

# # 4장

# ## 4.4.2 공백 문자
# 

# In[1]:


" ABC\t".strip()


# In[2]:


"  ABC\t".lstrip()


# In[3]:


"  ABC\t".rstrip()


# In[4]:


"ABC".strip("C")


# ## 4.4.6 유효하지 않은 문자

# In[5]:


s = "abc\xFF"
print(s)  # 마지막 문자가 어떻게 되나 잘 보시죠.
type(s)
s1 = s.encode()  # encode()메소드를 사용해서 bytes타입으로 변환
type(s1)
s1.decode("ascii", "ignore")  # bytes타입의 s1변수에 decode()메소드를 사용

# ## 4.4.7 불규칙한 날짜 시간 표기

# In[7]:


import dateutil.parser as p
p.parse("August 13, 1985")


# In[8]:


p.parse("2013-8-13")


# In[9]:


p.parse("2013-8-13 4:15am")


# # 4.5 예시: 데이터 포맷 정리

# In[13]:


def get_first_last_name(s):
    INVALID_NAME_PARTS = ["mr", "ms", "mrs", "dr", "jr", "sir"]
    parts = s.lower().replace(".", "").strip().split()
    parts = [p for p in parts if p not in INVALID_NAME_PARTS]
    if len(parts) == 0:
        raise ValueError(
             "Name %s is formatted wrong" % s)
    first, last = parts[0], parts[-1]
    first = first[0].upper() + first[1:]
    last = last[0].upper() + last[1:]
    return first, last


def format_age(s):
    chars = list(s)  # 문자 리스트
    digit_chars = [c for c in chars if c.isdigit()]
    return int("".join(digit_chars))


def format_date(s):
    MONTH_MAP = {"jan": "01", "feb": "02", "may": "05"}
    s = s.strip().lower().replace(",", "")
    m, d, y = s.split()
    if len(y) == 2:
        y = "19" + y
    if len(d) == 1:
        d = "0" + d
    return y + "-" + MONTH_MAP[m[:3]] + "-" + d


import pandas as pd
df = pd.read_csv("file.tsv", sep="|")
df["First Name"] = df["Name"].apply(
    lambda s: get_first_last_name(s)[0])
df["Last Name"] = df["Name"].apply(
    lambda s: get_first_last_name(s)[1])
df["Age"] = df["Age"].apply(format_age)
df["Birthdate"] = df["Birthdate"].apply(
    format_date).astype(pd.datetime)
print(df)


# ## 4.6.1 정규식 문법
# 
# 입력 파일이 없으니 문법만 참고하세요.

# In[14]:


import re
# 이 코드는 "1600 Pennsylvania Ave."를 찾을 수 있지만
# "5 Stony Brook St"는 못찾습니다.
# "Stony Brook"에 있는 띄어쓰기 때문입니다.
street_pattern = r"^[0-9]\s[A-Z][a-z]*" + \
    r"(Street|St|Rd|Road|Ave|Avenue|Blvd|Way|Wy)\.?$"
# 보다시피 띄어쓰기는 고려하지 않습니다.
city_pattern = r"^[A-Z][a-z]*,\s[A-Z]{2},[0-9]{5}$"
address_pattern = street_pattern + r"\n" + city_pattern
# 문자열을 정규표현식 객체로 변환
address_re = re.compile(address_pattern)
text = open("some_file.txt", "r").read()
matches = re.findall(address_re, text)
# 찾아낸 문자열을 출력
open("addresses_w_space_between.txt", "w").write("\n\n".join(matches))
