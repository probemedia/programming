
# coding: utf-8

# # 24장. 고급 분류기

# # 24.2
import numpy as np
import scipy as sp
import pandas as pd
import matplotlib as mpl
from matplotlib import pyplot as plt

mpl.rc('font', family='NanumGothic')
# In[1]:


import matplotlib
matplotlib.rc('font', family="NanumBarunGothicOTF")  

get_ipython().run_line_magic('matplotlib', 'inline')


# In[6]:


from keras.models import Sequential
from keras.layers.core import Dense, Activation
model = Sequential([
   Dense(3, input_dim=3, activation='sigmoid'), # 은닉 계층
   Dense(3, activation='sigmoid') # 출력 계층 
])

model.compile(
    loss='categorical_crossentropy',  # 목적 함수
    optimizer='adadelta')  # 최적화 방법


# In[7]:


import sklearn.datasets
from keras.models import Sequential
from keras.layers.core import Dense, Activation
import pandas as pd
from sklearn.cross_validation import train_test_split

# 아이리스 데이터셋 준비
ds = sklearn.datasets.load_iris()
X = ds['data']
Y = pd.get_dummies(ds['target']).as_matrix()

# 학습 및 시험 셋으로 나눔 
X_train, X_test, Y_train, Y_test =    train_test_split(X, Y, test_size=.2)

# 신경망 구현 : 4차원 입력을 받고 은닉 계층은 노드 50개로 이루어짐
# 최종 출력은 3차원이며 소프트맥스를 활성함수로 이용함 
model = Sequential([
    Dense(50, input_dim=4, activation='sigmoid'),
    Dense(3, activation='softmax')
])

# 문제와 활성함수에 맞는 목적함수 설정
model.compile(
    loss='categorical_crossentropy',
    optimizer='adadelta')
# 학습 수행
model.fit(X_train, Y_train, nb_epoch=5)
# 학습 결과 평가
proba = model.predict_proba(X_test, batch_size=32)
pred = pd.Series(proba.flatten())
true = pd.Series(Y_test.flatten())
print("상관계수:", pred.corr(true))


# # 24.5 합성곱신경망

# In[8]:

from keras.datasets import mnist
from keras.models import Sequential
from keras.layers.core import Dense, Dropout, Activation
from keras.optimizers import Adam
from keras.utils import np_utils
import numpy as np

np.random.seed(1909)
# MNIST 데이터를 다운받는다.
# 데이터를 학습셋과 시험셋으로 나눈다 .
(X_train, y_train), (X_test, y_test) = mnist.load_data()

# 데이터를 float32 자료형으로 변환하고 정규화하기 
X_train = X_train.reshape(60000, 784).astype('float32')
X_test = X_test.reshape(10000, 784).astype('float')
X_train /= 255
X_test /= 255
# 레이블 데이터를 0-9까지의 카테고리를 나타내는 배열로 변환하기 
y_train = np_utils.to_categorical(y_train, 10)
y_test = np_utils.to_categorical(y_test, 10)
# 모델을 만든다. 모델 구조 정의하기
model = Sequential()
model.add(Dense(512, input_shape=(784,)))
model.add(Activation('relu'))
model.add(Dropout(0.2))
model.add(Dense(512))
model.add(Activation('relu'))
model.add(Dropout(0.2))
model.add(Dense(10))
model.add(Activation('softmax'))
# 모델구축하기 
model.compile(
    loss='categorical_crossentropy',
    optimizer=Adam(),
    metrics=['accuracy'])

# 데이터 훈련하기: 학습
print('학습을 시작합니다..')
hist = model.fit(X_train, y_train)

# 학습된 모델을 평가한다.
# 테스트 데이터로 평가하기
score = model.evaluate(X_test, y_test, verbose=1)
print('loss=', score[0])
print('accuracy=', score[1])

model.save("keras_minist_model2.h5")

# %%

# # 24.6 순환신경망

# In[ ]:

import sklearn.datasets
from keras.models import Sequential
from keras.layers.core import Dense, Activation
from keras.layers.recurrent import LSTM
import statsmodels as sm
# 데이터셋을 불러온다. 
df = sm.datasets.elnino.load_pandas().data
X = df.as_matrix()[:, 1:-1]
X = (X - X.min()) / (X.max() - X.min())
Y = df.as_matrix()[:, -1].reshape(61)
# 간단한 전처리
Y = (Y - Y.min()) / (Y.max() - Y.min())
# 학습셋과 시험셋으로 나눈다
X_train, X_test, Y_train, Y_test = (train_test_split(X, Y, test_size=0.1))

# 모델을 만든다. 
model = Sequential()
# LSTM의 메모리는 20차원 벡터
model.add(LSTM(20, input_shape=(11, 1)))
# 예측값은 1차원 (스칼라) 값이다
model.add(Dense(1, activation='sigmoid'))
model.compile(loss='mean_squared_error', 
              optimizer='adadelta')
# 학습 수행 
model.fit(X_train.reshape((54, 11, 1)),
          Y_train, epochs=5)
# 학습한 모델을 평가한다.
proba = model.predict_proba(X_test.reshape((7, 11, 1)),
                            batch_size=32)
pred = pd.Series(proba.flatten())
true = pd.Series(Y_test.flatten())
print("예측값과 실젯값의 상관계수:", pred.corr(true))

# %%

# %%
# # 24.10 PyMC 예제

# In[5]:


import pymc
import pymc_model as mymodel  # 모델을 불러온다
import matplotlib.pyplot as plt
S = pymc.MCMC(mymodel)  # 모델 생성
S.sample(iter = 40000, burn = 30000)  # 초반 30000개는 무시한다
pymc.Matplot.plot(S)  # 추정 값을 시각화한다
plt.show()
# %%
import pymc3 as pymc
import pymc_model as mymodel  # 모델을 불러온다
import matplotlib.pyplot as plt
S = pymc.MCMC(mymodel)  # 모델 생성
S.sample(iter = 40000, burn = 30000)  # 초반 30000개는 무시한다
pymc.Matplot.plot(S)  # 추정 값을 시각화한다
plt.show()
# %%
from collections import defaultdict

import matplotlib.pyplot as plt
import numpy as np
import pymc3 as pm
import scipy.stats as st

plt.style.use('seaborn-darkgrid')
print('Running with PyMC3 version v.{}'.format(pm.__version__))

data = np.random.randn(100)

with pm.Model() as model:
    mu = pm.Normal('mu', mu=0, sd=1, testval=0)
    sd = pm.HalfNormal('sd', sd=1)
    n = pm.Normal('n', mu=mu, sd=sd, observed=data)
    trace = pm.sample(5000)

pm.traceplot(trace)

# %%
