
# coding: utf-8

# # 13장 빅데이터

# # 13.4 파이스파크

# ## `myfile.txt`가 주어지지 않아서 실행은 안됩니다.
from pyspark import SparkConf, SparkContext
# In[ ]:

'''13.4'''
# Create the SparkContext object
# from pyspark import SparkConf, SparkContext
# conf = SparkConf()
sc = SparkContext("local", "first App")

# Read file lines and parallelize them
# over the cluster in a Spark RDD
lines = open("myfile.txt")  # exist myfile.txt
lines_rdd = sc.parallelize(lines)

# Remove punctuation, make lines lowercase


def clean_line(s):
    s2 = s.strip().lower()
    s3 = s2.replace(".", "").replace(",", "")
    return s3


lines_clean = lines_rdd.map(clean_line)

# Break each line into words
words_rdd = lines_clean.flatMap(lambda x: x.split())

# Count words


def merge_counts(count1, count2):
    return count1 + count2


words_w_1 = words_rdd.map(lambda w: (w, 1))
counts = words_w_1.reduceByKey(merge_counts)

# Collect counts and display
for word, count in counts.collect():
    print("%s: %i " % (word, count))


# # 13.11

# In[ ]:


def mapper(line):
    l2 = line.strip().lower()
    l3 = l2.replace(".", "").replace(",", "")
    words = l3.split()
    return [(w, 1) for w in words]


def reducer_func(count1, count2):
    return count1 + count2


lines = open("myfile.txt")
lines_rdd = sc.parallelize(lines)

map_stage_out = lines_rdd.flatMap(mapper)
reduce_stage_out = map_stage_out.reduceByKey(reducer_func)


# # 13.12

# In[ ]:


def mapper(line):
    return [(w, [w]) for w in line.split()]


def red_func(lst1, lst2):
    return lst1 + lst2


result = lines_rdd.flatMap(mapper).reduceByKey(red_func)


# In[ ]:


def update_agg(agg_list, new_word):
    agg_list.append(new_word)
    return agg_list  # 동일한 리스트!


def merge_agg_lists(agg_list1, agg_list2):
    return agg_list1 + agg_list2


result = lines_rdd.flatMap(mapper).aggregateByKey(
    [], update_agg, merge_agg_lists)
