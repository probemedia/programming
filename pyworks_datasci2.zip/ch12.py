# -*- coding: utf-8 -*-
"""
Created on Tue Oct  9 11:13:07 2018

@author: KEO
"""

import sys
from matplotlib.pyplot import imread
# %%
'''12.9'''
img = imread('unicron.png')

'''12.11'''
sys.maxsize
3 * sys.maxsize

'''12.12'''
x, y = 0.1, 0.2
x + y

'''12.13'''
chr(65)
ord("A")
my_string = "abc123"
my_tab = "\t"
my_newline = "\n"
fancy_string = "\xAA"
unicode_str = u"This is unicode"

my_string = "하하하123"
byte_data = my_string.encode()
as_ascii = byte_data.decode("ascii", "ignore")
as_utf8 = byte_data.decode("utf-8", "ignore")
