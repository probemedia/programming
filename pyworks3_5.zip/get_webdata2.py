# coding: utf-8
from urllib.request import urlopen
from bs4 import BeautifulSoup

#공공데이터 포털의 표준데이터의 목록중 첫페이지 얻어냄
datas = urlopen('http://data.go.kr/search/index.do;jsessionid=AnZGsRt+zxqPOkSONZGqE4zA.node20?index=DATAGRID&query=&currentPage=1&countPerPage=10')

#얻어낸 데이터를 "html.parser"파서를 사용해서 파싱 후 soup변수에 저장
soup = BeautifulSoup(datas, "html.parser")

#print(soup.prettify()) # html문서의 들여쓰기 구조 형태로 내용 출력

#<div>태그중 class속성값이 "data-title"인(class="data-title") <div>태그만 찾아서 titles에 저장
titles = soup.find_all("div", "data-title")
#print(titles)


#titles의 내용에서 하위태그들 중에서 <a>태그의 내용과 <a>태그의 href속성값 만을 출력
for title in titles:
    for child in title.descendants:
        if child.name == 'a' :
            #print(child)
            print ('항목:{0} 링크:{1}\n'.format(child.string.strip(), child['href'][:-7]))

