f = open('myfile.txt','a')

f.write("\nThe show was just awesome.")
f.write("\n그 쇼는 그냥 기가 막히게 좋았다.")

f.close()

f = open('myfile.txt','r')
for line in f :
    print(line)

f.close()
