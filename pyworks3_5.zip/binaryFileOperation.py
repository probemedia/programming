f1 = open('protoss.jpg','rb')
f2 = open('protoss_copy.jpg','wb')

msg = f1.read(100)

while len(msg):
    f2.write(msg)
    msg = f1.read(100)

f1.close()
f2.close()

