def checkIfPrime(numberToCheck):
    for x in range(2,numberToCheck):
        if(numberToCheck%x == 0) :
            return False
        
    return True
    


num1 = int(input("input number : "))
if(checkIfPrime(num1)) :
    print("prime number")
else :
    print("non prime number")
