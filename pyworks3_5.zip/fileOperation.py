f = open('myfile.txt','r')
firstline = f.readline()
print(firstline)
f.close()
