import random
import prime

x = random.randrange(1,10)

print (x,' : ', end=' ')
print (prime.checkIfPrime2(x))
