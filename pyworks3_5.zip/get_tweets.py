# coding: utf-8 
import tweepy

consumer_key='rcZxplovUHvvsW0AIMu7YTc1t'
consumer_secret='6Pgax82h2wwourwa50JvF5rhbkTmaEa1ioz6ObP9TVRdCn730x'
access_token='197346094-Dru2fyJIq1I0UvVbZVjsKV4Zl0kJQLssdRwIj2Ou'
access_token_secret='CjEelh3slR22BNKivLVJBXsC6UDxZshNg3s6G4eUXVfnE'

auth = tweepy.OAuthHandler(consumer_key, consumer_secret)
auth.set_access_token(access_token, access_token_secret)

class listener(tweepy.streaming.StreamListener):
    def on_data(self, data):
        try:
            data = data.encode('utf-8')
            data = data.decode('unicode_escape')
        except:
            print('Error')

        print(data)
        return True
    def on_error(self, status):
        print('Error : ', status)

twitterStream = tweepy.Stream(auth, listener())
twitterStream.filter(track='파이썬') #track=['python', 'javascript', 'ruby']
