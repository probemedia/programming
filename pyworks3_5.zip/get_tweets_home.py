# coding: utf-8 
import tweepy

consumer_key='rcZxplovUHvvsW0AIMu7YTc1t'
consumer_secret='6Pgax82h2wwourwa50JvF5rhbkTmaEa1ioz6ObP9TVRdCn730x'
access_token='197346094-Dru2fyJIq1I0UvVbZVjsKV4Zl0kJQLssdRwIj2Ou'
access_token_secret='CjEelh3slR22BNKivLVJBXsC6UDxZshNg3s6G4eUXVfnE'

auth = tweepy.OAuthHandler(consumer_key, consumer_secret)
auth.set_access_token(access_token, access_token_secret)

api = tweepy.API(auth)

public_tweets = api.home_timeline()
for tweet in public_tweets:
    print (tweet.text)
