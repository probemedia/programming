# coding: utf-8
from urllib.request import urlopen
from bs4 import BeautifulSoup

#네이버 웹툰 메인의 데이터를 얻어냄
datas = urlopen('http://comic.naver.com/webtoon/weekday.nhn')

#얻어낸 데이터를 "html.parser"파서를 사용해서 파싱 후 soup변수에 저장
soup = BeautifulSoup(datas, "html.parser")

#print(soup.prettify()) # html문서의 들여쓰기 구조 형태로 내용 출력

#<a>태그중 속성값이 "title"인(class="title") <a>태그만 찾아서 titles에 저장
titles = soup.find_all("a", "title") #
#print(titles)

#titles의 내용에서 title속성값(title="xxx")과 href속성값(href="xxxx") 만을 출력
for title in titles:
    print ('title:{0:10s} link:{1:20s}\n'.format(title['title'], title['href']))

