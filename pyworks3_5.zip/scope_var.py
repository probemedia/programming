message1 = "global variable"

def myFunc():
    print("\nin function")
    print(message1)
    message2 = "local variable"
    print(message2)
    

myFunc()
print("\nout function")
print(message1)
print(message2)
