# coding: utf-8
import tweepy

consumer_key='your-consumer-key'
consumer_secret='your-consumer-secret'
access_token='your-access-token'
access_token_secret='your-access-token-secret'

auth = tweepy.OAuthHandler(consumer_key, consumer_secret)
auth.set_access_token(access_token, access_token_secret)

class listener(tweepy.streaming.StreamListener):
    def on_data(self, data):
        try:
            data = data.encode('utf-8')
            data = data.decode('unicode_escape')
        except:
            print('Error')

        print(data)
        return True
    def on_error(self, status):
        print('Error : ', status)

twitterStream = tweepy.Stream(auth, listener())
twitterStream.filter(track='파이썬') #track=['python', 'javascript', 'ruby']



