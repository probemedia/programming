userAge = [21,22,23,24,25]

print (userAge)
print (userAge[0])
print (userAge[-1])

userAge24 = userAge[2:4]
print(userAge24)

userAge.append(99)
print (userAge)

userAge.insert(1,5)
print (userAge)

del userAge[1]
print (userAge)

myList = [1,2,3,4,5,"Hello"]
print (myList)
