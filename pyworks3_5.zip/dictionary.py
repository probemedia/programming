myDic = {"key1":38, "key2":39}

print(myDic)

print(myDic["key1"])
