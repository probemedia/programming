# coding: utf-8

# Tkinter 라이브러리 임포트 : GUI프로그램을 위한 표준라이브러리
try:
    from tkinter import *  #파이썬 3
except ImportError:
    from Tkinter import *  #파이썬 2

# Tk 객체 인스턴스 생성
root = Tk()

# 라벨 생성
label = Label(root, text= 'Hello World')

# 라벨 배치
label.pack()

# root 표시
root.mainloop()
