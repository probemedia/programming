#!/usr/bin/env python
# coding: utf-8

# # 14장 웹 스크레이핑

# ## 14.1 웹 브라우저로 웹 사이트 접속하기

# ### 하나의 웹 사이트에 접속하기

# **[14장: 394페이지]**

# In[ ]:


import webbrowser

url = 'www.naver.com'
webbrowser.open(url)


# **[14장: 394~ 395페이지]**

# In[ ]:


import webbrowser

naver_search_url = "http://search.naver.com/search.naver?query="
search_word = '파이썬'
url = naver_search_url + search_word

webbrowser.open_new(url)


# **[14장: 395페이지]**

# In[ ]:


import webbrowser

google_url = "www.google.com/#q="
search_word = 'python'
url = google_url + search_word

webbrowser.open_new(url)


# ### 여러 개의 웹 사이트에 접속하기

# **[14장: 395페이지]**

# In[ ]:


import webbrowser

urls = ['www.naver.com', 'www.daum.net', 'www.google.com']

for url in urls:
    webbrowser.open_new(url)


# **[14장: 396페이지]**

# In[ ]:


import webbrowser

google_url = "www.google.com/#q="
search_words = ['python web scraping', 'python webbrowser']

for search_word in search_words:
    webbrowser.open_new(google_url + search_word)


# ## 14.2 웹 스크레이핑을 위한 기본 지식

# ### 데이터의 요청과 응답 과정

# ### HTML의 기본 구조

# **[14장: 399페이지]**

# In[ ]:


get_ipython().run_cell_magic('writefile', 'C:\\myPyCode\\HTML_example.html ', '<!doctype html>\n<html>\n <head>\n  <meta charset="utf-8">\n  <title>이것은 HTML 예제</title>\n </head>\n <body>\n  <h1>출간된 책 정보</h1>\n  <p id="book_title">이해가 쏙쏙 되는 파이썬</p>\n  <p id="author">홍길동</p>\n  <p id="publisher">위키북스 출판사</p>\n  <p id="year">2018</p>\n </body>\n</html>')
# get_ipython().run_cell_magic('writefile', 'D:\\pyworks_3_5_3th\\HTML_example.html ', '<!doctype html>\n<html>\n <head>\n  <meta charset="utf-8">\n  <title>이것은 HTML 예제</title>\n </head>\n <body>\n  <h1>출간된 책 정보</h1>\n  <p id="book_title">이해가 쏙쏙 되는 파이썬</p>\n  <p id="author">홍길동</p>\n  <p id="publisher">위키북스 출판사</p>\n  <p id="year">2018</p>\n </body>\n</html>')

# **[14장: 400페이지]**

# In[ ]:


get_ipython().run_cell_magic('writefile', 'C:/myPyCode/HTML_example2.html ', '<!doctype html>\n<html>\n <head>\n  <meta charset="utf-8">\n  <title>이것은 HTML 예제</title>\n </head>\n <body>\n  <h1>출간된 책 정보</h1>\n  <p>이해가 쏙쏙 되는 파이썬</p>\n  <p>홍길동</p>\n  <p>위키북스 출판사</p>\n  <p>2018</p>\n </body>\n</html>')
# get_ipython().run_cell_magic('writefile', 'D:/pyworks_3_5_3th/HTML_example2.html ', '<!doctype html>\n<html>\n <head>\n  <meta charset="utf-8">\n  <title>이것은 HTML 예제</title>\n </head>\n <body>\n  <h1>출간된 책 정보</h1>\n  <p>이해가 쏙쏙 되는 파이썬</p>\n  <p>홍길동</p>\n  <p>위키북스 출판사</p>\n  <p>2018</p>\n </body>\n</html>')

# ### 웹 페이지의 HTML 소스 갖고 오기

# **[14장: 402페이지]**

# In[ ]:


import requests

r = requests.get("https://www.google.co.kr")
r


# **[14장: 402페이지]**

# In[ ]:


r.text[0:100]


# **[14장: 403페이지]**

# In[ ]:


import requests

html = requests.get("https://www.google.co.kr").text
html[0:100]


# ### HTML 소스코드를 분석하고 처리하기

# #### 데이터 찾고 추출하기

# **[14장: 404페이지]**

# In[ ]:


from bs4 import BeautifulSoup

# 테스트용 html 코드
html = """<html><body><div><span>        <a href=http://www.naver.com>naver</a>        <a href=https://www.google.com>google</a>        <a href=http://www.daum.net/>daum</a>        </span></div></body></html>""" 

# BeautifulSoup를 이용해 HTML 소스를 파싱
soup = BeautifulSoup(html, 'lxml') 
soup


# **[14장: 404페이지]**

# In[ ]:


print(soup.prettify())


# **[14장: 405페이지]**

# In[ ]:


soup.find('a')


# **[14장: 405페이지]**

# In[ ]:


soup.find('a').get_text()


# **[14장: 405페이지]**

# In[ ]:


soup.find_all('a')


# **[14장: 406페이지]**

# In[ ]:


site_names = soup.find_all('a')
for site_name in site_names:
    print(site_name.get_text())


# **[14장: 406 ~ 407페이지]**

# In[ ]:


from bs4 import BeautifulSoup

# 테스트용 HTML 코드
html2 = """
<html>
 <head>
  <title>작품과 작가 모음</title>
 </head>
 <body>
  <h1>책 정보</h1>
  <p id="book_title">토지</p>
  <p id="author">박경리</p>

  <p id="book_title">태백산맥</p>
  <p id="author">조정래</p>

  <p id="book_title">감옥으로부터의 사색</p>
  <p id="author">신영복</p>
 </body>
</html>
"""

soup2 = BeautifulSoup(html2, "lxml")


# **[14장: 407페이지]**

# In[ ]:


soup2.title


# **[14장: 407페이지]**

# In[ ]:


soup2.body


# **[14장: 407페이지]**

# In[ ]:


soup2.body.h1


# **[14장: 408페이지]**

# In[ ]:


soup2.find_all('p')


# **[14장: 408페이지]**

# In[ ]:


soup2.find('p', {"id": "book_title"})


# **[14장: 408페이지]**

# In[ ]:


soup2.find('p', {"id": "author"})


# **[14장: 408 ~ 409페이지]**

# In[ ]:


soup2.find_all('p', {"id": "book_title"})


# In[ ]:


soup2.find_all('p', {"id": "author"})


# **[14장: 409페이지]**

# In[ ]:


from bs4 import BeautifulSoup

soup2 = BeautifulSoup(html2, "lxml")

book_titles = soup2.find_all('p', {"id": "book_title"})
authors = soup2.find_all('p', {"id": "author"})

for book_title, author in zip(book_titles, authors):
    print(book_title.get_text() + '/' + author.get_text())


# **[14장: 410페이지]**

# In[ ]:


soup2.select('body h1')


# **[14장: 410페이지]**

# In[ ]:


soup2.select('body p')


# **[14장: 410페이지]**

# In[ ]:


soup2.select('p')


# **[14장: 410 ~ 411페이지]**

# In[ ]:


soup2.select('p#book_title')


# In[ ]:


soup2.select('p#author')


# **[14장: 411페이지]**

# In[ ]:


get_ipython().run_cell_magic('writefile', 'C:/myPyCode/HTML_example_my_site.html ', '<!doctype html>\n<html>\n  <head>\n    <meta charset="utf-8">\n    <title>사이트 모음</title>\n  </head>\n  <body>\n    <p id="title"><b>자주 가는 사이트 모음</b></p>\n    <p id="contents">이곳은 자주 가는 사이트를 모아둔 곳입니다.</p>\n    <a href="http://www.naver.com" class="portal" id="naver">네이버</a> <br>\n    <a href="https://www.google.com" class="search" id="google">구글</a> <br>\n    <a href="http://www.daum.net" class="portal" id="danum">다음</a> <br>\n    <a href="http://www.nl.go.kr" class="government" id="nl">국립중앙도서관</a>\n  </body>\n</html>')
# get_ipython().run_cell_magic('writefile', 'D:/pyworks_3_5_3th/HTML_example_my_site.html ', '<!doctype html>\n<html>\n  <head>\n    <meta charset="utf-8">\n    <title>사이트 모음</title>\n  </head>\n  <body>\n    <p id="title"><b>자주 가는 사이트 모음</b></p>\n    <p id="contents">이곳은 자주 가는 사이트를 모아둔 곳입니다.</p>\n    <a href="http://www.naver.com" class="portal" id="naver">네이버</a> <br>\n    <a href="https://www.google.com" class="search" id="google">구글</a> <br>\n    <a href="http://www.daum.net" class="portal" id="danum">다음</a> <br>\n    <a href="http://www.nl.go.kr" class="government" id="nl">국립중앙도서관</a>\n  </body>\n</html>')

# **[14장: 412페이지]**

# In[ ]:


f = open('HTML_example_my_site.html', encoding='utf-8')

html3 = f.read()
f.close()

soup3 = BeautifulSoup(html3, "lxml")


# **[14장: 412페이지]**

# In[ ]:


soup3.select('a')


# **[14장: 412페이지]**

# In[ ]:


soup3.select('a.portal')


# #### 웹 브라우저의 요소 검사

# **[14장: 414페이지]**

# In[ ]:


soup3.select('a')


# **[14장: 414페이지]**

# In[ ]:


soup3.select('a.portal')


# **[14장: 415페이지]**

# In[ ]:


soup3.select('a#naver')


# #### 줄 바꿈으로 가독성 높이기

# **[14장: 415페이지]**

# In[ ]:


get_ipython().run_cell_magic('writefile', 'C:/myPyCode/br_example_constitution.html', '<!doctype html>\n<html>\n  <head>\n    <meta charset="utf-8">\n    <title>줄 바꿈 테스트 예제</title>\n  </head>\n  <body>\n  <p id="title"><b>대한민국헌법</b></p>\n  <p id="content">제1조 <br/>①대한민국은 민주공화국이다.<br/>②대한민국의 주권은 국민에게 있고, 모든 권력은 국민으로부터 나온다.</p>\n  <p id="content">제2조 <br/>①대한민국의 국민이 되는 요건은 법률로 정한다.<br/>②국가는 법률이 정하는 바에 의하여 재외국민을 보호할 의무를 진다.</p>\n  </body>\n</html>')
# get_ipython().run_cell_magic('writefile', 'D:/pyworks_3_5_3th/br_example_constitution.html', '<!doctype html>\n<html>\n  <head>\n    <meta charset="utf-8">\n    <title>줄 바꿈 테스트 예제</title>\n  </head>\n  <body>\n  <p id="title"><b>대한민국헌법</b></p>\n  <p id="content">제1조 <br/>①대한민국은 민주공화국이다.<br/>②대한민국의 주권은 국민에게 있고, 모든 권력은 국민으로부터 나온다.</p>\n  <p id="content">제2조 <br/>①대한민국의 국민이 되는 요건은 법률로 정한다.<br/>②국가는 법률이 정하는 바에 의하여 재외국민을 보호할 의무를 진다.</p>\n  </body>\n</html>')

# **[14장: 416페이지]**

# In[ ]:


from bs4 import BeautifulSoup

f = open('br_example_constitution.html', encoding='utf-8')

html_source = f.read()
f.close()

soup = BeautifulSoup(html_source, "lxml")

title = soup.find('p', {"id": "title"})
contents = soup.find_all('p', {"id": "content"})

print(title.get_text())
for content in contents:
    print(content.get_text())


# **[14장: 417페이지]**

# In[ ]:


html1 = '<p id="content">제1조 <br/>①대한민국은 민주공화국이다.<br/>②대한민국의 주권은 국민에게 있고, 모든 권력은 국민으로부터 나온다.</p>'

soup1 = BeautifulSoup(html1, "lxml")

print("==> 태그 p로 찾은 요소")
content1 = soup1.find('p', {"id": "content"})
print(content1)

br_content = content1.find("br")
print("==> 결과에서 태그 br로 찾은 요소:", br_content)

br_content.replace_with("\n")
print("==> 태그 br을 개행문자로 바꾼 결과")
print(content1)


# **[14장: 418페이지]**

# In[ ]:


soup2 = BeautifulSoup(html1, "lxml")
content2 = soup2.find('p', {"id": "content"})

br_contents = content2.find_all("br")
for br_content in br_contents:
    br_content.replace_with("\n")
print(content2)


# **[14장: 418페이지]**

# In[ ]:


def replace_newline(soup_html):
    br_to_newlines = soup_html.find_all("br")
    for br_to_newline in br_to_newlines:
        br_to_newline.replace_with("\n")
    return soup_html


# **[14장: 418페이지]**

# In[ ]:


soup2 = BeautifulSoup(html1, "lxml")
content2 = soup2.find('p', {"id": "content"})
content3 = replace_newline(content2)
print(content3.get_text())


# **[14장: 419페이지]**

# In[ ]:


from bs4 import BeautifulSoup

soup = BeautifulSoup(html_source, "lxml")

title = soup.find('p', {"id": "title"})
contents = soup.find_all('p', {"id": "content"})

print(title.get_text(), '\n')

for content in contents:
    content1 = replace_newline(content)
    print(content1.get_text(), '\n')


# ## 14.3 웹 사이트에서 데이터 가져오기

# ### 웹 스크레이핑 시 주의 사항

# ### 순위 데이터를 가져오기


# #### 웹 사이트 순위

# **[14장: 423페이지]**

# In[ ]:


import requests  
from bs4 import BeautifulSoup 

url = "https://www.alexa.com/topsites/countries/KR"

html_website_ranking = requests.get(url).text
soup_website_ranking = BeautifulSoup(html_website_ranking, "lxml")

# p 태그의 요소 안에서 a 태그의 요소를 찾음
website_ranking = soup_website_ranking.select('p a')


# **[14장: 423페이지]**

# In[ ]:


website_ranking[0:6]


# **[14장: 424페이지]**

# In[ ]:


website_ranking[0].get_text()


# **[14장: 424페이지]**

# In[ ]:


website_ranking_address = [website_ranking_element.get_text()
                           for website_ranking_element in website_ranking]


# **[14장: 424페이지]**

# In[ ]:


website_ranking_address[0:6]


# **[14장: 424페이지]**

# In[ ]:


import requests  
from bs4 import BeautifulSoup 

url = "https://www.alexa.com/topsites/countries/KR"

html_website_ranking = requests.get(url).text
soup_website_ranking = BeautifulSoup(html_website_ranking, "lxml")

# p 태그의 요소 안에서 a 태그의 요소를 찾음
website_ranking = soup_website_ranking.select('p a')
website_ranking_address = [website_ranking_element.get_text()
                           for website_ranking_element in website_ranking]

print("[Top Sites in South Korea]")
for k in range(6):
    print("{0}: {1}".format(k+1, website_ranking_address[k]))


# **[14장: 425페이지]**

# In[ ]:


import pandas as pd

website_ranking_dict = {'Website': website_ranking_address}
df = pd.DataFrame(website_ranking_dict, columns=['Website'],
                  index=range(1, len(website_ranking_address) + 1))
df[0:6]


# #### 주간 음악 순위

# **[14장: 429페이지]**

# In[ ]:


import requests
from bs4 import BeautifulSoup

url = "http://music.naver.com/listen/history/index.nhn?type=TOTAL&year=2019&month=12&week=1"
html_music = requests.get(url).text
soup_music = BeautifulSoup(html_music, "lxml")

# a 태그의 요소 중에서 class 속성값이 "_title" 인 것을 찾고
# 그 안에서 span 태그의 요소 중에서 class 속성값이 "ellipsis"인 요소를 추출
titles = soup_music.select('a._title span.ellipsis')
titles[0:7]


# **[14장: 429페이지]**

# In[ ]:


music_titles = [title.get_text() for title in titles]


# **[14장: 429페이지]**

# In[ ]:


music_titles[0:7]


# **[14장: 431페이지]**

# In[ ]:


# a 태그의 요소 중에서 class 속성값이 "_artist" 인 것을 찾고
# 그 안에서 span 태그의 요소 중에서 class 속성값이 "ellipsis"인 요소를 추출
artists = soup_music.select('a._artist span.ellipsis') 
artists[0].get_text()


# **[14장: 431페이지]**

# In[ ]:


artists[0].get_text().strip()


# **[14장: 431페이지]**

# In[ ]:


music_artists = [artist.get_text().strip() for artist in artists]


# **[14장: 431페이지]**

# In[ ]:


music_artists[0:7]


# **[14장: 433페이지]**

# In[ ]:


# td 태그의 요소 중에서 class 속성값이 "_artist" 인 것을 찾고
# 그 안에서 a 태그의 요소를 추출
artists = soup_music.select('td._artist a')


# **[14장: 433페이지]**

# In[ ]:


artists[0]


# In[ ]:


artists[4]


# **[14장: 433페이지]**

# In[ ]:


artists[0].get_text().strip()


# In[ ]:


artists[4].get_text().strip()


# **[14장: 433페이지]**

# In[ ]:


music_artists = [artist.get_text().strip() for artist in artists]


# **[14장: 434페이지]**

# In[ ]:


music_artists[0:7]


# **[14장: 434 ~ 435페이지]**

# In[ ]:


import requests
from bs4 import BeautifulSoup

url = "http://music.naver.com/listen/history/index.nhn?type=DOMESTIC&year=2019&month=12&week=1&page=1"    
# url = "http://music.naver.com/listen/history/index.nhn?type=DOMESTIC&year=2017&month=12&week=1&page=2"
# url = "http://music.naver.com/listen/top100.nhn?domain=TOTAL&page=1"

html_music = requests.get(url).text
soup_music = BeautifulSoup(html_music, "lxml")

titles = soup_music.select('a._title span.ellipsis')
artists = soup_music.select('td._artist a')

music_titles = [title.get_text() for title in titles]
music_artists = [artist.get_text().strip() for artist in artists]

for k in range(7):
    print("{0}: {1} / {2}".format(k+1, music_titles[k], music_artists[k]))


# **[14장: 435페이지]**

# In[ ]:


music_titles_artists = {}
order = 0

for (music_title, music_artist) in zip(music_titles, music_artists):
    order = order + 1
    music_titles_artists[order] = [music_title, music_artist]


# **[14장: 436페이지]**

# In[ ]:


music_titles_artists[1]


# In[ ]:


music_titles_artists[2]


# **[14장: 436 ~ 437페이지]**

# In[ ]:


import requests
from bs4 import BeautifulSoup
import glob
    
naver_music_url = "http://music.naver.com/listen/history/index.nhn?type=DOMESTIC&year=2019&month=12&week=1&page="


# 네이버 music 주소를 입력하면 노래 제목과 아티스트를 반환
def naver_music(url):
    html_music = requests.get(url).text
    soup_music = BeautifulSoup(html_music, "lxml")

    titles = soup_music.select('a._title span.ellipsis')
    artists = soup_music.select('td._artist a')

    music_titles = [title.get_text() for title in titles]
    music_artists = [artist.get_text().strip() for artist in artists]

    return music_titles, music_artists


# 노래 제목과 아티스트를 저장할 파일 이름을 폴더와 함께 지정
file_name = 'data/NaverMusicTop100.txt'

f = open(file_name, 'w')  # 파일 열기

# 각 page에는 50개의 노래 제목과 아티스트가 추출됨
for page in range(2):
    naver_music_url_page = naver_music_url + str(page+1)  # page URL
    naver_music_titles, naver_music_artists = naver_music(naver_music_url_page)

    # 추출된 노래 제목과 아티스트를 파일에 저장
    for k in range(len(naver_music_titles)):
        f.write("{0:2d}: {1}/{2}\n".format(page*50 + k+1,
                naver_music_titles[k],  naver_music_artists[k]))

f.close()  # 파일 닫기

glob.glob(file_name)  # 생성된 파일 확인


# ### 웹 페이지에서 이미지 가져오기

# #### 하나의 이미지 내려받기

# **[14장: 439페이지]**

# In[ ]:


import requests

url = 'https://www.python.org/static/img/python-logo.png'
html_image = requests.get(url)
html_image.close


# **[14장: 440페이지]**

# In[ ]:


import os

image_file_name = os.path.basename(url)
image_file_name


# **[14장: 441페이지]**

# In[ ]:


folder = 'C:/myPyCode/download'

if not os.path.exists(folder):
    os.makedirs(folder)

# %%
folder = 'D:\\pyworks_3_5_3th\\download'

if not os.path.exists(folder):
    os.makedirs(folder)
# **[14장: 441페이지]**

# In[ ]:


image_path = os.path.join(folder, image_file_name)
image_path


# **[14장: 441페이지]**

# In[ ]:


imageFile = open(image_path, 'wb')  # 빈 파일 만들기


# **[14장: 442페이지]**

# In[ ]:


# 빈 파일에 이미지 데이터를 100000 바이트씩 나눠서 내려받고 파일에 순차적으로 저장
chunk_size = 1000000
for chunk in html_image.iter_content(chunk_size):
    imageFile.write(chunk)
imageFile.close()


# **[14장: 442페이지]**

# In[ ]:


os.listdir(folder)


# **[14장: 442 ~ 443페이지]**

# In[ ]:


import requests  
import os

url = 'https://www.python.org/static/img/python-logo.png'
html_image = requests.get(url)
image_file_name = os.path.basename(url)

# folder = 'C:/myPyCode/download'
folder = 'D:\\pyworks_3_5_3th\\download'

if not os.path.exists(folder):
    os.makedirs(folder)

image_path = os.path.join(folder, image_file_name)

imageFile = open(image_path, 'wb')
# 이미지 데이터를 100000 바이트씩 나눠서 저장
chunk_size = 1000000
for chunk in html_image.iter_content(chunk_size):
    imageFile.write(chunk)
imageFile.close()


# #### 여러 이미지 내려받기

# **[14장: 446페이지]**

# In[ ]:


import requests
from bs4 import BeautifulSoup

URL = 'https://pixabay.com/ko/photos/?order=popular&cat=animals'

html_pixabay_image = requests.get(URL).text
soup_pixabay_image = BeautifulSoup(html_pixabay_image, "lxml")
pixabay_image_elements = soup_pixabay_image.select('img')
pixabay_image_elements[0:3]


# **[14장: 446페이지]**

# In[ ]:


pixabay_image_url = pixabay_image_elements[0].get('src')
pixabay_image_url


# **[14장: 447페이지]**

# In[ ]:


html_image = requests.get(pixabay_image_url)

# folder = "C:/myPyCode/download"
folder = "D:\\pyworks_3_5_3th\\download"
# os.path.basename(URL)는 웹사이트나 폴더가 포함된 파일명에서 파일명만 분리하는 방법
imageFile = open(os.path.join(folder,
                              os.path.basename(pixabay_image_url)), 'wb')

# 이미지 데이터를 100000 바이트씩 나눠서 저장하는 방법
chunk_size = 1000000
for chunk in html_image.iter_content(chunk_size):
    imageFile.write(chunk)
imageFile.close()


# **[14장: 447 ~ 449페이지]**

# In[ ]:


import requests  
from bs4 import BeautifulSoup 
import os


# URL(주소)에서 이미지 주소 추출
def get_image_url(url):
    html_image_url = requests.get(url).text
    soup_image_url = BeautifulSoup(html_image_url, "lxml")
    image_elements = soup_image_url.select('img')
    if(image_elements != None):
        image_urls = []
        for image_element in image_elements:
            image_urls.append(image_element.get('src'))
        return image_urls
    else:
        return None


# 폴더를 지정해 이미지 주소에서 이미지 내려받기
def download_image(img_folder, img_url):
    if(img_url != None):
        html_image = requests.get(img_url)
        # os.path.basename(URL)는 웹사이트나 폴더가 포함된 파일명에서 파일명만 분리
        imageFile = open(os.path.join(img_folder,
                                      os.path.basename(img_url)), 'wb')

        chunk_size = 1000000  # 이미지 데이터를 100000 바이트씩 나눠서 저장
        for chunk in html_image.iter_content(chunk_size):
            imageFile.write(chunk)
            imageFile.close()
        print("이미지 파일명: '{0}'. 내려받기 완료!".format(os.path.basename(img_url))) 
    else:
        print("내려받을 이미지가 없습니다.")


# 웹 사이트의 주소 지정
pixabay_url = 'https://pixabay.com/ko/photos/?order=popular&cat=animals'
# pixabay_url='https://pixabay.com/ko/photos/?order=popular&cat=animals&pagi=2'

# figure_folder = "C:/myPyCode/download" # 이미지를 내려받을 폴더 지정
figure_folder = "D:\\pyworks_3_5_3th\\download"
pixabay_image_urls = get_image_url(pixabay_url)  # 이미지 파일의 주소 가져오기

num_of_download_image = 7  # 내려받을 이미지 개수 지정
# num_of_download_image = len(pixabay_image_urls)

for k in range(num_of_download_image):
    download_image(figure_folder, pixabay_image_urls[k])
print("================================")
print("선택한 모든 이미지 내려받기 완료!")

# %%
import requests  
from bs4 import BeautifulSoup 
import os


# URL(주소)에서 이미지 주소 추출
def get_image_url(url):
    html_image_url = requests.get(url).text
    soup_image_url = BeautifulSoup(html_image_url, "lxml")
    image_elements = soup_image_url.select('img')
    if(image_elements):
        image_urls = []
        for image_element in image_elements:
            image_urls.append(image_element.get('src'))
        return image_urls
    else:
        return None


# 폴더를 지정해 이미지 주소에서 이미지 내려받기
def download_image(img_folder, img_url):
    if(img_url):
        html_image = requests.get(img_url)
        # os.path.basename(URL)는 웹사이트나 폴더가 포함된 파일명에서 파일명만 분리
        imageFile = open(os.path.join(img_folder,
                                      os.path.basename(img_url)), 'wb')

        chunk_size = 1000000  # 이미지 데이터를 100000 바이트씩 나눠서 저장
        for chunk in html_image.iter_content(chunk_size):
            imageFile.write(chunk)
            imageFile.close()
        print("이미지 파일명: '{0}'. 내려받기 완료!".format(os.path.basename(img_url))) 
    else:
        print("내려받을 이미지가 없습니다.")


# 웹 사이트의 주소 지정
pixabay_url = 'https://pixabay.com/ko/photos/?order=popular&cat=animals'
# pixabay_url='https://pixabay.com/ko/photos/?order=popular&cat=animals&pagi=2'

# figure_folder = "C:/myPyCode/download" # 이미지를 내려받을 폴더 지정
figure_folder = "D:\\pyworks_3_5_3th\\download"
pixabay_image_urls = get_image_url(pixabay_url)  # 이미지 파일의 주소 가져오기

num_of_download_image = 7  # 내려받을 이미지 개수 지정
# num_of_download_image = len(pixabay_image_urls)

for k in range(num_of_download_image):
    download_image(figure_folder, pixabay_image_urls[k])
print("================================")
print("선택한 모든 이미지 내려받기 완료!")


# **[14장: 450페이지]**

# In[ ]:


num_of_download_image = len(pixabay_image_urls)
num_of_download_image


# ## 14.4 정리
