#!/usr/bin/env python
# coding: utf-8

# # 6장 입력과 출력

# ## 6.1 화면 출력

# ### 기본 출력

# **[6장: 95페이지]**

# In[ ]:


print("Hello Python!!")


# **[6장: 96페이지]**

# In[ ]:


print("Best", "python", "book")


# **[6장: 96페이지]**

# In[ ]:


print("Best", "python", "book", sep="-:*:-")


# **[6장: 96페이지]**

# In[ ]:


print("abcd" + "efg")


# **[6장: 96페이지]**

# In[ ]:


print("Best", "python", "book" + ":", "This book")


# **[6장: 96페이지]**

# In[ ]:


x = 10
print(x)


# **[6장: 97페이지]**

# In[ ]:


name = "James"
ID_num = 789
print("Name:", name + ",", "ID Number:", ID_num)


# **[6장: 97페이지]**

# In[ ]:


print("James is my friend.\nHe is Korean.")


# **[6장: 97페이지]**

# In[ ]:


print("James is my friend.\n\nHe is Korean.")


# **[6장: 97페이지]**

# In[ ]:


print("Welcome to ")
print("python!")


# **[6장: 98페이지]**

# In[ ]:


print("Welcome to ", end="")
print("python!")


# ### 형식 지정 출력

# #### 나머지 연산자(%)를 이용한 형식 및 위치 지정

# **[6장: 99페이지]**

# In[ ]:


name = "광재"
print("%s는 나의 친구입니다." % name)


# **[6장: 99페이지]**

# In[ ]:


r = 3  # 변수 r에 정수 데이터 할당
PI = 3.14159265358979  # 변수 PI에 실수 데이터 할당
print("반지름: %d, 원주율: %f" % (r, PI))  # 지정된 위치에 데이터 출력


# #### 형식 지정 문자열에서 출력 위치 지정


# **[6장: 100페이지]**

# In[ ]:


animal_0 = "cat"
animal_1 = "dog"
animal_2 = "fox"

print("Animal: {0}".format(animal_0))
print("Animal: {0},{1},{2}".format(animal_0, animal_1, animal_2))


# **[6장: 100페이지]**

# In[ ]:


print("Animal: {1},{2},{0}".format(animal_0, animal_1, animal_2))


# **[6장: 100페이지]**

# In[ ]:


print("Animal: {0},{2}".format(animal_0, animal_1, animal_2))


# **[6장: 101페이지]**

# In[ ]:


print("Animal: {}, {}, {}".format(animal_0, animal_1, animal_2))


# **[6장: 101페이지]**

# In[ ]:


name = "Tomas"
age = 10
a = 0.1234567890123456789
fmt_string = "String: {0}. Integer Number: {1}. Floating Number: {2}"
print(fmt_string.format(name, age, a))


# #### 형식 지정 문자열에서 숫자 출력 형식 지정

# **[6장: 101페이지]**

# In[ ]:


a = 0.1234567890123456789
print("{0:.2f}, {0:.5f}".format(a))


# ## 6.1 키보드 입력

# **[6장: 103페이지]**

# In[ ]:


yourName = input("당신의 이름은? ")
print("당신은 {}이군요.".format(yourName))


# **[6장: 103페이지]**

# In[ ]:


num = input("숫자를 입력하세요: ")
print("당신이 입력한 숫자는 {}입니다.".format(num))


# **[6장: 103페이지]**

# In[ ]:


a = input("정사각형 한 변의 길이는?: ")
area = int(a) ** 2
print("정사각형의 넓이: {}".format(area))


# **[6장: 103페이지]**

# In[ ]:


b = input("정사각형 한 변의 길이는?:")
area = float(b) ** 2
print("정사각형의 넓이: {}".format(area))


# **[6장: 104페이지]**

# In[ ]:


c = input("정사각형 한 변의 길이는?: ")
area = float(c) ** 2
print("정사각형의 넓이: {}".format(area))


# ## 6.3 파일 읽고 쓰기

# ### 파일 열기


# ### 파일 쓰기

# **[6장: 106페이지]**

# In[ ]:


# cd C:\myPyCode


# **[6장: 106페이지]**

# In[ ]:


f = open('data/myFile.txt', 'w')           # (1)'myFile.txt' 파일 쓰기 모드로 열기
f.write('This is my first file.')     # (2) 연 파일에 문자열 쓰기
f.close()                             # (3) 파일 닫기


# **[6장: 106페이지]**

# In[ ]:

# ipython 창에서 할 것
get_ipython().system('type myFile.txt')
# get_ipython().system('type D:\pyworks_3_5_3th\data\myFile.txt')

# ### 파일 읽기

# **[6장: 107페이지]**

# In[ ]:


f = open('data/myFile.txt', 'r')  # (1)'myFile.txt' 파일 읽기 모드로 열기
file_text = f.read()        # (2) 파일 내용 읽은 후에 변수에 저장
f.close()                   # (3) 파일 닫기

print(file_text)            # 변수에 저장된 내용 출력


# ## 6.4 반복문을 이용해 파일 읽고 쓰기

# ### 파일에 문자열 한 줄씩 쓰기

# **[6장: 107페이지]**

# In[ ]:


f = open('data/Two_times_table.txt', 'w')  # (1)파일을 쓰기 모드로 열기
for num in range(1, 6):              # (2) for문: num이 1~5까지 반복
    format_string = "2 x {0} = {1}\n".format(num, 2*num)  # 저장할 문자열 생성
    f.write(format_string)          # (3) 파일에 문자열 저장
f.close()                           # (4) 파일 닫기


# **[6장: 108페이지]**

# In[ ]:


get_ipython().system('type Two_times_table.txt')
# get_ipython().system('type D:\pyworks_3_5_3th\data\Two_times_table.txt')

# ### 파일에서 문자열 한 줄씩 읽기

# #### readline()

# **[6장: 109페이지]**

# In[ ]:


f = open("data/Two_times_table.txt")   # 파일을 읽기 모드로 열기
line1 = f.readline()              # 한 줄씩 문자열을 읽기
line2 = f.readline()
f.close()                         # 파일 닫기
print(line1, end="")              # 한 줄씩 문자열 출력(줄 바꿈 안 함)
print(line2, end="")


# **[6장: 109페이지]**

# In[ ]:


f = open("data/Two_times_table.txt")  # 파일을 읽기 모드로 열기
line = f.readline()              # 문자열 한 줄 읽기
while line:  # line이 공백인지 검사해서 반복 여부 결정
    print(line, end="")        # 문자열 한 줄 출력(줄 바꿈 안 함)
    line = f.readline()          # 문자열 한 줄 읽기
f.close()  # 파일 닫기


# #### readlines()

# **[6장: 110페이지]**

# In[ ]:


f = open("data/Two_times_table.txt")  # (1) 파일을 읽기 모드로 열기
lines = f.readlines()           # (2) 파일 전체 읽기(리스트로 반환)
f.close()                       # (3) 파일 닫기

print(lines)                    # 리스트 변수 내용 출력


# **[6장: 110페이지]**

# In[ ]:


f = open("data/Two_times_table.txt")  # 파일을 읽기 모드로 열기
lines = f.readlines()            # 파일 전체 읽기(리스트로 반환)
f.close()                        # 파일 닫기
for line in lines:              # 리스트를 <반복 범위>로 지정
    print(line, end="")          # 리스트 항목을 출력(줄 바꿈 안 함)


# **[6장: 111페이지]**

# In[ ]:


f = open("data/Two_times_table.txt")  # 파일을 읽기 모드로 열기
for line in f.readlines():      # 파일 전체를 읽고, 리스트 항목을 line에 할당
    print(line, end="")          # 리스트 항목을 출력(줄 바꿈 안 함)
f.close()


# **[6장: 111페이지]**

# In[ ]:


f = open("data/Two_times_table.txt")  # 파일을 읽기 모드로 열기
for line in f:                 # 파일 전체를 읽고, 리스트 항목을 line에 할당
    print(line, end="")         # line의 내용 출력(줄 바꿈 안 함)
f.close()                       # 파일 닫기


# ## 6.5 with 문을 활용해 파일 읽고 쓰기

# ### with 문의 구조

# **[6장: 112페이지]**

# In[ ]:


f = open('data/myTextFile.txt', 'w')   # (1) 파일 열기
f.write('File write/read test.')  # (2) 파일 쓰기
f.close()                         # (3) 파일 닫기


# **[6장: 112페이지]**

# In[ ]:


f = open('data/myTextFile.txt', 'r')  # (1) 파일 열기
test = f.read()  # (2) 파일 읽기
f.close()   # (3) 파일 닫기
print(test)


# ### with문의 활용

# **[6장: 113페이지]**

# In[ ]:


with open('data/myTextFile2.txt', 'w') as f:  # (1) 파일 열기
    f.write('File read/write test2: line1\n')        # (2) 파일 쓰기
    f.write('File read/write test2: line2\n')
    f.write('File read/write test2: line3\n')


# **[6장: 113페이지]**

# In[ ]:


with open('data/myTextFile2.txt') as f:  # (1) 파일 열기
    file_string = f.read()                      # (2) 파일 읽기
    print(file_string)


# **[6장: 113페이지]**

# In[ ]:


with open('data/myTextFile3.txt', 'w') as f:  # 파일을 쓰기 모드로 열기
    for num in range(1, 6):             # for문에서 num이 1~5까지 반복
        format_string = "3 x {0} = {1}\n".format(num, 3*num)  # 문자열 생성
        f.write(format_string)         # 파일에 문자열 쓰기


# **[6장: 114페이지]**

# In[ ]:


with open('data/myTextFile3.txt', 'r') as f:  # 파일을 읽기 모드로 열기
    for line in f:           # 파일 전체를 읽고 리스트 항목을 line에 할당
        print(line, end="")  # line에 할당된 문자열 출력(줄 바꿈 안 함)


# # 6.6 정리
