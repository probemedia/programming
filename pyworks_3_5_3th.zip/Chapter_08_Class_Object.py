#!/usr/bin/env python
# coding: utf-8

# # 8장 객체와 클래스

# ## 8.1 클래스 선언과 객체 생성
# 
# ### 객체란?

# ### 클래스 선언

# ### 객체 생성 및 활용

# **[8장: 137페이지]**

# In[ ]:


class Bicycle():  # 클래스 선언
    pass


# **[8장: 138페이지]**

# In[ ]:


my_bicycle = Bicycle()


# **[8장: 138페이지]**

# In[ ]:


my_bicycle


# **[8장: 138페이지]**

# In[ ]:


my_bicycle.wheel_size = 26
my_bicycle.color = 'black'


# **[8장: 139페이지]**

# In[ ]:


print("바퀴 크기:", my_bicycle.wheel_size)  # 객체의 속성 출력
print("색상:", my_bicycle.color)


# **[8장: 139페이지]**

# In[ ]:


class Bicycle():

    def move(self, speed):
        print("자전거: 시속 {0}킬로미터로 전진".format(speed))

    def turn(self, direction):
        print("자전거: {0}회전".format(direction))

    def stop(self):
        print("자전거({0}, {1}): 정지 ".format(self.wheel_size, self.color))


# **[8장: 140페이지]**

# In[ ]:


my_bicycle = Bicycle()  # Bicycle 클래스의 인스턴스인 my_bicycle 객체 생성

my_bicycle.wheel_size = 26  # 객체의 속성 설정
my_bicycle.color = 'black'

my_bicycle.move(30)  # 객체의 메서드 호출
my_bicycle.turn('좌')
my_bicycle.stop()


# **[8장: 141페이지]**

# In[ ]:


bicycle1 = Bicycle()  # Bicycle 클래스의 인스턴스인 bicycle1 객체 생성

bicycle1.wheel_size = 27  # 객체의 속성 설정
bicycle1.color = 'red'

bicycle1.move(20)
bicycle1.turn('좌')
bicycle1.stop()


# In[ ]:


bicycle2 = Bicycle()  # Bicycle 클래스의 인스턴스인 bicycle2 객체 생성

bicycle2.wheel_size = 24  # 객체의 속성 설정
bicycle2.color = 'blue'

bicycle2.move(15)
bicycle2.turn('우')
bicycle2.stop()


# ### 객체 초기화

# **[8장: 142페이지]**

# In[ ]:


class Bicycle():

    def __init__(self, wheel_size, color):
        self.wheel_size = wheel_size
        self.color = color

    def move(self, speed):
        print("자전거: 시속 {0}킬로미터로 전진".format(speed))

    def turn(self, direction):
        print("자전거: {0}회전".format(direction))

    def stop(self):
        print("자전거({0}, {1}): 정지 ".format(self.wheel_size, self.color))


# **[8장: 142페이지]**

# In[ ]:


my_bicycle = Bicycle(26, 'black')  # 객체 생성과 동시에 속성값을 지정.

my_bicycle.move(30)  # 객체 메서드 호출
my_bicycle.turn('좌')
my_bicycle.stop()


# ## 8.2 클래스를 구성하는 변수와 함수

# ### 클래스에서 사용하는 변수

# **[8장: 143페이지]**

# In[ ]:


class Car():
    instance_count = 0  # 클래스 변수 생성 및 초기화

    def __init__(self, size, color):
        self.size = size    # 인스턴스 변수 생성 및 초기화
        self.color = color  # 인스턴스 변수 생성 및 초기화
        Car.instance_count = Car.instance_count + 1  # 클래스 변수 이용
        print("자동차 객체의 수: {0}".format(Car.instance_count))

    def move(self):
        print("자동차({0} & {1})가 움직입니다.".format(self.size, self.color))


# **[8장: 144페이지]**

# In[ ]:


car1 = Car('small', 'white')
car2 = Car('big', 'black')


# **[8장: 144페이지]**

# In[ ]:


print("Car 클래스의 총 인스턴스 개수:{}".format(Car.instance_count))


# **[8장: 144페이지]**

# In[ ]:


print("Car 클래스의 총 인스턴스 개수:{}".format(car1.instance_count))
print("Car 클래스의 총 인스턴스 개수:{}".format(car2.instance_count))


# **[8장: 144페이지]**

# In[ ]:


car1.move()
car2.move()


# **[8장: 145페이지]**

# In[ ]:


class Car2():
    count = 0  # 클래스 변수 생성 및 초기화

    def __init__(self, size, num):
        self.size = size    # 인스턴스 변수 생성 및 초기화
        self.count = num  # 인스턴스 변수 생성 및 초기화
        Car2.count = Car2.count + 1  # 클래스 변수 이용
        print("자동차 객체의 수: Car2.count = {0}".format(Car2.count))
        print("인스턴스 변수 초기화: self.count = {0}".format(self.count))

    def move(self):
        print("자동차({0} & {1})가 움직입니다.".format(self.size, self.count))


# **[8장: 145페이지]**

# In[ ]:


car1 = Car2("big", 20)
car2 = Car2("small", 30)


# ### 클래스에서 사용하는 함수

# #### 인스턴스 메서드

# **[8장: 146 ~ 147페이지]**

# In[ ]:


# Car 클래스 선언
class Car():
    instance_count = 0  # 클래스 변수 생성 및 초기화

    # 초기화 함수(인스턴스 메서드)
    def __init__(self, size, color):
        self.size = size    # 인스턴스 변수 생성 및 초기화
        self.color = color  # 인스턴스 변수 생성 및 초기화
        Car.instance_count = Car.instance_count + 1  # 클래스 변수 이용
        print("자동차 객체의 수: {0}".format(Car.instance_count))

    # 인스턴스 메서드
    def move(self, speed):
        self.speed = speed  # 인스턴스 변수 생성
        print("자동차({0} & {1})가 ".format(self.size, self.color), end='')
        print("시속 {0}킬로미터로 전진".format(self.speed))

    # 인스턴스 메서드
    def auto_cruise(self):
        print("자율 주행 모드")
        self.move(self.speed)  # move() 함수의 인자로 인스턴스 변수를 입력


# **[8장: 147페이지]**

# In[ ]:


car1 = Car("small", "red")  # 객체 생성 (car1)
car2 = Car("big", "green")  # 객체 생성 (car2)

car1.move(80)  # 객체(car1)의 move() 메서드 호출
car2.move(100)  # 객체(car2)의 move() 메서드 호출

car1.auto_cruise()  # 객체(car1)의 auto_cruise() 메서드 호출
car2.auto_cruise()  # 객체(car2)의 auto_cruise() 메서드 호출


# #### 정적 메서드

# **[8장: 148 ~ 149페이지]**

# In[ ]:


# Car 클래스 선언
class Car():

    # def __init__(self, size, color): => 앞의 코드 활용
    # def move(self, speed): => 앞의 코드 활용
    # def auto_cruise(self): => 앞의 코드 활용

    # 정적 메서드
    @staticmethod
    def check_type(model_code):
        if(model_code >= 20):
            print("이 자동차는 전기차입니다.")
        elif(10 <= model_code < 20):
            print("이 자동차는 가솔린차입니다.")
        else:
            print("이 자동차는 디젤차입니다.")


# **[8장: 149페이지]**

# In[ ]:


Car.check_type(25)
Car.check_type(2)


# #### 클래스 메서드

# **[8장: 150페이지]**

# In[ ]:


# Car 클래스 선언
class Car():
    instance_count = 0  # 클래스 변수

    # 초기화 함수(인스턴스 메서드)
    def __init__(self, size, color):
        self.size = size    # 인스턴스 변수
        self.color = color  # 인스턴스 변수
        Car.instance_count = Car.instance_count + 1

    # def move(self, speed): => 앞의 코드 활용
    # def auto_cruise(self): => 앞의 코드 활용
    # @staticmethod
    # def check_type(model_code): => 앞의 코드 활용

    # 클래스 메서드
    @classmethod
    def count_instance(cls):
        print("자동차 객체의 개수: {0}".format(cls.instance_count))


# **[8장: 150페이지]**

# In[ ]:


Car.count_instance()  # 객체 생성 전에 클래스 메서드 호출

car1 = Car("small", "red")  # 첫 번째 객체 생성
Car.count_instance()  # 클래스 메서드 호출

car2 = Car("big", "green")  # 두 번째 객체 생성
Car.count_instance()  # 클래스 메서드 호출


# ## 8.3 객체와 클래스를 사용하는 이유

# **[8장: 151페이지]**

# In[ ]:


robot_name = 'R1'  # 로봇 이름
robot_pos = 0  # 로봇의 초기 위치


def robot_move():
    global robot_pos
    robot_pos = robot_pos + 1
    print("{0} position: {1}".format(robot_name, robot_pos))


# **[8장: 152페이지]**

# In[ ]:


robot_move()


# **[8장: 152페이지]**

# In[ ]:


robot1_name = 'R1'  # 로봇 이름
robot1_pos = 0  # 로봇의 초기 위치


def robot1_move():
    global robot1_pos
    robot1_pos = robot1_pos + 1
    print("{0} position: {1}".format(robot1_name, robot1_pos))


robot2_name = 'R2'  # 로봇 이름
robot2_pos = 10  # 로봇의 초기 위치


def robot2_move():
    global robot2_pos
    robot2_pos = robot2_pos + 1
    print("{0} position: {1}".format(robot2_name, robot2_pos))


# **[8장: 152페이지]**

# In[ ]:


robot1_move()
robot2_move()


# **[8장: 153페이지]**

# In[ ]:


class Robot():
    def __init__(self, name, pos):
        self.name = name  # 로봇 객체의 이름
        self.pos = pos  # 로봇 객체의 위치

    def move(self):
        self.pos = self.pos + 1
        print("{0} position: {1}".format(self.name, self.pos))


# **[8장: 153페이지]**

# In[ ]:


robot1 = Robot('R1', 0)
robot2 = Robot('R2', 10)


# **[8장: 153페이지]**

# In[ ]:


robot1.move()
robot2.move()


# **[8장: 153페이지]**

# In[ ]:


myRobot3 = Robot('R3', 30)
myRobot4 = Robot('R4', 40)

myRobot3.move()
myRobot4.move()


# ## 8.4 클래스 상속

# **[8장: 155페이지]**

# In[ ]:


class Bicycle():

    def __init__(self, wheel_size, color):
        self.wheel_size = wheel_size
        self.color = color

    def move(self, speed):
        print("자전거: 시속 {0}킬로미터로 전진".format(speed))

    def turn(self, direction):
        print("자전거: {0}회전".format(direction))

    def stop(self):
        print("자전거({0}, {1}): 정지 ".format(self.wheel_size, self.color))


# **[8장: 156페이지]**

# In[ ]:


class FoldingBicycle(Bicycle):

    def __init__(self, wheel_size, color, state):  # FoldingBicycle 초기화
        Bicycle.__init__(self, wheel_size, color)  # Bicycle의 초기화 재사용
        # super().__init__(wheel_size, color)  # super()도 사용 가능
        self.state = state  # 자식 클래스에서 새로 추가한 변수

    def fold(self):
        self.state = 'folding'
        print("자전거: 접기, state = {0}".format(self.state))

    def unfold(self):
        self.state = 'unfolding'
        print("자전거: 펴기, state = {0}".format(self.state))


# **[8장: 156페이지]**

# In[ ]:


folding_bicycle = FoldingBicycle(27, 'white', 'unfolding')  # 객체 생성

folding_bicycle.move(20)  # 부모 클래스의 함수(메서드) 호출
folding_bicycle.fold()   # 자식 클래스에서 정의한 함수 호출
folding_bicycle.unfold()


# # 8.5 정리
