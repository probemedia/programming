#!/usr/bin/env python
# coding: utf-8

# # 10장 모듈

# ## 10.1 모듈을 사용하는 이유

# ## 모듈 생성 및 호출

# ### 모듈 만들기

# **[10장: 181페이지]**

# In[ ]:


get_ipython().run_cell_magic('writefile', 'C:\\myPyCode\\my_first_module.py', '# File name: my_first_module.py\n\ndef my_function():\n    print("This is my first module.") ')
# get_ipython().run_cell_magic('writefile', 'D:\\pyworks_3_5_3th\\data\\my_first_module.py', '# File name: my_first_module.py\n\ndef my_function():\n    print("This is my first module.") ')

# **[10장: 182페이지]**

# In[ ]:


get_ipython().system('type C:\\myPyCode\\my_first_module.py')
# get_ipython().system('type D:\\pyworks_3_5_3th\\data\\my_first_module.py')

# ### 모듈 불러오기

# **[10장: 182페이지]**

# In[ ]:


# cd C:\myPyCode


# **[10장: 183페이지]**

# In[ ]:


import data.my_first_module as my_first_module

my_first_module.my_function()


# **[10장: 183페이지]**

# In[ ]:


get_ipython().system('echo %PYTHONPATH%')


# **[10장: 184페이지]**

# In[ ]:


get_ipython().run_cell_magic('writefile', 'C:\\myPyCode\\modules\\my_area.py', '# File name: my_area.py\n\nPI = 3.14\ndef square_area(a): # 정사각형의 넓이 반환\n    return a ** 2\n\ndef circle_area(r): # 원의 넓이 반환\n    return PI * r ** 2')
# get_ipython().run_cell_magic('writefile', 'D:\\pyworks_3_5_3th\\my_area.py', '# File name: my_area.py\n\nPI = 3.14\ndef square_area(a): # 정사각형의 넓이 반환\n    return a ** 2\n\ndef circle_area(r): # 원의 넓이 반환\n    return PI * r ** 2')

# **[10장: 184페이지]**

# In[ ]:


# cd C:\myPyCode


# **[10장: 184페이지]**

# In[ ]:


import my_area    # 모듈 불러오기

print('pi =', my_area.PI)  # 모듈의 변수 이용
print('square area =', my_area.square_area(5))  # 모듈의 함수 이용     
print('circle area =', my_area.circle_area(2))


# **[10장: 185페이지]**

# In[ ]:


dir(my_area)


# ### 모듈을 불러오는 다른 형식

# #### 모듈의 내용 바로 선언

# **[10장: 186페이지]**

# In[ ]:


from my_area import PI  # 모듈의 변수 바로 불러오기

print('pi =', PI)  # 모듈의 변수 이용


# **[10장: 186페이지]**

# In[ ]:


from my_area import square_area
from my_area import circle_area

print('square area =', square_area(5))  # 모듈의 함수 이용      
print('circle area =', circle_area(2))   


# **[10장: 186페이지]**

# In[ ]:


from my_area import PI, square_area, circle_area

print('pi =', PI)  # 모듈의 변수 이용
print('square area =', square_area(5))  # 모듈의 함수 이용      
print('circle area =', circle_area(2))  


# **[10장: 187페이지]**

# In[ ]:


from my_area import *

print('pi =', PI)  # 모듈의 변수 이용
print('square area =', square_area(5))  # 모듈의 함수 이용
print('circle area =', circle_area(2)) 


# **[10장: 187 ~ 188페이지]**

# In[ ]:


get_ipython().run_cell_magic('writefile', 'C:\\myPyCode\\modules\\my_module1.py', '# File name: my_module1.py\n\ndef func1():\n    print("func1 in  my_module1 ")\n\ndef func2():\n    print("func2 in  my_module1 ")')
# get_ipython().run_cell_magic('writefile', 'D:\\pyworks_3_5_3th\\my_module1.py', '# File name: my_module1.py\n\ndef func1():\n    print("func1 in  my_module1 ")\n\ndef func2():\n    print("func2 in  my_module1 ")')

# In[ ]:


get_ipython().run_cell_magic('writefile', 'C:\\myPyCode\\modules\\my_module2.py', '# File name: my_module2.py\n\ndef func2():\n    print("func2 in  my_module2 ")\n\ndef func3():\n    print("func3 in  my_module2 ")')
# get_ipython().run_cell_magic('writefile', 'D:\\pyworks_3_5_3th\\my_module2.py', '# File name: my_module2.py\n\ndef func2():\n    print("func2 in  my_module2 ")\n\ndef func3():\n    print("func3 in  my_module2 ")')

# **[10장: 188페이지]**

# In[ ]:


from my_module1 import *
from my_module2 import *

func1()
func2()
func3()


# **[10장: 188페이지]**

# In[ ]:


from my_module2 import *
from my_module1 import *

func1()
func2()
func3()


# #### 모듈명을 별명으로 선언

# **[10장: 189페이지]**

# In[ ]:


import my_area as area  # 모듈명(my_area)에 별명(area)을 붙임 

print('pi =', area.PI)  # 모듈명 대신 별명 이용
print('square area =', area.square_area(5))     
print('circle area =', area.circle_area(2))


# **[10장: 190페이지]**

# In[ ]:


from my_area import PI as pi
from my_area import square_area as square
from my_area import circle_area as circle

print('pi =', pi)  # 모듈 변수의 별명 이용
print('square area =', square(5))  # 모듈 함수의 별명 이용
print('circle area =', circle(2))  


# ## 10.3 모듈을 직접 실행하는 경우와 임포트한 후 실행하는 경우 구분하기

# **[10장: 190페이지]**

# In[ ]:


get_ipython().run_cell_magic('writefile', 'C:\\myPyCode\\modules\\my_module_test1.py', '# File name: my_module_test1.py\n\ndef func(a):\n    print("입력 숫자:", a)\n    \nfunc(3)')
# get_ipython().run_cell_magic('writefile', 'D:\\pyworks_3_5_3th\\my_module_test1.py', '# File name: my_module_test1.py\n\ndef func(a):\n    print("입력 숫자:", a)\n    \nfunc(3)')

# **[10장: 191페이지]**

# In[ ]:


get_ipython().run_line_magic('run', 'C:\\myPyCode\\modules\\my_module_test1.py')
# get_ipython().run_line_magic('run', 'D:\\pyworks_3_5_3th\\my_module_test1.py')

# **[10장: 191페이지]**

# In[ ]:


import my_module_test1


# **[10장: 192페이지]**

# In[ ]:


get_ipython().run_cell_magic('writefile', 'C:\\myPyCode\\modules\\my_module_test2.py', '# File name: my_module_test2.py\n\ndef func(a):\n    print("입력 숫자:",a)\n\nif __name__ == "__main__":\n    print("모듈을 직접 실행")\n    func(3)\n    func(4)')
# get_ipython().run_cell_magic('writefile', 'D:\\pyworks_3_5_3th\\my_module_test2.py', '# File name: my_module_test2.py\n\ndef func(a):\n    print("입력 숫자:",a)\n\nif __name__ == "__main__":\n    print("모듈을 직접 실행")\n    func(3)\n    func(4)')

# **[10장: 192페이지]**

# In[ ]:


get_ipython().run_line_magic('run', 'C:\\myPyCode\\modules\\my_module_test2.py')
# get_ipython().run_line_magic('run', 'D:\\pyworks_3_5_3th\\my_module_test2.py')

# **[10장: 192페이지]**

# In[ ]:


import my_module_test2


# **[10장: 193페이지]**

# In[ ]:


get_ipython().run_cell_magic('writefile', 'C:\\myPyCode\\modules\\my_module_test3.py', '# File name: my_module_test3.py\n\ndef func(a):\n    print("입력 숫자:",a)\n\nif __name__ == "__main__":\n    print("모듈을 직접 실행")\n    func(3)\n    func(4)\nelse:\n    print("모듈을 임포트해서 실행")')
# get_ipython().run_cell_magic('writefile', 'D:\pyworks_3_5_3th\\my_module_test3.py', '# File name: my_module_test3.py\n\ndef func(a):\n    print("입력 숫자:",a)\n\nif __name__ == "__main__":\n    print("모듈을 직접 실행")\n    func(3)\n    func(4)\nelse:\n    print("모듈을 임포트해서 실행")')

# **[10장: 193페이지]**

# In[ ]:


get_ipython().run_line_magic('run', 'C:\\myPyCode\\modules\\my_module_test3.py')
# get_ipython().run_line_magic('run', 'D:\pyworks_3_5_3th\\my_module_test3.py')

# **[10장: 194페이지]**

# In[ ]:


import my_module_test3


# ## 10.4 내장 모듈

# ### 난수 발생 모듈

# **[10장: 195페이지]**

# In[ ]:


import random

random.random()


# **[10장: 195페이지]**

# In[ ]:


import random

dice1 = random.randint(1,6)  # 임의의 정수가 생성됨
dice2 = random.randint(1,6)  # 임의의 정수가 생성됨
print('주사위 두 개의 숫자: {0}, {1}'.format(dice1, dice2))


# **[10장: 196페이지]**

# In[ ]:


import random

random.randrange(0, 11, 2)


# **[10장: 196페이지]**

# In[ ]:


import random

num1 = random.randrange(1, 10, 2)  # 1 ~ 9(10-1) 중 임의의 홀수 선택
num2 = random.randrange(0, 100, 10)  # 0 ~ 99(100-1) 중 임의의10의 단위 숫자 선택
print('num1: {0}, num2: {1}'.format(num1, num2))


# **[10장: 196페이지]**

# In[ ]:


import random

menu = ['비빔밥', '된장찌개', '볶음밥', '불고기', '스파게티', '피자', '탕수육']
random.choice(menu)


# **[10장: 197페이지]**

# In[ ]:


import random

random.sample([1, 2, 3, 4, 5], 2)  # 모집단에서 두 개의 인자 선택


# ### 날짜 및 시간 관련 처리 모듈

# **[10장: 198페이지]**

# In[ ]:


import datetime

set_day = datetime.date(2019, 3, 1)
print(set_day)


# **[10장: 198페이지]**

# In[ ]:


print('{0}/{1}/{2}'.format(set_day.year, set_day.month, set_day.day))


# **[10장: 198 ~ 199페이지]**

# In[ ]:


import datetime

day1 = datetime.date(2019, 4, 1)
day2 = datetime.date(2019, 7, 10)
diff_day = day2 - day1
print(diff_day)


# **[10장: 199페이지]**

# In[ ]:


type(day1)


# In[ ]:


type(diff_day)


# **[10장: 199페이지]**

# In[ ]:


print("** 지정된 두 날짜의 차이는 {}일입니다. **".format(diff_day.days))


# **[10장: 199페이지]**

# In[ ]:


import datetime

print(datetime.date.today())


# **[10장: 200페이지]**

# In[ ]:


import datetime

today = datetime.date.today()
special_day = datetime.date(2018, 12, 31)
print(special_day - today)


# **[10장: 200페이지]**

# In[ ]:


import datetime

set_time = datetime.time(15, 30, 45)
print(set_time)


# **[10장: 200페이지]**

# In[ ]:


print('{0}:{1}:{2}'.format(set_time.hour, set_time.minute, set_time.second))


# **[10장: 200페이지]**

# In[ ]:


import datetime

set_dt = datetime.datetime(2018, 10, 9, 10, 20, 0)
print(set_dt)


# **[10장: 200 ~ 201페이지]**

# In[ ]:


print('날짜 {0}/{1}/{2}'.format(set_dt.year, set_dt.month, set_dt.day))
print('시각 {0}:{1}:{2}'.format(set_dt.hour, set_dt.minute, set_dt.second))


# **[10장: 201페이지]**

# In[ ]:


import datetime

now = datetime.datetime.now()
print(now)


# **[10장: 201페이지]**

# In[ ]:


print("Date & Time: {:%Y-%m-%d, %H:%M:%S}".format(now))


# **[10장: 201페이지]**

# In[ ]:


print("Date: {:%Y, %m, %d}".format(now))
print("Time: {:%H/%M/%S}".format(now))


# **[10장: 201 ~ 202페이지]**

# In[ ]:


now = datetime.datetime.now()
set_dt = datetime.datetime(2017, 12, 1, 12, 30, 45)

print("현재 날짜 및 시각:", now)
print("차이:", set_dt - now)


# **[10장: 202페이지]**

# In[ ]:


from datetime import date, time, datetime

print(date(2019, 7, 1))


# In[ ]:


print(date.today())


# In[ ]:


print(time(15, 30, 45))


# In[ ]:


print(datetime(2020, 2, 14, 18, 10, 50))


# In[ ]:


print(datetime.now())


# ### 달력 생성 및 처리 모듈

# **[10장: 204페이지]**

# In[ ]:


import calendar

print(calendar.calendar(2018))

# **[10장: 205페이지]**

# In[ ]:


print(calendar.calendar(2019, m=4))


# **[10장: 206페이지]**

# In[ ]:


print(calendar.month(2020,9))


# **[10장: 206페이지]**

# In[ ]:


calendar.monthrange(2020,2)


# **[10장: 206페이지]**

# In[ ]:


calendar.firstweekday()


# **[10장: 207페이지]**

# In[ ]:


calendar.setfirstweekday(calendar.SUNDAY)
print(calendar.month(2020, 9))
print(calendar.calendar(2020))

# **[10장: 208페이지]**

# In[ ]:


print(calendar.weekday(2018, 10, 14))


# **[10장: 208페이지]**

# In[ ]:


print(calendar.isleap(2018))
print(calendar.isleap(2020))

# 위의 출력 결과에서 2020년은 윤년인 것을 알 수 있습니다.

# ## 10.5 패키지

# ### 패키지의 구조

# ### 패키지 만들기

# **[10장: 210페이지]**

# In[ ]:


mkdir C:\myPyCode\packages\image; C:\myPyCode\packages\image\io_file


# **[10장: 210페이지]**

# In[ ]:


get_ipython().run_cell_magic('writefile', 'C:\\myPyCode\\packages\\image\\__init__.py', '# File name: __init__.py')
# get_ipython().run_cell_magic('writefile', 'D:\\pyworks_3_5_3th\\packages\\image\\__init__.py', '# File name: __init__.py')

# In[ ]:


get_ipython().run_cell_magic('writefile', 'C:\\myPyCode\\packages\\image\\io_file\\__init__.py', '# File name: __init__.py')
# get_ipython().run_cell_magic('writefile', 'D:\\pyworks_3_5_3th\\packages\\image\\io_file\\__init__.py', '# File name: __init__.py')

# **[10장: 210페이지]**

# In[ ]:


get_ipython().run_cell_magic('writefile', 'C:\\myPyCode\\packages\\image\\io_file\\imgread.py', '# File name: imgread.py\n    \ndef pngread():\n    print("pngread in imgread module")\n\ndef jpgread():\n    print("jpgread in imgread module")')
# get_ipython().run_cell_magic('writefile', 'D:\\pyworks_3_5_3th\\packages\\image\\io_file\\imgread.py', '# File name: imgread.py\n    \ndef pngread():\n    print("pngread in imgread module")\n\ndef jpgread():\n    print("jpgread in imgread module")')

# **[10장: 210페이지]**

# In[ ]:


get_ipython().system('tree /F  c:\\myPyCode\\packages')
# get_ipython().system('tree /F  D:\pyworks_3_5_3th\\packages')

# ### 패키지 사용하기

# **[10장: 211페이지]**

# In[ ]:


import image.io_file.imgread # image 패키지 io_file 폴더의 imgread 모듈 임포트
    
image.io_file.imgread.pngread() # imgread 모듈 내의 pngread() 함수 호출
image.io_file.imgread.jpgread() # imgread 모듈 내의 jpgread() 함수 호출


# %%
import packages.image.io_file.imgread as image_io_file_imgread

image_io_file_imgread.pngread() # imgread 모듈 내의 pngread() 함수 호출
image_io_file_imgread.jpgread() # imgread 모듈 내의 jpgread() 함수 호출

# **[10장: 211페이지]**

# In[ ]:


from image.io_file import imgread

imgread.pngread()
imgread.jpgread()

# %%
from packages.image.io_file import imgread

imgread.pngread()
imgread.jpgread()

# **[10장: 212페이지]**

# In[ ]:


from image.io_file.imgread import pngread

pngread()
# %%
from packages.image.io_file.imgread import pngread

pngread()

# **[10장: 212페이지]**

# In[ ]:


from image.io_file.imgread import *

pngread()
jpgread()
# %%
from packages.image.io_file.imgread import *

pngread()
jpgread()

# **[10장: 212페이지]**

# In[ ]:


from image.io_file.imgread import pngread, jpgread

pngread()
jpgread()

# %%
from packages.image.io_file.imgread import pngread, jpgread

pngread()
jpgread()
# **[10장: 212 ~ 213페이지]**

# In[ ]:


from image.io_file import imgread as img

img.pngread()
img.jpgread()

# %%
from packages.image.io_file import imgread as img

img.pngread()
img.jpgread()
# **[10장: 213페이지]**

# In[ ]:


from image.io_file.imgread import pngread as pread
from image.io_file.imgread import jpgread as jread

pread()
jread()

# %%
from packages.image.io_file.imgread import pngread as pread
from packages.image.io_file.imgread import jpgread as jread

pread()
jread()
# ## 10.6 정리
