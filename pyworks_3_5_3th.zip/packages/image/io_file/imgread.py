# File name: imgread.py
    
def pngread():
    print("pngread in imgread module")

def jpgread():
    print("jpgread in imgread module")