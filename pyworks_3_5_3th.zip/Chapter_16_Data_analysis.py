#!/usr/bin/env python
# coding: utf-8

# # 16장 실전 데이터 분석 프로젝트

# ## 16.1 데이터 분석 프로세스

# ## 16.2 데이터 획득, 처리, 시각화 심화

# ### 깃허브에서 파일 다운로드

# **[16장: 533 ~ 534페이지]**

# In[ ]:


import requests

# 깃허브의 파일 URL
url = 'https://github.com/wikibook/python-for-data-analysis-rev/raw/master/readme.txt'

# URL에 해당하는 파일을 내려받음
r = requests.get(url)

# 파일을 저장할 폴더와 파일명을 지정
file_name = 'data/readme.txt'

# 내려받은 파일을 지정한 폴더에 저장
with open(file_name, 'wb') as f:
    f.write(r.content)


# **[16장: 534페이지]**

# In[ ]:


import os

os.path.isfile(file_name) 


# ### 데이터에서 결측치 확인 및 처리

# #### 결측치 확인

# **[16장: 535페이지]**

# In[ ]:


get_ipython().system('type C:\\myPyCode\\data\\missing_data_test.csv')
# get_ipython().system('type D:\\pyworks_3_5_3th\\data\\missing_data_test.csv')

# **[16장: 535페이지]**

# In[ ]:


import pandas as pd

data_file = "data/missing_data_test.csv"

df = pd.read_csv(data_file, encoding = "cp949", index_col = "연도")

df


# **[16장: 535페이지]**

# In[ ]:


df.isnull()


# **[16장: 536페이지]**

# In[ ]:


df.isnull().sum()


# #### 결측치 처리

# **[16장: 537페이지]**

# In[ ]:


df.drop(index=[2019])


# **[16장: 537페이지]**

# In[ ]:


df.drop(columns=['제품3', '제품4'])


# **[16장: 538페이지]** 

# In[ ]:


df.drop(index=[2018, 2019], columns=['제품3', '제품4'])


# **[16장: 538페이지]** 

# In[ ]:


df.dropna() #df.dropna(axis=0)도 결과는 같습니다.


# **[16장: 539페이지]** 

# In[ ]:


df.dropna(axis=0, subset=['제품1'])


# **[16장: 539페이지]** 

# In[ ]:


df.dropna(axis=1)


# **[16장: 539페이지]** 

# In[ ]:


df.dropna(axis=1, subset=[2015])


# **[16장: 540페이지]** 

# In[ ]:


df.dropna(axis=1, subset=[2016, 2019])


# **[16장: 541페이지]**

# In[ ]:


df.fillna(0)


# **[16장: 541페이지]**

# In[ ]:


df.fillna(method='bfill')


# **[16장: 541페이지]**

# In[ ]:


df.fillna(method='ffill')


# **[16장: 542페이지]**

# In[ ]:


values = {'제품1': 100,  '제품4': 400}
df.fillna(value=values)


# ### 데이터의 요약 및 재구성

# #### 데이터의 구조 살펴보기

# **[16장: 543페이지]**

# In[ ]:


import pandas as pd

data_file = "data/total_sales_data.csv"

df_sales = pd.read_csv(data_file)
df_sales


# **[16장: 543페이지]**

# In[ ]:


df_sales.info()


# **[16장: 544페이지]**

# In[ ]:


df_sales['매장명'].value_counts()


# **[16장: 545페이지]**

# In[ ]:


df_sales['제품종류'].value_counts()


# #### 피벗 테이블로 데이터 재구성하기

# **[16장: 546페이지]**

# In[ ]:


df_sales


# **[16장: 546페이지]**

# In[ ]:


df_sales.pivot_table(index=["매장명", "제품종류", "모델명"],
                     values=["판매", "재고"], aggfunc='sum')


# **[16장: 547페이지]**

# In[ ]:


df_sales.pivot_table(index=["매장명"], columns=["제품종류"],
                     values=["판매", "재고"], aggfunc='sum')


# **[16장: 547페이지]**

# In[ ]:


df_sales.pivot_table(index=["매장명"], columns=["제품종류"],
                     values=["판매", "재고"], aggfunc='count')


# ### 워드 클라우드를 이용한 데이터 시각화

# **[16장: 549~550페이지]**

# In[ ]:


from wordcloud import WordCloud
import matplotlib.pyplot as plt

file_name = 'data/littleprince_djvu.txt'

with open(file_name) as f:  # 파일을 읽기 모드로 열기
    text = f.read()  # 파일의 내용 읽어오기

# 워드 클라우드의 이미지를 생성합니다.
wordcloud_image = WordCloud().generate(text)

# 생성한 워드 클라우드 이미지를 화면에 표시합니다.
plt.imshow(wordcloud_image, interpolation='bilinear')
plt.axis("off")
plt.show()


# **[16장: 550페이지]**

# In[ ]:


wordcloud_image = WordCloud(background_color='white', max_font_size=300,
                            width=800, height=400).generate(text)

plt.imshow(wordcloud_image, interpolation="bilinear")
plt.axis("off")
plt.show()


# **[16장: 551페이지]**

# In[ ]:


image_file_name = 'figures/little_prince.png'

wordcloud_image.to_file(image_file_name)
plt.show()


# **[16장: 551페이지]**

# In[ ]:


import pandas as pd

word_count_file = "data/word_count.csv"
word_count = pd.read_csv(word_count_file, index_col='단어')
word_count.head(5)


# **[16장: 552페이지]**

# In[ ]:


word_count['빈도'][0:5]


# **[16장: 552페이지]**

# In[ ]:


type(word_count['빈도'])


# **[16장: 553페이지]**

# In[ ]:


from wordcloud import WordCloud
import matplotlib.pyplot as plt

korean_font_path = 'C:/Windows/Fonts/malgun.ttf'  # 한글 폰트(맑은 고딕) 파일명

# 워드 클라우드 이미지 생성
wc = WordCloud(font_path=korean_font_path, background_color='white')

frequencies = word_count['빈도']  # pandas의 Series 형식이 됨
wordcloud_image = wc.generate_from_frequencies(frequencies)

# 생성한 워드 클라우드 이미지를 화면에 표시
plt.imshow(wordcloud_image, interpolation="bilinear")
plt.axis("off")
plt.show()


# ## 16.3 실전 데이터(서울시 업무추진비) 분석

# ### 데이터 분석의 주제 선정

# ### 데이터 수집

# **[16장: 557~558페이지]**

# In[ ]:
# 2016데이터 없어짐 - https://github.com/seoul-opengov/opengov/raw/master/expense_list2016/ 안됨
# 2017데이터부터 실습함  - https://github.com/seoul-opengov/opengov/raw/master/expense_list2017/
import requests
import os
import pathlib


#인자: 확장자, 연도, 내려받을 폴더
def get_seoul_expense_list(extension, year, data_folder):

    # 깃허브의 데이터 위치 지정
    # ex) 'https://github.com/seoul-opengov/opengov/raw/master/expense_list2017/'
    expense_list_year_url = 'https://github.com/seoul-opengov/opengov/raw/master/expense_list' + str(year) + '/'

    # 데이터를 내려받을 폴더 지정
    # ex) 'C:/myPyCode/data/seoul_expense/2016/'
    expense_list_year_dir = data_folder + str(year) + '/'

    # 내려받을 폴더가 없다면 폴더 생성
    if(os.path.isdir(expense_list_year_dir)):
        print("데이터 폴더({0})가 이미 있습니다. {0}년 데이터의 다운로드를 시작합니다.".format(year))
    else:
        print("데이터 폴더({0})가 없어서 생성했습니다. {0}년 데이터의 다운로드를 시작합니다.".format(year))
        # 폴더 생성
        pathlib.Path(expense_list_year_dir).mkdir(parents=True, exist_ok=True)

    # 지정한 폴더로 1월 ~ 12월 업무추진비 파일을 다운로드
    for k in range(12):
        file_name = '{0}{1:02d}_expense_list.{2}'.format(year, k+1, extension)
        url = expense_list_year_url + file_name
        print(url)
        r = requests.get(url)
        with open(expense_list_year_dir + file_name, 'wb') as f:
            f.write(r.content)


# **[16장: 558~559페이지]**

# In[ ]:

# 
# 내려받을 업무추진비 데이터의 파일 형식을 지정
extension = "csv"

# 내려받을 업무추진비 데이터의 연도를 지정
# year = 2016
year = 2017
# 내려받을 업무추진비 데이터의 폴더를 지정
data_folder = 'data/seoul_expense/'

# 함수를 실행
get_seoul_expense_list(extension, year, data_folder)


# **[16장: 559~560페이지]**

# In[ ]:


import glob

# path_name = 'data/seoul_expense/2016/'  # 폴더 이름
path_name = 'data/seoul_expense/2017/'  # 폴더 이름
# 지정 폴더에서 파일명에 list.csv가 포함된 파일만 지정
file_name_for_glob = path_name + "*list.csv"

csv_files = []
for csv_file in glob.glob(file_name_for_glob):
    # 반환값에서 폴더는 제거하고 파일 이름만 추출
    csv_files.append(csv_file.split("\\")[-1])

print("[폴더 이름]", path_name)  # 폴더명 출력
print("* CSV 파일:", csv_files)


# **[16장: 560페이지]**

# In[ ]:


data_folder = 'data/seoul_expense/'

# years = [2016, 2017, 2018]  # 다운로드받을 연도를 지정
years = [2017, 2018]  # 다운로드받을 연도를 지정
extension = "csv"
# extension = "xlsx"
# extension = "xml"

for year in years:
    get_seoul_expense_list(extension, year, data_folder)

print("모든 데이터를 다운로드 받았습니다.")


# **[16장: 561페이지]**

# In[ ]:


import glob

data_folder = 'data/seoul_expense/'

# years = [2016, 2017, 2018]  # 다운로드받을 연도를 지정
years = [2017, 2018]  # 다운로드받을 연도를 지정
for year in years:
    path_name = data_folder + str(year) + "/"  # 연도별 폴더명을 지정

    # 지정 폴더에서 파일명에 list.csv가 포함된 파일만 지정
    file_name_for_glob = path_name + "*list.csv"

    csv_files = []
    for csv_file in glob.glob(file_name_for_glob):
        # 반환값에서 폴더는 제거하고 파일명만 추출
        csv_files.append(csv_file.split("\\")[-1])

    print("[폴더 이름]", path_name)  # 폴더명 출력
    print("* CSV 파일:", csv_files)


# ### 데이터 처리

# #### 수집된 데이터 파일의 구조 분석

# **[16장: 562페이지]**

# In[ ]:

# data_file = 'data/seoul_expense/2016/201601_expense_list.csv'
data_file = 'data/seoul_expense/2017/201701_expense_list.csv'

with open(data_file, encoding='utf-8') as f:
    line1 = f.readline()
    line2 = f.readline()
    line3 = f.readline()

    print(line1)
    print(line2)
    print(line3)


# **[16장: 563페이지]**

# In[ ]:


line1_len = len(line1.split(','))
line2_len = len(line2.split(','))
line3_len = len(line3.split(','))

print("[각 줄의 데이터값의 개수]")
print("첫째 줄:{}, 둘째 줄:{}, 셋째 줄:{}".format(line1_len, line2_len, line3_len))


# **[16장: 563페이지]**

# In[ ]:


def get_value_count(line):

    line_rep_list = []
    for k, x in enumerate(line.split('"')):
        if(k % 2 != 0):
            x = x.replace(',', '')
        line_rep_list.append(x)

    line_rep_str = ''.join(line_rep_list)
    return len(line_rep_str.split(','))


# **[16장: 564페이지]**

# In[ ]:


line1_len = get_value_count(line1)
line2_len = get_value_count(line2)
line3_len = get_value_count(line3)

print("[각 줄의 데이터값의 개수]")
print("첫째 줄:{}, 둘째 줄:{}, 셋째 줄:{}".format(line1_len, line2_len, line3_len))


# #### 첫 번째 줄의 열 이름과 개수 변경

# **[16장: 565페이지]**

# In[ ]:


def change_csv_file_first_line_value(old_file_name, new_file_name):
    with open(old_file_name, encoding='utf-8') as f:  # 파일을 읽기 모드로 열기
        # 전체 데이터를 읽어서 한 줄씩 lines 리스트의 각 요소에 할당
        lines = f.read().splitlines()

    # 첫째 줄의 내용을 변경할 열 이름을 지정해서 변경
    lines[0] = 'nid,제목,url,부서레벨1,부서레벨2,부서레벨3,부서레벨4,부서레벨5,집행연도,집행월,예산,집행,구분,부서명,집행일시,집행장소,집행목적,대상인원,결제방법,집행금액'

    with open(new_file_name, 'w', encoding='utf-8') as f:  # 파일을 쓰기 모드로 열기
        # 리스트 내의 각 요소를 개행문자(\n)로 연결해서 파일로 저장
        f.write('\n'.join(lines))


# **[16장: 565페이지]**

# In[ ]:


# 기존의 파일
# old_file_name = 'data/seoul_expense/2016/201601_expense_list.csv'
old_file_name = 'data/seoul_expense/2017/201701_expense_list.csv'

# 새로운 파일
# new_file_name = 'data/seoul_expense/2016/201601_expense_list_new.csv'
new_file_name = 'data/seoul_expense/2017/201701_expense_list_new.csv'

# 첫째 줄의 내용을 변경한 새로운 파일 생성
change_csv_file_first_line_value(old_file_name, new_file_name)


# **[16장: 565페이지]**

# In[ ]:


with open(new_file_name, encoding='utf-8') as f:  # 파일을 읽기 모드로 열기
    for k in range(3):
        print(f.readline())


# **[16장: 566페이지]**

# In[ ]:


# 인자: 연도, 데이터 파일이 있는 폴더
def change_year_csv_file_first_line_value(year, data_folder):

    # 데이터 파일이 있는 폴더 지정
    # ex) 'C:/myPyCode/data/seoul_expense/2016/'
    expense_list_year_dir = data_folder + str(year) + '/'

    extension = 'csv'  # 확장자 이름

    # 지정한 폴더에 있는 월별 업무추진비 파일에서 첫 번째 줄의 열 이름을 변경
    for k in range(12):
        # 기존의 파일 이름 지정
        old_file_name = expense_list_year_dir + '{0}{1:02d}_expense_list.{2}'.format(year, k+1, extension) 

        # 새로운 파일 이름 지정
        new_file_name = expense_list_year_dir + '{0}{1:02d}_expense_list_new.{2}'.format(year, k+1, extension) 

        # 첫째 줄의 내용을 변경한 새로운 파일 생성
        change_csv_file_first_line_value(old_file_name, new_file_name)


# **[16장: 566 ~ 567페이지]**

# In[ ]:


data_folder = 'data/seoul_expense/'
# years = [2016, 2017, 2018]  # 연도를 지정
years = [2017, 2018]  # 연도를 지정

for year in years:
    print("{}년 데이터의 첫 번째 줄의 열 이름을 변경해서 새 파일에 저장합니다.".format(year))
    change_year_csv_file_first_line_value(year, data_folder)

print("모든 데이터의 첫 번째 줄의 열 이름을 변경해서 새 파일로 저장했습니다.")


# **[16장: 567페이지]**

# In[ ]:


import glob

data_folder = 'data/seoul_expense/'
# years = [2016, 2017, 2018]  # 연도를 지정
years = [2017, 2018]  # 연도를 지정

for year in years:
    path_name = data_folder + str(year)  # 폴더명을 지정
    print("[폴더 이름]", path_name)  # 폴더명 출력

    new_csv_files = []

    # 지정 폴더에서 파일명에 _new.csv가 포함된 파일만 지정
    file_name_for_glob = path_name + "/*_new.csv"

    for new_csv_file in glob.glob(file_name_for_glob):
        # 반환값에서 폴더는 제거하고 파일 이름만 추출
        new_csv_files.append(new_csv_file.split("\\")[-1])

    print("* 새롭게 생성된 CSV 파일:", new_csv_files)


# #### 데이터의 구조 및 결측치 살펴보기

# **[16장: 568페이지]**

# In[ ]:


import pandas as pd
# expense_list2016_dir = 'data/seoul_expense/2016/'
# file_name = "201601_expense_list_new.csv"
expense_list2017_dir = 'data/seoul_expense/2017/'
file_name = "201701_expense_list_new.csv"

df = pd.read_csv(expense_list2017_dir + file_name)


# **[16장: 568페이지]**

# In[ ]:


df.head(2)


# **[16장: 569페이지]**

# In[ ]:


import pandas as pd
# year = 2016
year = 2017
expense_list_year_dir = 'data/seoul_expense/' + str(year) + '/'

df_year = pd.DataFrame()
for k in range(12):

    # 파일 이름 지정
    file_name = "{0}{1:02d}_expense_list_new.csv".format(year, k+1)

    # pandas DataFrame 형식으로 csv 데이터 불러오기
    df_month = pd.read_csv(expense_list_year_dir + file_name)

    # df_year에 df_month를 세로 방향으로 추가해서 다시 df_year에 할당
    # 통합된 dataFrame의 순서대로 index를 할당하기 위해서 `ignore_index = True` 옵션 지정
    df_year = df_year.append(df_month, ignore_index=True)


# **[16장: 569페이지]**

# In[ ]:


df_year.head(2)


# **[16장: 569페이지]**

# In[ ]:


df_year.tail(2)


# **[16장: 570페이지]**

# In[ ]:


df_year.info()


# **[16장: 571페이지]**

# In[ ]:


df_year.isna().sum()


# **[16장: 572페이지]**

# In[ ]:


df_year_drop = df_year.drop(columns=['nid', 'url', '부서레벨3', '부서레벨4',
                                     '부서레벨5', '예산', '집행', '구분'])
df_year_drop.head(2)


# **[16장: 572페이지]**

# In[ ]:

# year = 2016
year = 2017
expense_list_year_dir = 'data/seoul_expense/' + str(year) + '/'

expense_list_tidy_file = "{}_expense_list_tidy.csv".format(year)
df_year_drop.to_csv(expense_list_year_dir + expense_list_tidy_file, index = False)


# **[16장: 572페이지]**

# In[ ]:


import os

file_name = expense_list_year_dir + expense_list_tidy_file
print(file_name)
os.path.isfile(file_name)


# **[16장: 573페이지]**

# In[ ]:


import pandas as pd


def select_columns_save_file(year, data_folder, drop_columns_list):

    expense_list_year_dir = data_folder + str(year) + '/'
    expense_list_tidy_file = "{}_expense_list_tidy.csv".format(year)
    df_year = pd.DataFrame()

    for k in range(12):
        # 파일 이름 지정
        file_name = "{0}{1:02d}_expense_list_new.csv".format(year, k+1)

        # aDtaFrame 형식으로 csv 데이터 불러오기
        df_month = pd.read_csv(expense_list_year_dir + file_name)

        # fd_year에 df_month를 새로 추가해서 다시 df_year에 할당
        # 통합된 adtaFrame의 순서대로 index를 할당하기 위해서 `ignore_index = True` 옵션 지정
        df_year = df_year.append(df_month, ignore_index=True)

    df_year_drop = df_year.drop(columns=drop_columns_list)
    new_file_name = expense_list_year_dir + expense_list_tidy_file
    df_year_drop.to_csv(new_file_name, index=False)

    print("==> {} 파일을 생성했습니다.".format(expense_list_tidy_file))


# **[16장: 573페이지]**

# In[ ]:


data_folder = 'data/seoul_expense/'
# years = [2016, 2017, 2018]
years = [2017, 2018]
drop_columns_list = ['nid', 'url', '부서레벨3', '부서레벨4', '부서레벨5',
                     '예산', '집행', '구분']

for year in years:
    print("{}년 데이터를 정리해서 저장하고 있습니다.".format(year))
    select_columns_save_file(year, data_folder, drop_columns_list)
print("모든 연도의 데이터를 정리해서 파일로 저장했습니다.")


# **[16장: 574페이지]**

# In[ ]:


import os
# years = [2016, 2017, 2018]
years = [2017, 2018]

for year in years:

    expense_list_year_dir = data_folder + str(year) + '/'
    expense_list_tidy_file = "{}_expense_list_tidy.csv".format(year)

    file_name = expense_list_year_dir + expense_list_tidy_file
    print(file_name, "==> ", end="")
    print(os.path.isfile(file_name))


# **[16장: 574 ~ 575페이지]**

# In[ ]:


import os
from datetime import datetime


def get_file_info(year, data_folder):
    expense_list_year_dir = data_folder + str(year) + '/'
    expense_list_tidy_file = "{}_expense_list_tidy.csv".format(year)

    path_file_name = expense_list_year_dir + expense_list_tidy_file
    print(path_file_name)
    result = os.path.isfile(path_file_name)

    # 파일 수정 시간
    modified_time = datetime.fromtimestamp(os.path.getmtime(path_file_name))

    # 파일 생성 시간
    created_time = datetime.fromtimestamp(os.path.getctime(path_file_name))

    # 파일 크기
    file_size = os.path.getsize(path_file_name)

    if(result):
        print("[생성한 CSV 데이터 파일의 정보]")
        print('* 폴더 위치 :', expense_list_year_dir)
        print('* 파일 이름 :', expense_list_tidy_file)
        print('* 수정 시간 :', modified_time.strftime('%Y-%m-%d %H:%M:%S'))
        print('* 생성 시간 :', created_time.strftime('%Y-%m-%d %H:%M:%S'))
        print('* 파일 크기 : {0:,} 바이트'.format(file_size))


# **[16장: 575페이지]**

# In[ ]:


data_folder = 'data/seoul_expense/'
# years = [2016, 2017, 2018]
years = [2017, 2018]

for year in years:

    get_file_info(year, data_folder)
    print("")


# ### 데이터 분석

# **[16장: 576 ~ 577페이지]**

# In[ ]:


import pandas as pd

data_folder = 'data/seoul_expense/'
# years = [2016, 2017, 2018]
years = [2017, 2018]

df_expense_all = pd.DataFrame()

for year in years:
    expense_list_year_dir = data_folder + str(year) + '/'
    expense_list_tidy_file = "{}_expense_list_tidy.csv".format(year)

    path_file_name = expense_list_year_dir + expense_list_tidy_file

    df_expense = pd.read_csv(path_file_name)
    df_expense_all = df_expense_all.append(df_expense, ignore_index=True)


# **[16장: 577페이지]**

# In[ ]:


df_expense_all.info()


# **[16장: 578페이지]**

# In[ ]:


df_expense_all.head(2)


# **[16장: 578페이지]**

# In[ ]:


df_expense_all.tail(2)


# #### 연도별 추이 분석

# **[16장: 578페이지]**

# In[ ]:

year_expense = df_expense_all['집행연도'].value_counts()
type(year_expense)
year_expense

# **[16장: 579페이지]**

# In[ ]:


import pandas as pd
import matplotlib.pyplot as plt
import matplotlib

matplotlib.rcParams['font.family'] = 'Malgun Gothic'
matplotlib.rcParams['axes.unicode_minus'] = False

plt.bar(year_expense.index, year_expense.values,
        tick_label=year_expense.index, width=0.5)
plt.title("연도별 업무추진비 집행 횟수")
plt.xlabel("연도")
plt.ylabel("집행 횟수")
plt.show()


# **[16장: 579페이지]**

# In[ ]:


import pandas as pd

year_total = pd.pivot_table(df_expense_all, index = ['집행연도'], values=['집행금액'], aggfunc = sum)
year_total


# **[16장: 580페이지]**

# In[ ]:


import pandas as pd
import matplotlib.pyplot as plt
import matplotlib

matplotlib.rcParams['font.family'] = 'Malgun Gothic'
matplotlib.rcParams['axes.unicode_minus'] = False

eok_won = 100000000  # 억원
(year_total/eok_won).plot.bar(rot=0)  # 'rot = 각도'로 xtick 회전 각도를 지정
plt.ylabel('집행금액(억원)')
plt.show()


# #### 월별 집행금액 분석

# **[16장: 581페이지]** 

# In[ ]:


month_total = pd.pivot_table(df_expense_all, index=['집행월'], values=['집행금액'],
                             aggfunc=sum)
month_total


# **[16장: 581페이지]** 

# In[ ]:


year_month_total = pd.pivot_table(df_expense_all, index=['집행월'], columns=['집행연도'],
                                  values=['집행금액'], aggfunc=sum)
year_month_total


# **[16장: 582페이지]** 

# In[ ]:


eok_won = 100000000  # 억원

(year_month_total/eok_won).plot.bar(rot=0)
plt.ylabel('집행금액(억원)')
plt.title("업무추진비의 월별 집행금액")
# plt.legend(['2016년', '2017년', '2018년'])
plt.legend(['2017년', '2018년'])
plt.show()


# #### 부서별 집행 내역 분석

# **[16장: 583페이지]** 

# In[ ]:


dept_level1_total = pd.pivot_table(df_expense_all, index=['부서레벨1'], values=['집행금액'],
                                   aggfunc=sum)
dept_level1_total


# **[16장: 584페이지]** 

# In[ ]:


dept_level_2_total = pd.pivot_table(df_expense_all, index=['부서레벨2'], values=['집행금액'],
                                    aggfunc=sum)
dept_level_2_total.head()


# **[16장: 584페이지]** 

# In[ ]:


dept_level_2_total_top10 = dept_level_2_total.sort_values(by=['집행금액'], ascending=False)[0:10]
dept_level_2_total_top10


# **[16장: 585페이지]** 

# In[ ]:


eok_won = 100000000  # 억원

(dept_level_2_total_top10/eok_won).plot.bar(rot=80)
plt.ylabel('집행금액(억원)')
plt.title("업무추진비 집행금액이 높은 상위 10개 부서")
plt.show()


# **[16장: 585 ~ 586페이지]** 

# In[ ]:


import matplotlib.pyplot as plt
from wordcloud import WordCloud

korean_font_path = 'C:/Windows/Fonts/malgun.ttf'  # 한글 폰트(맑은 고딕) 파일명

# 워드 클라우드 이미지 생성
wc = WordCloud(font_path=korean_font_path, background_color='white',
               width=800, height=600)

frequencies = dept_level_2_total['집행금액']  # pandas의 Series 형식이 됨
wordcloud_image = wc.generate_from_frequencies(frequencies)

plt.figure(figsize=(12, 9))
plt.axis('off')
plt.imshow(wordcloud_image, interpolation='bilinear')
plt.show()


# #### 요일별 및 시간대별 집행 내역 분석

# **[16장: 586페이지]** 

# In[ ]:


df_expense_all['집행일시'].values


# **[16장: 587페이지]** 

# In[ ]:


expense_date_time = pd.to_datetime(df_expense_all['집행일시'])
expense_date_time.values


# **[16장: 587페이지]**  

# In[ ]:


week_day_name = ["월", "화", "수", "목", "금", "토", "일"]

df_expense_all['집행일시_요일'] = [week_day_name[weekday] for weekday in expense_date_time.dt.weekday]


# **[16장: 587페이지]**  

# In[ ]:


df_expense_all['집행일시_시간'] = [hour for hour in expense_date_time.dt.hour]


# **[16장: 587페이지]**  

# In[ ]:


df_expense_all.head(3)


# **[16장: 588페이지]**  

# In[ ]:


expense_weekday = df_expense_all['집행일시_요일'].value_counts()
expense_weekday


# **[16장: 588페이지]**  

# In[ ]:


expense_weekday = expense_weekday.reindex(index=week_day_name)
expense_weekday


# **[16장: 589페이지]**  

# In[ ]:


expense_weekday.plot.bar(rot=0)
plt.title("요일별 업무추진비 집행 횟수")
plt.xlabel("요일")
plt.ylabel("집행 횟수")
plt.show()


# **[16장: 589페이지]**  

# In[ ]:


expense_hour_num = df_expense_all['집행일시_시간'].value_counts()
expense_hour_num


# **[16장: 590페이지]**  

# In[ ]:


work_hour = [ (k+8)%24 for k in range(24)]
expense_hour_num = expense_hour_num.reindex(index=work_hour)
expense_hour_num


# **[16장: 591페이지]** 

# In[ ]:


expense_hour_num.plot.bar(rot=0)
plt.title("시간별 업무추진비 집행 횟수")
plt.xlabel("집행 시간")
plt.ylabel("집행 횟수")
plt.show()


# **[16장: 592페이지]** 

# In[ ]:


expense_hour_total = pd.pivot_table(df_expense_all, index=['집행일시_시간'],
                                    values=['집행금액'], aggfunc=sum)
expense_hour_total.head()


# **[16장: 592페이지]** 

# In[ ]:


eok_won = 100000000  # 억원
expense_hour_total = expense_hour_total.reindex(index = work_hour)

(expense_hour_total/eok_won).plot.bar(rot=0)
plt.ylabel('집행금액(억원)')
plt.title("시간별대 업무추진비 집행금액")
plt.show()


# ## 16.4 정리
