#!/usr/bin/env python
# coding: utf-8

# # 4장 변수와 자료형

# ## 4.1 변수

# **[4장: 42페이지]**

# In[ ]:


12340 * 1 / 2


# In[ ]:


12340 * 1 / 4


# In[ ]:


12340 * 1 / 5


# **[4장: 43페이지]**

# In[ ]:


abc = 12340
print(abc)


# **[4장: 44페이지]**

# In[ ]:


abc


# **[4장: 44페이지]**

# In[ ]:


print(abc * 1/2)
print(abc * 1/4)
print(abc * 1/5)


# ## 4.2 문자열

# ### 문자열 만들기

# **[4장: 45 ~ 46페이지]**

# In[2]:


print("String Test")


# In[ ]:


print('String Test')


# **[4장: 46페이지]**

# In[ ]:


string1 = "String Test 1"
string2 = 'String Test 2'
print(string1)
print(string2)


# **[4장: 46페이지]**

# In[ ]:


type(string1)


# In[ ]:


type(string2)


# **[4장: 46페이지]**

# In[ ]:


string3 = 'This is a "double" quotation test'
string4 = "This is a 'single' quotation test"
print(string3)
print(string4)


# **[4장: 47페이지]**

# In[ ]:


long_string1 = '''[삼중 작은따옴표를 사용한 예]
파이썬에는 삼중 따옴표로 여러 행의 문자열을 입력할 수 있습니다.
큰따옴표(")와 작은따옴표(')도 입력할 수 있습니다.''' 

long_string2 = """[삼중 큰따옴표를 사용한 예]
파이썬에는 삼중 따옴표로 여러 행의 문자열을 입력할 수 있습니다.
큰따옴표(")와 작은따옴표(')도 입력할 수 있습니다.""" 

print(long_string1)
print(long_string2)


# ### 문자열 다루기

# **[4장: 48페이지]**

# In[ ]:


a = 'Enjoy '
b = 'python!'
c = a + b
print(c)


# In[ ]:


print(a * 3)


# ## 4.3 리스트

# ### 리스트 만들기

# **[4장: 49페이지]**

# In[ ]:


# 1번 학생의 국어, 영어, 수학, 과학 점수가 각각 90,95,85,80
student1 = [90, 95, 85, 80]
student1


# **[4장: 49페이지]**

# In[ ]:


type(student1)


# **[4장: 50페이지]**

# In[ ]:


student1[0]


# In[ ]:


student1[1]


# In[ ]:


student1[-1]


# **[4장: 50페이지]**

# In[ ]:


student1[1] = 100  # 두 번째 항목에 새로운 데이터 할당
student1


# **[4장: 50페이지]**

# In[ ]:


myFriends = ['James', 'Robert', 'Lisa', 'Mary']
myFriends


# **[4장: 50 ~ 51페이지]**

# In[ ]:


myFriends[2]


# In[ ]:


myFriends[3]


# In[ ]:


myFriends[-1]


# **[4장: 51페이지]**

# In[ ]:


mixedList = [0, 2, 3.14, 'python', 'program', True, myFriends]
mixedList


# ### 리스트 다루기

# #### 리스트 더하기와 곱하기

# **[4장: 51페이지]**

# In[ ]:


list_con1 = [1, 2, 3, 4]
list_con2 = [5, 6, 7, 8]
list_con = list_con1 + list_con2  # 리스트 연결

print(list_con)


# **[4장: 51 ~ 52페이지]**

# In[ ]:


list_con1 = [1, 2, 3, 4]
list_con = list_con1 * 3  # 리스트 반복

print(list_con)


# #### 리스트 중 일부 항목 가져오기

# **[4장: 52페이지]**

# In[ ]:


list_data = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
print(list_data)
print(list_data[0:3])
print(list_data[4:8])
print(list_data[:3])
print(list_data[7:])
print(list_data[::2])


# ####  리스트에서 항목 삭제하기

# **[4장: 53페이지]**

# In[ ]:


print(list_data)
del list_data[6]
print(list_data)


# #### 리스트에서 항목의 존재 여부 확인하기

# **[4장: 53페이지]**

# In[ ]:


list_data1 = [1, 2, 3, 4, 5]
print(5 in list_data1)
print(6 in list_data1)


# #### 리스트 메서드 활용하기

# **[4장: 54페이지]**

# In[ ]:


myFriends = ['James', 'Robert', 'Lisa', 'Mary']
print(myFriends)
myFriends.append('Thomas')
print(myFriends)


# **[4장: 55페이지]**

# In[ ]:


myFriends = ['James', 'Robert', 'Lisa', 'Mary']
print(myFriends)
myFriends.insert(1, 'Paul')
print(myFriends)


# **[4장: 55페이지]**

# In[ ]:


myFriends = ['James', 'Robert', 'Lisa', 'Mary']
print(myFriends)
myFriends.extend(['Laura', 'Betty'])
print(myFriends)


# ## 4.4 튜플

# ### 튜플 만들기

# **[4장: 56페이지]**

# In[ ]:


tuple1 = (1, 2, 3, 4)
tuple1


# **[4장: 56페이지]**

# In[ ]:


type(tuple1)


# **[4장: 56페이지]**

# In[ ]:


tuple1[1]


# **[4장: 56 ~ 57페이지]**

# In[ ]:


tuple2 = 5, 6, 7, 8
print(tuple2)


# In[ ]:


type(tuple2)


# **[4장: 57페이지]**

# In[ ]:


tuple3 = (9, )  # 반드시 쉼표(',') 필요
tuple4 = 10,  # 반드시 쉼표(',') 필요
print(tuple3)
print(tuple4)


# ### 튜플 다루기

# **[4장: 57페이지]**

# In[ ]:


tuple5 = (1, 2, 3, 4)
tuple5[1] = 5  # 한번 생성된 튜플의 요소는 변경되지 않음  - 에러남


# In[ ]:


del tuple5[1]  # 한번 생성된 튜플 요소는 삭제되지 않음 - 에러남


# **[4장: 58페이지]**

# In[ ]:


tuple6 = ('a', 'b', 'c', 'd', 'e', 'f')
tuple6.index('c')


# **[4장: 58페이지]**

# In[ ]:


tuple7 = ('a', 'a', 'a', 'b', 'b', 'c', 'd')
tuple7.count('a')


# ## 4.5 세트

# ### 세트 만들기

# **[4장: 59페이지]**

# In[ ]:


set1 = {1, 2, 3}
set1a = {1, 2, 3, 3}
print(set1)
print(set1a)


# **[4장: 59페이지]**

# In[ ]:


type(set1)


# ### 세트의 교집합, 합집합, 차집합 구하기

# **[4장: 60페이지]**

# In[ ]:


A = {1, 2, 3, 4, 5}         # Set A
B = {4, 5, 6, 7, 8, 9, 10}  # Set B
A.intersection(B)  # 집합 A에 대한 집합 B의 교집합(A∩B)


# In[ ]:


A.union(B)  # 집합 A에 대한 집합 B의 합집합(A∪B)


# In[ ]:


A.difference(B)  # 집합 A에 대한 집합 B의 차집합(A-B)


# **[4장: 60 ~ 61페이지]**

# In[ ]:


A = {1, 2, 3, 4, 5}         # Set A
B = {4, 5, 6, 7, 8, 9, 10}  # Set B
A & B  # 집합 A에 대한 집합 B의 교집합(A∩B)


# In[ ]:


A | B  # 집합 A에 대한 집합 B의 합집합(A∪B)


# In[ ]:


A - B  # 집합 A에 대한 집합 B의 차집합(A-B)


# ### 리스트, 튜플, 세트 간 타입 변환

# **[4장: 61페이지]**

# In[ ]:


a = [1, 2, 3, 4, 5]


# In[ ]:


type(a)


# **[4장: 61페이지]**

# In[ ]:


b = tuple(a)
b


# In[ ]:


type(b)


# **[4장: 61페이지]**

# In[ ]:


c = set(a)
c


# In[ ]:


type(c)


# **[4장: 62페이지]**

# In[ ]:


list(b)


# In[ ]:


list(c)


# ## 4.6 딕셔너리

# ### 딕셔너리 만들기

# **[4장: 63페이지]**

# In[ ]:


country_capital = {"영국": "런던", "프랑스": "파리", "스위스": "베른",
                   "호주": "멜버른", "덴마크": "코펜하겐"}
country_capital


# **[4장: 63페이지]**

# In[ ]:


type(country_capital)


# **[4장: 63페이지]**

# In[ ]:


country_capital["영국"]


# **[4장: 64페이지]**

# In[ ]:


dict_data1 = {1: "버스", 3: "비행기", 4: "택시", 5: "자전거"}
dict_data1


# **[4장: 64페이지]**

# In[ ]:


dict_data1[3]


# **[4장: 64페이지]**

# In[ ]:


dict_data2 = {1: 10, 2: 20, 3: 30, 4: 40, 5: 50}
print(dict_data2)
print(dict_data2[4])


# **[4장: 64페이지]**

# In[ ]:


dict_data3 = {"list_data1": [11, 12, 13], "list_data2": [21, 22, 23]}
print(dict_data3)
print(dict_data3["list_data2"])


# **[4장: 64페이지]**

# In[ ]:


mixed_dict = {1: 10, 'dict_num': {1: 10, 2: 20},
              "dict_list_tuple": {"A": [11, 12, 13], "B": (21, 22, 23)},
              "dict_string": "이것은 책입니다."}
mixed_dict


# ### 딕셔너리 다루기

# #### 딕셔너리에 데이터 추가하고 변경하기

# **[4장: 65페이지]**

# In[ ]:


country_capital["독일"] = "베를린"
country_capital


# **[4장: 65페이지]**

# In[ ]:


country_capital["호주"] = "캔버라"
country_capital


# #### 딕셔너리에서 데이터 삭제하기

# **[4장: 66페이지]**

# In[ ]:


del country_capital["덴마크"]
country_capital


# #### 딕셔너리 메서드 활용하기

# **[4장: 66페이지]**

# In[ ]:


fruit_code = {"사과": 101, "배": 102, "딸기": 103, "포도": 104, "바나나": 105}


# **[4장: 66페이지]**

# In[ ]:


print(fruit_code.keys())


# **[4장: 66페이지]**

# In[ ]:


print(fruit_code.values())


# **[4장: 67페이지]**

# In[ ]:


print(fruit_code.items())


# **[4장: 67페이지]**

# In[ ]:


list(fruit_code.keys())


# In[ ]:


list(fruit_code.values())


# In[ ]:


list(fruit_code.items())


# **[4장: 67페이지]**

# In[ ]:


fruit_code2 = {"오렌지": 106, "수박": 107}


# **[4장: 67페이지]**

# In[ ]:


fruit_code.update(fruit_code2)
fruit_code


# **[4장: 68페이지]**

# In[ ]:


fruit_code2.clear()
print(fruit_code2)
type(fruit_code2)


# # 4.7 정리
