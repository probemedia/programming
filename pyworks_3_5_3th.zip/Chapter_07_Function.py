#!/usr/bin/env python
# coding: utf-8

# # 7장 함수

# ## 7.1 함수 정의와 호출

# ### 함수의 기본 구조
# 

# ### 인자도 반환 값도 없는 함수

# **[7장: 117페이지]**

# In[ ]:


def my_func():
    print("My first function!")
    print("This is a function.")


# **[7장: 118페이지]**

# In[ ]:


my_func()


# ### 인자는 있으나 반환 값이 없는 함수

# **[7장: 118페이지]**

# In[ ]:


def my_friend(friendName):
    print("{}는 나의 친구입니다.".format(friendName))


# **[7장: 118페이지]**

# In[ ]:


my_friend("철수")
my_friend("영미")


# **[7장: 118 ~ 119페이지]**

# In[ ]:


def my_student_info(name, school_ID, phoneNumber):
    print("------------------------")
    print("- 학생이름:", name)
    print("- 학급번호:", school_ID)
    print("- 전화번호:", phoneNumber)


# **[7장: 119페이지]**

# In[ ]:


my_student_info("현아", "01", "01-235-6789")
my_student_info("진수", "02", "01-987-6543")


# **[7장: 119페이지]**

# In[ ]:


def my_student_info(name, school_ID,  phoneNumber):
    print("****************************")
    print("* 학생이름:", name)
    print("* 학급번호:", school_ID)
    print("* 전화번호:", phoneNumber)


# **[7장: 119페이지]**

# In[ ]:


my_student_info("현아", "01", "01-235-6789")
my_student_info("진수", "02", "01-987-6543")


# ### 인자도 있고 반환 값도 있는 함수

# **[7장: 120페이지]**

# In[ ]:


def my_calc(x, y):
    z = x * y
    return z


# **[7장: 120페이지]**

# In[ ]:


my_calc(3, 4)


# **[7장: 120페이지]**

# In[ ]:


def my_student_info_list(student_info):
    print("****************************")
    print("* 학생이름:", student_info[0])
    print("* 학급번호:", student_info[1])
    print("* 전화번호:", student_info[2])
    print("****************************")


# **[7장: 120페이지]**

# In[ ]:


student1_info = ["현아", "01", "01-235-6789"]
my_student_info_list(student1_info)


# **[7장: 121페이지]**

# In[ ]:


my_student_info_list(["진수", "02", "01-987-6543"])


# ## 7.2 변수의 유효 범위

# **[7장: 122페이지]**

# In[ ]:


a = 5  # 전역 변수


def func1():
    a = 1  # 지역 변수. func1()에서만 사용
    print("[func1] 지역 변수 a =", a)


def func2():
    a = 2  # 지역 변수. func2()에서만 사용
    print("[func2] 지역 변수 a =", a)


def func3():
    print("[func3] 전역 변수 a =", a)


def func4():
    global a  # 함수 내에서 전역 변수 변경 위해 선언
    a = 4      # 전역 변수의 값 변경
    print("[func4] 전역 변수 a =", a)


# **[7장: 122페이지]**

# In[ ]:


func1()  # 함수 func1() 호출
func2()  # 함수 func2() 호출
print("전역 변수 a =", a)  # 전역 변수 출력


# **[7장: 123페이지]**

# In[ ]:


func3()  # 함수 func3() 호출
func4()  # 함수 func4() 호출
func3()  # 함수 func3() 호출


# ## 7.3 람다(lambda) 함수

# **[7장: 124페이지]**

# In[ ]:


(lambda x: x ** 2)(3)


# **[7장: 124페이지]**

# In[ ]:


mySquare = (lambda x: x ** 2)
mySquare(2)


# **[7장: 124페이지]**

# In[ ]:


mySquare(5)


# **[7장: 124페이지]**

# In[ ]:


mySimpleFunc = (lambda x, y, z: 2 * x + 3 * y + z)
mySimpleFunc(1, 2, 3)


# ## 7.4 유용한 내장 함수

# ### 형 변환 함수

# #### 정수형으로 변환

# **[7장: 125페이지]**

# In[ ]:


[int(0.123), int(3.5123456), int(-1.312367)]


# **[7장: 125페이지]**

# In[ ]:


[int('1234'), int('5678'), int('-9012')]


# #### 실수형으로 변환

# **[7장: 125페이지]**

# In[ ]:


[float(0), float(123), float(-567)]


# **[7장: 126페이지]**

# In[ ]:


[float('10'), float('0.123'), float('-567.89')]


# #### 문자형으로 변환

# **[7장: 126페이지]**

# In[ ]:


[str(123), str(459678), str(-987)]


# **[7장: 126페이지]**

# In[ ]:


[str(0.123), str(345.678), str(-5.987)]


# #### 리스트, 튜플, 세트형으로 변환

# **[7장: 127페이지]**

# In[ ]:


list_data = ['abc', 1, 2, 'def']
tuple_data = ('abc', 1, 2, 'def')
set_data = {'abc', 1, 2, 'def'}


# **[7장: 127페이지]**

# In[ ]:


[type(list_data), type(tuple_data), type(set_data)]


# **[7장: 127페이지]**

# In[ ]:


print("리스트로 변환: ", list(tuple_data), list(set_data))


# **[7장: 127페이지]**

# In[ ]:


print("튜플로 변환:", tuple(list_data), tuple(set_data))


# **[7장: 127페이지]**

# In[ ]:


print("세트로 변환:", set(list_data), set(tuple_data))


# ### bool 함수

# #### 숫자를 인자로 bool 함수 호출

# **[7장: 128페이지]**

# In[ ]:


bool(0)  # 인자: 숫자 0


# **[7장: 128페이지]**

# In[ ]:


bool(1)  # 인자: 양의 정수


# In[ ]:


bool(-10)  # 인자: 음의 정수


# In[ ]:


bool(5.12)  # 인자: 양의 실수


# In[ ]:


bool(-3.26)  # 인자: 음의 실수


# #### 문자열을 인자로 bool 함수 호출

# **[7장: 128 ~ 129페이지]**

# In[ ]:


bool('a')  # 인자: 문자열 'a'


# In[ ]:


bool(' ') # 인자: 빈 문자열(공백)


# In[ ]:


bool('')  # 인자: 문자열 없음


# In[ ]:


bool(None)  # 인자: None


# #### 리스트, 튜플, 세트를 인자로 bool 함수 호출

# **[7장: 129페이지]**

# In[ ]:


myFriends = []
bool(myFriends)  # 인자: 항목이 없는 빈 리스트


# **[7장: 129페이지]**

# In[ ]:


myFriends = ['James', 'Robert', 'Lisa', 'Mary']
bool(myFriends)  # 인자: 항목이 있는 리스트


# **[7장: 129 ~ 130페이지]**

# In[ ]:


myNum = ()
bool(myNum)  # 인자: 항목이 없는 빈 튜플


# In[ ]:


myNum = (1, 2, 3)
bool(myNum)  # 인자: 항목이 있는 튜플


# **[7장: 130페이지]**

# In[ ]:


mySetA = {}
bool(mySetA)  # 인자: 항목이 없는 빈 세트


# In[ ]:


mySetA = {10, 20, 30}
bool(mySetA)  # 인자: 항목이 있는 세트


# #### bool 함수의 활용

# **[7장: 130페이지]**

# In[ ]:


def print_name(name):
    if bool(name):
        print("입력된 이름:", name)
    else:
        print("입력된 이름이 없습니다.")


# **[7장: 130페이지]**

# In[ ]:


print_name("James")


# In[ ]:


print_name("")


# ### 최솟값과 최댓값을 구하는 함수

# **[7장: 131페이지]**

# In[ ]:


myNum = [10, 5, 12, 0, 3.5, 99.5, 42]
[min(myNum), max(myNum)]


# **[7장: 131페이지]**

# In[ ]:


myStr = 'zxyabc'
[min(myStr), max(myStr)]


# **[7장: 131페이지]**

# In[ ]:


myNum = (10, 5, 12, 0, 3.5, 99.5, 42)
[min(myNum), max(myNum)]


# In[ ]:


myNum = {"Abc", "abc", "bcd", "efg"}
[min(myNum), max(myNum)]


# ### 절댓값과 전체 합을 구하는 함수

# **[7장: 132페이지]**

# In[ ]:


[abs(10), abs(-10)]


# In[ ]:


[abs(2.45), abs(-2.45)]


# **[7장: 132페이지]**

# In[ ]:


sumList = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
sum(sumList)


# ### 항목의 개수를 구하는 함수

# **[7장: 132 ~ 133페이지]**

# In[ ]:


len("ab cd")  # 문자열


# In[ ]:


len([1, 2, 3, 4, 5, 6, 7, 8])  # 리스트


# In[ ]:


len((1, 2, 3, 4, 5))  # 튜플


# In[ ]:


len({'a', 'b', 'c', 'd'})  # 세트


# In[ ]:


len({1: "Thomas", 2: "Edward", 3: "Henry"})  # 딕셔너리


# ### 내장 함수의 활용

# **[7장: 133페이지]**

# In[ ]:


scores = [90, 80, 95, 85]  # 과목별 시험 점수

score_sum = 0                     # 총점 계산을 위한 초깃값 설정
subject_num = 0                   # 과목수 계산을 위한 초깃값 설정
for score in scores:
    score_sum = score_sum + score  # 과목별 점수 모두 더하기
    subject_num = subject_num + 1  # 과목수 계산

average = score_sum / subject_num  # 평균(총점 / 과목수) 구하기

print("총점:{0}, 평균:{1}".format(score_sum, average))


# **[7장: 134페이지]**

# In[ ]:


scores = [90, 80, 95, 85]  # 과목별 시험 점수

print("총점:{0}, 평균:{1}".format(sum(scores), sum(scores)/len(scores)))

# **[7장: 134페이지]**

# In[ ]:


print("최하 점수:{0}, 최고 점수:{1}".format(min(scores), max(scores)))


# # 7.5 정리
