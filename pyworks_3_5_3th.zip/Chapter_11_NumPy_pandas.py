#!/usr/bin/env python
# coding: utf-8

# # 11장 데이터 분석을 위한 패키지

# ## 11.1 배열 데이터를 효과적으로 다루는 NumPy

# ### 배열 생성하기

# **[11장: 215페이지]**

# In[ ]:


import numpy as np


# #### 시퀀스 데이터로부터 배열 생성

# **[11장: 215 ~ 216페이지]**

# In[ ]:


import numpy as np

data1 = [0, 1, 2, 3, 4, 5]
a1 = np.array(data1)
a1


# **[11장: 216페이지]**

# In[ ]:


data2 = [0.1, 5, 4, 12, 0.5]
a2 = np.array(data2)
a2


# **[11장: 216페이지]**

# In[ ]:


a1.dtype


# In[ ]:


a2.dtype


# **[11장: 216페이지]**

# In[ ]:


np.array([0.5, 2, 0.01, 8])


# **[11장: 217페이지]**

# In[ ]:


np.array([[1,2,3], [4,5,6], [7,8,9]])


# #### 범위를 지정해 배열 생성

# **[11장: 217페이지]**

# In[ ]:


np.arange(0, 10, 2)


# In[ ]:


np.arange(1, 10)


# In[ ]:


np.arange(5)


# **[11장: 218페이지]**

# In[ ]:


np.arange(12).reshape(4,3)


# **[11장: 218페이지]**

# In[ ]:


b1 = np.arange(12).reshape(4,3)
b1.shape


# **[11장: 219페이지]**

# In[ ]:


b2 = np.arange(5)
b2.shape


# **[11장: 219페이지]**

# In[ ]:


np.linspace(1, 10, 10)


# **[11장: 219페이지]**

# In[ ]:


np.linspace(0, np.pi, 20 )


# #### 특별한 형태의 배열 생성

# **[11장: 220페이지]**

# In[ ]:


np.zeros(10)


# **[11장: 220페이지]**

# In[ ]:


np.zeros((3,4))


# **[11장: 220 ~ 221페이지]**

# In[ ]:


np.ones(5)


# In[ ]:


np.ones((3,5))


# **[11장: 221페이지]**

# In[ ]:


np.eye(3)


# #### 배열의 데이터 타입 변환

# **[11장: 221페이지]**

# In[ ]:


np.array(['1.5', '0.62', '2', '3.14', '3.141592'])


# **[11장: 222페이지]**

# In[ ]:


str_a1 = np.array(['1.567', '0.123', '5.123', '9', '8'])
num_a1 = str_a1.astype(float)
num_a1


# **[11장: 223페이지]**

# In[ ]:


str_a1.dtype


# In[ ]:


num_a1.dtype


# **[11장: 223페이지]**

# In[ ]:


str_a2 = np.array(['1', '3', '5', '7', '9'])
num_a2 = str_a2.astype(int)
num_a2


# **[11장: 223페이지]**

# In[ ]:


str_a2.dtype


# In[ ]:


num_a2.dtype


# **[11장: 223페이지]**

# In[ ]:


num_f1 = np.array([10, 21, 0.549, 4.75, 5.98])
num_i1 = num_f1.astype(int)
num_i1


# **[11장: 224페이지]**

# In[ ]:


num_f1.dtype


# In[ ]:


num_i1.dtype


# #### 난수 배열의 생성

# **[11장: 224 ~ 225페이지]**

# In[ ]:


np.random.rand(2, 3)


# In[ ]:


np.random.rand()


# In[ ]:


np.random.rand(2, 3, 4)


# **[11장: 225페이지]**

# In[ ]:


np.random.randint(10, size=(3, 4))


# In[ ]:


np.random.randint(1, 30)


# ### 배열의 연산

# #### 기본 연산

# **[11장: 225페이지]**

# In[ ]:


arr1 = np.array([10, 20, 30, 40])
arr2 = np.array([1, 2, 3, 4])


# **[11장: 226페이지]**

# In[ ]:


arr1 + arr2


# **[11장: 226페이지]**

# In[ ]:


arr1 - arr2


# **[11장: 226페이지]**

# In[ ]:


arr2 * 2


# **[11장: 226페이지]**

# In[ ]:


arr2 ** 2


# **[11장: 226페이지]**

# In[ ]:


arr1 * arr2


# **[11장: 227페이지]**

# In[ ]:


arr1 / arr2


# **[11장: 227페이지]**

# In[ ]:


arr1 / (arr2 ** 2)


# **[11장: 227페이지]**

# In[ ]:


arr1 > 20


# #### 통계를 위한 연산

# **[11장: 227페이지]**

# In[ ]:


arr3 = np.arange(5)
arr3


# **[11장: 227페이지]**

# In[ ]:


[arr3.sum(), arr3.mean()]


# **[11장: 228페이지]**

# In[ ]:


[arr3.std(), arr3.var()]


# **[11장: 228페이지]**

# In[ ]:


[arr3.min(), arr3.max()]


# **[11장: 228페이지]**

# In[ ]:


arr4 = np.arange(1,5)
arr4


# **[11장: 228페이지]** 

# In[ ]:


arr4.cumsum()


# In[ ]:


arr4.cumprod()


# #### 행렬 연산

# **[11장: 229페이지]**

# In[ ]:


A = np.array([0, 1, 2, 3]).reshape(2,2)
A


# In[ ]:


B = np.array([3, 2, 0, 1]).reshape(2,2)
B


# **[11장: 229페이지]**

# In[ ]:


A.dot(B)


# In[ ]:


np.dot(A,B)


# **[11장: 229 ~ 230페이지]**

# In[ ]:


np.transpose(A)


# In[ ]:


A.transpose()


# **[11장: 230페이지]**

# In[ ]:


np.linalg.inv(A)


# **[11장: 230페이지]**

# In[ ]:


np.linalg.det(A)


# ### 배열의 인덱싱과 슬라이싱

# #### 배열의 인덱싱

# **[11장: 230페이지]**

# In[ ]:


a1 = np.array([0, 10, 20, 30, 40, 50])
a1


# **[11장: 231페이지]**

# In[ ]:


a1[0]


# **[11장: 231페이지]**

# In[ ]:


a1[4]


# **[11장: 231페이지]**

# In[ ]:


a1[5] = 70
a1


# **[11장: 231페이지]**

# In[ ]:


a1[[1,3,4]]


# **[11장: 232페이지]**

# In[ ]:


a2 = np.arange(10, 100, 10).reshape(3,3)
a2


# **[11장: 232페이지]**

# In[ ]:


a2[0, 2]



# **[11장: 232페이지]**

# In[ ]:


a2[2, 2] = 95
a2


# **[11장: 232페이지]**

# In[ ]:


a2[1]


# **[11장: 232 ~ 233페이지]**

# In[ ]:


a2[1] = np.array([45, 55, 65])
a2


# In[ ]:


a2[1] = [47, 57, 67]
a2


# **[11장: 233페이지]**

# In[ ]:


a2[[0, 2], [0, 1]]


# **[11장: 233페이지]**

# In[ ]:


a = np.array([1, 2, 3, 4, 5, 6])
a[a > 3]


# **[11장: 234페이지]**

# In[ ]:


a[(a % 2) == 0]


# #### 배열의 슬라이싱

# **[11장: 234페이지]**

# In[ ]:


b1 = np.array([0, 10, 20, 30, 40, 50])
b1[1:4]


# **[11장: 234페이지]**

# In[ ]:


b1[:3]


# In[ ]:


b1[2:]


# **[11장: 235페이지]**

# In[ ]:


b1[2:5] = np.array([25, 35, 45])
b1


# **[11장: 235페이지]**

# In[ ]:


b1[3:6] = 60
b1


# **[11장: 235페이지]**

# In[ ]:


b2 = np.arange(10, 100, 10).reshape(3, 3)
b2


# **[11장: 236페이지]**

# In[ ]:


b2[1:3, 1:3]


# **[11장: 236페이지]**

# In[ ]:


b2[:3, 1:]


# **[11장: 236페이지]**

# In[ ]:


b2[1][0:2]


# **[11장: 236페이지]**

# In[ ]:


b2[0:2, 1:3] = np.array([[25, 35], [55, 65]])
b2


# ## 11.2 구조적 데이터 표시와 처리에 강한 pandas

# ### 구조적 데이터 생성하기

# #### Series를 활용한 데이터 생성

# **[11장: 237페이지]**

# In[ ]:


import pandas as pd


# **[11장: 238페이지]**

# In[ ]:


s1 = pd.Series([10, 20, 30, 40, 50])
s1


# **[11장: 238페이지]**

# In[ ]:


s1.index
print(s1.index)


# **[11장: 239페이지]**

# In[ ]:


s1.values


# **[11장: 239페이지]**

# In[ ]:


s2 = pd.Series(['a', 'b', 'c', 1, 2, 3])
s2


# **[11장: 239페이지]**

# In[ ]:


import numpy as np

s3 = pd.Series([np.nan, 10, 30])
s3


# **[11장: 240페이지]**

# In[ ]:


index_date = ['2018-10-07', '2018-10-08', '2018-10-09', '2018-10-10']
s4 = pd.Series([200, 195, np.nan, 205], index=index_date)
s4


# **[11장: 241페이지]**

# In[ ]:


s5 = pd.Series({'국어': 100, '영어': 95, '수학': 90})
s5


# #### 날짜 자동 생성: date_range

# **[11장: 241페이지]**

# In[ ]:


import pandas as pd

pd.date_range(start='2019-01-01', end='2019-01-07')


# **[11장: 242페이지]**

# In[ ]:


pd.date_range(start='2019/01/01', end='2019.01.07')


# In[ ]:


pd.date_range(start='01-01-2019', end='01/07/2019')


# In[ ]:


pd.date_range(start='2019-01-01', end='01.07.2019')


# **[11장: 242페이지]**

# In[ ]:


pd.date_range(start='2019-01-01', periods=7)


# **[11장: 243페이지]**

# In[ ]:


pd.date_range(start='2019-01-01', periods=4, freq='2D')


# **[11장: 244페이지]**

# In[ ]:


pd.date_range(start='2019-01-01', periods=4, freq='W')


# **[11장: 244페이지]**

# In[ ]:


pd.date_range(start='2019-01-01', periods = 12, freq = '2BM')


# **[11장: 244페이지]**

# In[ ]:


pd.date_range(start='2019-01-01', periods=4, freq='QS')


# **[11장: 244페이지]**

# In[ ]:


pd.date_range(start='2019-01-01', periods=3, freq='AS')


# **[11장: 244페이지]**

# In[ ]:


pd.date_range(start='2019-01-01 08:00', periods=10, freq='H')


# **[11장: 245페이지]**

# In[ ]:


pd.date_range(start='2019-01-01 08:00', periods=10, freq='BH')


# **[11장: 245페이지]**

# In[ ]:


pd.date_range(start='2019-01-01 10:00', periods=4, freq='30min')


# **[11장: 245페이지]**

# In[ ]:


pd.date_range(start='2019-01-01 10:00', periods=4, freq='30T')


# **[11장: 246페이지]**

# In[ ]:


pd.date_range(start='2019-01-01 10:00:00', periods=4, freq='10S')


# **[11장: 246페이지]**

# In[ ]:


index_date = pd.date_range(start='2019-03-01', periods=5, freq='D')
pd.Series([51, 62, 55, 49, 58], index=index_date )


# #### DataFrame을 활용한 데이터 생성

# **[11장: 247페이지]**

# In[ ]:


import pandas as pd

pd.DataFrame([[1, 2, 3], [4, 5, 6], [7, 8, 9]])


# **[11장: 248페이지]**

# In[ ]:


import numpy as np
import pandas as pd

data_list = np.array([[10, 20, 30], [40, 50, 60], [70, 80, 90]])
pd.DataFrame(data_list)


# **[11장: 248페이지]**

# In[ ]:


import numpy as np
import pandas as pd

data = np.array([[1, 2, 3], [4, 5, 6], [7, 8 ,9], [10, 11, 12]])
index_date = pd.date_range('2019-09-01', periods=4)
columns_list = ['A', 'B', 'C']
pd.DataFrame(data, index=index_date, columns=columns_list)


# **[11장: 249페이지]**

# In[ ]:


table_data = {'연도': [2015, 2016, 2016, 2017, 2017],
              '지사': ['한국', '한국', '미국', '한국','미국'],
              '고객 수': [200, 250, 450, 300, 500]}
table_data


# **[11장: 249페이지]**

# In[ ]:


pd.DataFrame(table_data)


# **[11장: 250페이지]**

# In[ ]:


df = pd.DataFrame(table_data, columns=['연도', '지사', '고객 수'])
df


# **[11장: 251페이지]**

# In[ ]:


df.index


# In[ ]:


df.columns


# In[ ]:


df.values


# ### 데이터 연산

# **[11장: 251 ~ 252페이지]**

# In[ ]:


s1 = pd.Series([1, 2, 3, 4, 5])
s2 = pd.Series([10, 20, 30, 40, 50])
s1 + s2


# In[ ]:


s2 - s1


# In[ ]:


s1 * s2


# In[ ]:


s2 / s1


# **[11장: 252 ~ 253페이지]**

# In[ ]:


s3 = pd.Series([1, 2, 3, 4])
s4 = pd.Series([10, 20, 30, 40, 50])
s3 + s4


# In[ ]:


s4 - s3


# In[ ]:


s3 * s4


# In[ ]:


s4 / s3


# **[11장: 253 ~ 254페이지]**

# In[ ]:


table_data1 = {'A': [1, 2, 3, 4, 5],
               'B': [10, 20, 30, 40, 50],
               'C': [100, 200, 300, 400, 500]}
df1 = pd.DataFrame(table_data1)
df1


# In[ ]:


table_data2 = {'A': [6, 7, 8],
               'B': [60, 70, 80],
               'C': [600, 700, 800]}
df2 = pd.DataFrame(table_data2)
df2


# **[11장: 254페이지]**

# In[ ]:


df1 + df2


# **[11장: 255페이지]**

# In[ ]:


table_data3 = {'봄':  [256.5, 264.3, 215.9, 223.2, 312.8],
               '여름': [770.6, 567.5, 599.8, 387.1, 446.2],
               '가을': [363.5, 231.2, 293.1, 247.7, 381.6],
               '겨울': [139.3, 59.9, 76.9, 109.1, 108.1]}
columns_list = ['봄', '여름', '가을', '겨울']
index_list = ['2012', '2013', '2014', '2015', '2016']

df3 = pd.DataFrame(table_data3, columns=columns_list, index=index_list)
df3


# **[11장: 256페이지]**

# In[ ]:


df3.mean()


# In[ ]:


df3.std()


# **[11장: 256 ~ 257페이지]**

# In[ ]:


df3.mean(axis=1)


# In[ ]:


df3.std(axis=1)


# **[11장: 257페이지]**

# In[ ]:


df3.describe()


# ### 데이터를 원하는 대로 선택하기

# **[11장: 258페이지]**

# In[ ]:


import pandas as pd
import numpy as np

KTX_data = {'경부선 KTX': [39060, 39896, 42005, 43621, 41702, 41266, 32427],
            '호남선 KTX': [7313, 6967, 6873, 6626, 8675, 10622, 9228],
            '경전선 KTX': [3627, 4168, 4088, 4424, 4606, 4984, 5570],
            '전라선 KTX': [309, 1771, 1954, 2244, 3146, 3945, 5766],
            '동해선 KTX': [np.nan, np.nan, np.nan, np.nan, 2395, 3786, 6667]}
col_list = ['경부선 KTX', '호남선 KTX', '경전선 KTX', '전라선 KTX', '동해선 KTX']
index_list = ['2011', '2012', '2013', '2014', '2015', '2016', '2017']

df_KTX = pd.DataFrame(KTX_data, columns=col_list, index=index_list)
df_KTX


# **[11장: 259페이지]**

# In[ ]:


df_KTX.index


# In[ ]:


df_KTX.columns


# In[ ]:


df_KTX.values


# **[11장: 260페이지]**

# In[ ]:


df_KTX.head()


# In[ ]:


df_KTX.tail()


# **[11장: 260 ~ 261페이지]**

# In[ ]:


df_KTX.head(3)


# In[ ]:


df_KTX.tail(2)


# **[11장: 261페이지]**

# In[ ]:


df_KTX[1:2]


# **[11장: 261페이지]**

# In[ ]:


df_KTX[2:5]


# **[11장: 262페이지]**

# In[ ]:


df_KTX.loc['2011']


# **[11장: 262페이지]**

# In[ ]:


df_KTX.loc['2013':'2016']


# **[11장: 263페이지]**

# In[ ]:


df_KTX['경부선 KTX']


# **[11장: 263페이지]**

# In[ ]:


df_KTX['경부선 KTX']['2012':'2014']


# **[11장: 264페이지]**

# In[ ]:


df_KTX['경부선 KTX'][2:5]


# **[11장: 264페이지]**

# In[ ]:


df_KTX.loc['2016']['호남선 KTX']


# In[ ]:


df_KTX.loc['2016', '호남선 KTX']


# In[ ]:


df_KTX['호남선 KTX']['2016']


# In[ ]:


df_KTX['호남선 KTX'][5]


# In[ ]:


df_KTX['호남선 KTX'].loc['2016']


# **[11장: 265페이지]**

# In[ ]:


df_KTX.T


# **[11장: 265페이지]**

# In[ ]:


df_KTX


# **[11장: 266페이지]**

# In[ ]:


df_KTX[['동해선 KTX', '전라선 KTX', '경전선 KTX', '호남선 KTX', '경부선 KTX']]


# ### 데이터 통합하기

# #### 세로 방향으로 통합하기

# **[11장: 267페이지]**

# In[ ]:


import pandas as pd
import numpy as np

df1 = pd.DataFrame({'Class1': [95, 92, 98, 100],
                    'Class2': [91, 93, 97, 99]})
df1


# **[11장: 267페이지]**

# In[ ]:


df2 = pd.DataFrame({'Class1': [87, 89],
                    'Class2': [85, 90]})
df2


# **[11장: 267페이지]**

# In[ ]:


df1.append(df2)


# **[11장: 268페이지]**

# In[ ]:


df1.append(df2, ignore_index=True)


# **[11장: 268페이지]**

# In[ ]:


df3 = pd.DataFrame({'Class1': [96, 83]})
df3


# **[11장: 269페이지]**

# In[ ]:


df2.append(df3, ignore_index=True)


# #### 가로 방향으로 통합하기

# **[11장: 269페이지]**

# In[ ]:


df4 = pd.DataFrame({'Class3': [93, 91, 95, 98]})
df4


# **[11장: 270페이지]**

# In[ ]:


df1.join(df4)


# **[11장: 270페이지]**

# In[ ]:


index_label = ['a', 'b', 'c', 'd']
df1a = pd.DataFrame({'Class1': [95, 92, 98, 100],
                    'Class2': [91, 93, 97, 99]}, index=index_label)
df4a = pd.DataFrame({'Class3': [93, 91, 95, 98]}, index=index_label)

df1a.join(df4a)


# **[11장: 270페이지]**

# In[ ]:


df5 = pd.DataFrame({'Class4': [82, 92]})
df5


# **[11장: 271페이지]**

# In[ ]:


df1.join(df5)


# #### 특정 열을 기준으로 통합하기

# **[11장: 271 ~272페이지]**

# In[ ]:


df_A_B = pd.DataFrame({'판매월': ['1월', '2월', '3월', '4월'],
                       '제품A': [100, 150, 200, 130],
                       '제품B': [90, 110, 140, 170]})
df_A_B


# In[ ]:


df_C_D = pd.DataFrame({'판매월': ['1월', '2월', '3월', '4월'],
                       '제품C': [112, 141, 203, 134],
                       '제품D': [90, 110, 140, 170]})
df_C_D


# **[11장: 272페이지]**

# In[ ]:


df_A_B.merge(df_C_D)


# **[11장: 273페이지]**

# In[ ]:


df_left = pd.DataFrame({'key': ['A', 'B', 'C'], 'left': [1, 2, 3]})
df_left


# In[ ]:


df_right = pd.DataFrame({'key': ['A', 'B', 'D'], 'right': [4, 5, 6]})
df_right


# **[11장: 274페이지]**

# In[ ]:


df_left.merge(df_right, how='left', on='key')


# In[ ]:


df_left.merge(df_right, how='right', on='key')


# In[ ]:


df_left.merge(df_right, how='outer', on='key')


# In[ ]:


df_left.merge(df_right, how='inner', on='key')


# ### 데이터 파일을 읽고 쓰기

# #### 표 형식의 데이터 파일을 읽기

# **[11장: 276페이지]**

# In[ ]:


get_ipython().run_cell_magic('writefile', 'C:\\myPyCode\\data\\sea_rain1.csv', '연도,동해,남해,서해,전체\n1996,17.4629,17.2288,14.436,15.9067\n1997,17.4116,17.4092,14.8248,16.1526\n1998,17.5944,18.011,15.2512,16.6044\n1999,18.1495,18.3175,14.8979,16.6284\n2000,17.9288,18.1766,15.0504,16.6178')
# get_ipython().run_cell_magic('writefile', 'D:\\pyworks_3_5_3th\\data\\sea_rain1.csv', '연도,동해,남해,서해,전체\n1996,17.4629,17.2288,14.436,15.9067\n1997,17.4116,17.4092,14.8248,16.1526\n1998,17.5944,18.011,15.2512,16.6044\n1999,18.1495,18.3175,14.8979,16.6284\n2000,17.9288,18.1766,15.0504,16.6178')

# **[11장: 276페이지]**

# In[ ]:


import pandas as pd

pd.read_csv('C:/myPyCode/data/sea_rain1.csv')

pd.read_csv('data/sea_rain1.csv')

# **[11장: 277페이지]**

# In[ ]:


pd.read_csv('C:/myPyCode/data/sea_rain1_from_notepad.csv', encoding = "cp949")
pd.read_csv('data/sea_rain1_from_notepad.csv', encoding = "cp949")

# **[11장: 277페이지]**

# In[ ]:


get_ipython().run_cell_magic('writefile', 'C:\\myPyCode\\data\\sea_rain1_space.txt', '연도 동해 남해 서해 전체\n1996 17.4629 17.2288 14.436 15.9067\n1997 17.4116 17.4092 14.8248 16.1526\n1998 17.5944 18.011 15.2512 16.6044\n1999 18.1495 18.3175 14.8979 16.6284\n2000 17.9288 18.1766 15.0504 16.6178')
# get_ipython().run_cell_magic('writefile', 'D:\\pyworks_3_5_3th\\data\\sea_rain1_space.txt', '연도 동해 남해 서해 전체\n1996 17.4629 17.2288 14.436 15.9067\n1997 17.4116 17.4092 14.8248 16.1526\n1998 17.5944 18.011 15.2512 16.6044\n1999 18.1495 18.3175 14.8979 16.6284\n2000 17.9288 18.1766 15.0504 16.6178')

# **[11장: 278페이지]**

# In[ ]:


pd.read_csv('C:/myPyCode/data/sea_rain1_space.txt', sep=" ")
pd.read_csv('data/sea_rain1_space.txt', sep=" ")


# **[11장: 278페이지]**

# In[ ]:


pd.read_csv('C:/myPyCode/data/sea_rain1.csv', index_col="연도" )
pd.read_csv('data/sea_rain1.csv', index_col="연도" )

# #### 표 형식의 데이터를 파일로 쓰기

# **[11장: 279페이지]**

# In[ ]:


df_WH = pd.DataFrame({'Weight': [62, 67, 55, 74],
                      'Height': [165, 177, 160, 180]},
                     index=['ID_1', 'ID_2', 'ID_3', 'ID_4'])
df_WH.index.name = 'User'
df_WH


# **[11장: 280페이지]**

# In[ ]:


bmi = df_WH['Weight'] / (df_WH['Height']/100) ** 2
bmi


# **[11장: 280페이지]**

# In[ ]:


df_WH['BMI'] = bmi
df_WH


# **[11장: 281페이지]**

# In[ ]:


df_WH.to_csv('C:/myPyCode/data/save_DataFrame.csv')
df_WH.to_csv('data/save_DataFrame.csv')

# **[11장: 281페이지]**

# In[ ]:


get_ipython().system('type C:\\myPyCode\\data\\save_DataFrame.csv')
# get_ipython().system('type D:\pyworks_3_5_3th\\data\\save_DataFrame.csv')

# **[11장: 281페이지]**

# In[ ]:


df_pr = pd.DataFrame({'판매가격':[2000, 3000, 5000, 10000],
                       '판매량':[32, 53, 40, 25]},
                       index=['P1001', 'P1002', 'P1003', 'P1004'])
df_pr.index.name = '제품번호'
df_pr


# **[11장: 281페이지]**

# In[ ]:


file_name = 'data/save_DataFrame_cp949.txt'
df_pr.to_csv(file_name, sep=" ", encoding="cp949")


# **[11장: 282페이지]**

# In[ ]:


get_ipython().system('type C:\\myPyCode\\data\\save_DataFrame_cp949.txt')
# get_ipython().system('type D:\\pyworks_3_5_3th\\data\\save_DataFrame_cp949.txt')

# ## 11.3 정리
