#!/usr/bin/env python
# coding: utf-8

# # 9장 문자열과 텍스트 파일 데이터 다루기

# ## 9.1 문자열 다루기

# ### 문자열 분리하기

# **[9장: 159페이지]**

# In[ ]:


coffee_menu_str = "에스프레소,아메리카노,카페라테,카푸치노"
coffee_menu_str.split(',')


# **[9장: 159페이지]**

# In[ ]:


"에스프레소,아메리카노,카페라테,카푸치노".split(',')


# **[9장: 160페이지]**

# In[ ]:


"에스프레소 아메리카노 카페라테 카푸치노".split(' ')


# **[9장: 160페이지]**

# In[ ]:


"에스프레소 아메리카노 카페라테 카푸치노".split()


# **[9장: 160페이지]**

# In[ ]:


"   에스프레소  \n\n  아메리카노  \n  카페라테   카푸치노 \n\n".split()


# **[9장: 160페이지]**

# In[ ]:


"에스프레소 아메리카노 카페라테 카푸치노".split(maxsplit=2)


# **[9장: 161페이지]**

# In[ ]:


phone_number = "+82-01-2345-6789" # 국가 번호가 포함된 전화번호
split_num = phone_number.split("-", 1) # 국가 번호와 나머지 번호 분리

print(split_num)
print("국내전화번호: {0}".format(split_num[1]))


# ### 필요없는 문자열 삭제하기

# **[9장: 162페이지]**

# In[ ]:


"aaaaPythonaaa".strip('a')


# **[9장: 162페이지]**

# In[ ]:


test_str = "aaabbPythonbbbaa"
temp1 = test_str.strip('a')  # 문자열 앞뒤의 'a' 제거
temp1


# **[9장: 162페이지]**

# In[ ]:


temp1.strip('b')  # 문자열 앞뒤의 'b' 제거


# **[9장: 162페이지]**

# In[ ]:


test_str.strip('ab')  # 문자열 앞뒤의 'a'와 'b' 제거


# **[9장: 162페이지]**

# In[ ]:


test_str.strip('ba')


# **[9장: 163페이지]**

# In[ ]:


test_str_multi = "##***!!!##....  Python is powerful.!...  %%!#..   "
test_str_multi.strip('*.#! %')


# **[9장: 163페이지]**

# In[ ]:


test_str_multi.strip('%* !#.')


# **[9장: 163페이지]**

# In[ ]:


"  Python   ".strip(' ')


# **[9장: 163페이지]**

# In[ ]:


"\n  Python  \n\n".strip(' \n')


# **[9장: 163페이지]**

# In[ ]:


"\n  Python  \n\n".strip()


# **[9장: 164페이지]**

# In[ ]:


"aaaBallaaa".strip('a')


# **[9장: 164페이지]**

# In[ ]:


"\n This is very \n fast. \n\n".strip()


# **[9장: 164페이지]**

# In[ ]:


str_lr = "000Python is easy to learn.000"
print(str_lr.strip('0'))
print(str_lr.lstrip('0'))
print(str_lr.rstrip('0'))


# **[9장: 165페이지]**

# In[ ]:


coffee_menu = "  에스프레소, 아메리카노,    카페라테   , 카푸치노  "
coffee_menu_list = coffee_menu.split(',')
coffee_menu_list


# **[9장: 165페이지]**

# In[ ]:


coffee_list = []  # 빈 리스트 생성
for coffee in coffee_menu_list:
    temp = coffee.strip()  # 문자열의 공백 제거
    coffee_list.append(temp)  # 리스트 변수에 공백이 제거된 문자열 추가

print(coffee_list)  # 최종 문자열 리스트 출력


# ### 문자열 연결하기

# **[9장: 165페이지]**

# In[ ]:


name1 = "철수"
name2 = "영미"

hello = "님, 주소와 전화 번호를 입력해 주세요."
print(name1 + hello)
print(name2 + hello)


# **[9장: 166페이지]**

# In[ ]:


address_list = ["서울시", "서초구", "반포대로", "201(반포동)"]
address_list


# **[9장: 166페이지]**

# In[ ]:


a = " "
a.join(address_list)


# **[9장: 167페이지]**

# In[ ]:


" ".join(address_list)


# **[9장: 167페이지]**

# In[ ]:


"*^-^*".join(address_list)


# ### 문자열 찾기

# **[9장: 168페이지]**

# In[ ]:


str_f = "Python code."

print("찾는 문자열의 위치:", str_f.find("Python"))
print("찾는 문자열의 위치:", str_f.find("code"))
print("찾는 문자열의 위치:", str_f.find("n"))
print("찾는 문자열의 위치:", str_f.find("easy"))


# **[9장: 168페이지]**

# In[ ]:


str_f_se = "Python is powerful. Python is easy to learn."

print(str_f_se.find("Python", 10, 30))  # 시작 위치(start)와 끝 위치(end) 지정
print(str_f_se.find("Python", 35))  # 찾기 위한 시작 위치(start) 지정


# **[9장: 169페이지]**

# In[ ]:


str_c = "Python is powerful. Python is easy to learn. Python is open."

print("Python의 개수는?:", str_c.count("Python"))
print("powerful의 개수는?:", str_c.count("powerful"))
print("IPython의 개수는?:", str_c.count("IPython"))


# **[9장: 170페이지]**

# In[ ]:


str_se = "Python is powerful. Python is easy to learn."

print("Python으로 시작?:", str_se.startswith("Python"))
print("is로 시작?:", str_se.startswith("is"))
print(".로 끝?:", str_se.endswith("."))
print("learn으로 끝?:", str_se.endswith("learn"))


# ### 문자열 바꾸기

# **[9장: 170페이지]**

# In[ ]:


str_a = 'Python is fast. Python is friendly. Python is open.'
print(str_a.replace('Python', 'IPython'))
print(str_a.replace('Python', 'IPython', 2))


# **[9장: 171페이지]**

# In[ ]:


str_b = '[Python] [is] [fast]'
str_b1 = str_b.replace('[', '')  # 문자열에서 '['를 제거
str_b2 = str_b1.replace(']', '')  # 결과 문자열에서 다시 ']'를 제거

print(str_b)
print(str_b1)
print(str_b2)


# ### 문자열의 구성 확인하기

# **[9장: 171페이지]**

# In[ ]:


print('Python'.isalpha())  # 문자열에 공백, 특수 문자, 숫자가 없음
print('Ver. 3.x'.isalpha())  # 공백, 특수 문자, 숫자 중 하나가 있음


# **[9장: 172페이지]**

# In[ ]:


print('12345'.isdigit())  # 문자열이 모두 숫자로 구성됨
print('12345abc'.isdigit())  # 문자열이 숫자로만 구성되지 않음


# **[9장: 172페이지]**

# In[ ]:


print('abc1234'.isalnum())  # 특수 문자나 공백이 아닌 문자와 숫자로 구성됨
print('   abc1234'.isalnum())  # 문자열에 공백이 있음


# **[9장: 172페이지]**

# In[ ]:


print('   '.isspace())  # 문자열이 공백으로만 구성됨
print(' 1 '.isspace())  # 문자열에 공백 외에 다른 문자가 있음


# **[9장: 172페이지]**

# In[ ]:


print('PYTHON'.isupper())  # 문자열이 모두 대문자로 구성됨
print('Python'.isupper())  # 문자열에 대문자와 소문자가 있음
print('python'.islower())  # 문자열이 모두 소문자로 구성됨
print('Python'.islower())  # 문자열에 대문자와 소문자가 있음


# ### 대소문자로 변경하기

# **[9장: 173페이지]**

# In[ ]:


string1 = 'Python is powerful. PYTHON IS EASY TO LEARN.'
print(string1.lower())
print(string1.upper())


# **[9장: 173페이지]**

# In[ ]:


'Python' == 'python'


# **[9장: 173페이지]**

# In[ ]:


print('Python'.lower() == 'python'.lower())
print('Python'.upper() == 'python'.upper())


# ## 9.2 텍스트 파일의 데이터를 읽고 처리하기

# ### 데이터 파일 준비 및 읽기

# **[9장: 174페이지]**

# In[ ]:


get_ipython().system('type c:\\myPyCode\\data\\coffeeShopSales.txt')
# get_ipython().system('type D:\\pyworks_3_5_3th\\data\\coffeeShopSales.txt')

# **[9장: 175페이지]**

# In[ ]:


# file_name = 'c:\myPyCode\data\coffeeShopSales.txt' 
file_name = 'data/coffeeShopSales.txt'

f = open(file_name)      # 파일 열기
for line in f:           # 한 줄씩 읽기
    print(line, end='')  # 한 줄씩 출력
f.close()                # 파일 닫기


# ### 파일에서 읽은 문자열 데이터 처리

# **[9장: 175 ~ 176페이지]**

# In[ ]:


f = open(file_name)   # 파일 열기
header = f.readline()  # 데이터의 첫 번째 줄을 읽음
f.close()             # 파일 닫기

header


# **[9장: 176페이지]**

# In[ ]:


header_list = header.split()  # 첫 줄의 문자열을 분리후 리스트로 변환
header_list


# **[9장: 176페이지]**

# In[ ]:


f = open(file_name)          # 파일 열기
header = f.readline()        # 데이터의 첫 번째 줄을 읽음
header_list = header.split()  # 첫 줄의 문자열을 분리한 후 리스트로 변환

for line in f:               # 두 번째 줄부터 데이터를 읽어서 반복적으로 처리
    data_list = line.split()  # 문자열을 분리해서 리스트로 변환
    print(data_list)         # 결과 확인을 위해 리스트 출력

f.close()                    # 파일 닫기


# **[9장: 177페이지]**

# In[ ]:


f = open(file_name)         # 파일 열기
header = f.readline()       # 데이터의 첫 번째 줄을 읽음
headerList = header.split()  # 첫 줄의 문자열을 분리한 후 리스트로 변환

espresso = []               # 커피 종류별로 빈 리스트 생성
americano = []
cafelatte = []
cappucino = []

for line in f:              # 두 번째 줄부터 데이터를 읽어서 반복적으로 처리
    dataList = line.split()  # 문자열에서 공백을 제거해서 문자열 리스트로 변환

    # 커피 종류별로 정수로 변환한 후, 리스트의 항목으로 추가
    espresso.append(int(dataList[1]))
    americano.append(int(dataList[2]))
    cafelatte.append(int(dataList[3]))
    cappucino.append(int(dataList[4]))

f.close()  # 파일 닫기

print("{0}: {1}".format(headerList[1], espresso))  # 변수에 할당된 값을 출력
print("{0}: {1}".format(headerList[2], americano))
print("{0}: {1}".format(headerList[3], cafelatte))
print("{0}: {1}".format(headerList[4], cappucino))


# **[9장: 178페이지]**

# In[ ]:


total_sum = [sum(espresso), sum(americano), sum(cafelatte), sum(cappucino)]
total_mean = [sum(espresso)/len(espresso), sum(americano)/len(americano),
              sum(cafelatte)/len(cafelatte), sum(cappucino)/len(cappucino)]

for k in range(len(total_sum)):
    print('[{0}] 판매량'.format(headerList[k+1]))
    print('- 나흘 전체: {0}, 하루 평균: {1}'.format(total_sum[k], total_mean[k]))


# # 9.3 정리
