#!/usr/bin/env python
# coding: utf-8

# # 15장 웹 API

# ## 15.1 웹 API의 이해

# ### 웹 API의 데이터 획득 과정

# ### 웹 API의 인증 방식

# ### 응답 데이터의 형식 및 처리

# #### JSON 형식의 데이터 처리

# **[15장: 458 ~ 459페이지]**

# In[ ]:


import json

python_dict = {
    "이름": "홍길동",
    "나이": 25,
    "거주지": "서울",
    "신체정보": {
        "키": 175.4,
        "몸무게": 71.2
    },
    "취미": [
        "등산",
        "자전거타기",
        "독서"
    ]
}
type(python_dict)


# **[15장: 459페이지]**

# In[ ]:


json_data = json.dumps(python_dict)
type(json_data)


# **[15장: 459페이지]**

# In[ ]:


print(json_data)


# **[15장: 459페이지]**

# In[ ]:


json_data = json.dumps(python_dict, indent=3, sort_keys=True, ensure_ascii=False)
print(json_data)


# **[15장: 460페이지]**

# In[ ]:


json_dict = json.loads(json_data)
type(json_dict)


# **[15장: 460페이지]**

# In[ ]:


json_dict['신체정보']['몸무게']


# **[15장: 460페이지]**

# In[ ]:


json_dict['취미']


# **[15장: 461페이지]**

# In[ ]:


json_dict['취미'][0]


# #### XML 형식의 데이터 처리

# **[15장: 465페이지]**

# In[ ]:


xml_data = """<?xml version="1.0" encoding="UTF-8" ?>
<사용자정보>
    <이름>홍길동</이름>
    <나이>25</나이>
    <거주지>서울</거주지>
    <신체정보>
        <키 unit="cm">175.4</키>
        <몸무게 unit="kg">71.2</몸무게>
    </신체정보>
    <취미>등산</취미>
    <취미>자전거타기</취미>
    <취미>독서</취미>
</사용자정보>
"""
print(xml_data)


# **[15장: 465페이지]**

# In[ ]:


import xmltodict

dict_data = xmltodict.parse(xml_data, xml_attribs=True)
dict_data


# **[15장: 466페이지]**

# In[ ]:


dict_data['사용자정보']['이름']


# **[15장: 466페이지]**

# In[ ]:


dict_data['사용자정보']['신체정보']


# **[15장: 466 ~ 467페이지]**

# In[ ]:


dict_data['사용자정보']['신체정보']['키']['@unit']


# In[ ]:


dict_data['사용자정보']['신체정보']['키']['#text']


# **[15장: 467페이지]**

# In[ ]:


import xmltodict

dict_data = xmltodict.parse(xml_data)

user_name = dict_data['사용자정보']['이름']
body_data = dict_data['사용자정보']['신체정보']

height = body_data['키']['#text']
height_unit = body_data['키']['@unit']

weight = body_data['몸무게']['#text']
weight_unit = body_data['몸무게']['@unit']

print("[사용자 {0}의 신체정보]".format(user_name))
print("*키: {0}{1}".format(height, height_unit))
print("*몸무게: {0}{1}".format(weight, weight_unit))


# **[15장: 467페이지]**

# In[ ]:


dict_data2 = xmltodict.parse(xml_data, xml_attribs=False)
dict_data2


# ### 웹 사이트 주소에 부가 정보 추가하기

# #### 웹 사이트 주소에 경로 추가하기

# **[15장: 468페이지]**

# In[ ]:


base_url = "https://api.github.com/"
sub_dir = "events"
url = base_url + sub_dir
print(url)


# **[15장: 469페이지]**

# In[ ]:


import requests

base_url = "https://api.github.com/"
sub_dirs = ["events", "user", "emails"]

for sub_dir in sub_dirs:
    url_dir = base_url + sub_dir
    r = requests.get(url_dir)
    print(r.url)


# #### 웹 사이트 주소에 매개변수 추가하기

# **[15장: 470페이지]**

# In[ ]:


import requests

LAT = '37.57'  # 위도
LON = '126.98'  # 경도
API_KEY = 'b235c57pc357fb68acr1e81'  # API 키(임의의 API 키)
UNIT = 'metric'  # 단위

site_url = "http://api.openweathermap.org/data/2.5/weather"
parameter = "?lat=%s&lon=%s&appid=%s&units=%s"%(LAT, LON, API_KEY, UNIT)
url_para = site_url + parameter
r = requests.get(url_para)

print(r.url)


# **[15장: 471페이지]**

# In[ ]:


import requests

LAT = '37.57'  # 위도
LON = '126.98'  # 경도
API_KEY = 'b235c57pc357fb68acr1e81'  # API 키(임의의 API 키)
UNIT = 'metric'  # 단위

req_url = "http://api.openweathermap.org/data/2.5/weather"
req_parameter = {"lat": LAT, "lon": LON, "appid": API_KEY, "units": UNIT}
r = requests.get(req_url, params=req_parameter)
print(r.url)


# #### 웹 사이트 주소의 인코딩과 디코딩

# **[15장: 471 ~ 472페이지]**

# In[ ]:


import requests

API_KEY = "et5piq3pfpqLEWPpCbvtSQ%2Bertertg%2Bx3evdvbaRBvhWEerg3efac2r3f3RfhDTERTw%2B9rkvoewRV%2Fovmrk3dq%3D%3D"

API_KEY_decode = requests.utils.unquote(API_KEY)

print("Encoded url:", API_KEY)
print("Decoded url:", API_KEY_decode)


# **[15장: 472페이지]**

# In[ ]:


req_url = "http://openapi.airkorea.or.kr/openapi/services/rest/MsrstnInfoInqireSvc/getNearbyMsrstnList"

tm_x = 244148.546388
tm_y = 412423.75772

req_parameter = {"ServiceKey": API_KEY_decode, "tmX": tm_x, "tmY": tm_y}

r = requests.get(req_url,  params=req_parameter)
print(r.url)


# **[15장: 473페이지]**

# In[ ]:


req_parameter = {"ServiceKey":API_KEY, "tmX":tm_x, "tmY":tm_y}

r = requests.get(req_url,  params = req_parameter)
print(r.url)


# ## 15.2 API 키를 사용하지 않고 데이터 가져오기

# ### 국제 우주 정거장의 정보 가져오기

# **[15장: 473 ~ 474페이지]**

# In[ ]:


import requests  
import json

url = "http://api.open-notify.org/iss-now.json"

r = requests.get(url)
print(r.text)


# **[15장: 474페이지]**

# In[ ]:


json_to_dict = json.loads(r.text)
type(json_to_dict)


# **[15장: 474 ~ 475페이지]**

# In[ ]:


import requests

url = "http://api.open-notify.org/iss-now.json"

r = requests.get(url)
json_to_dict = r.json()
type(json_to_dict)


# **[15장: 475페이지]**

# In[ ]:


import requests

url = "http://api.open-notify.org/iss-now.json"

json_to_dict = requests.get(url).json()
type(json_to_dict)


# **[15장: 475페이지]**

# In[ ]:


json_to_dict


# **[15장: 475페이지]**

# In[ ]:


print(json_to_dict["iss_position"])
print(json_to_dict["iss_position"]["latitude"])
print(json_to_dict["iss_position"]["longitude"])
print(json_to_dict["message"])
print(json_to_dict["timestamp"])


# **[15장: 476페이지]**

# In[ ]:


import requests
import time

url = "http://api.open-notify.org/iss-now.json"


def ISS_Position(iss_position_api_url):
    json_to_dict = requests.get(iss_position_api_url).json()
    return json_to_dict["iss_position"]


for k in range(5):
    print(ISS_Position(url))
    time.sleep(10)  # 10초 동안 코드 실행을 일시적으로 중지한다.


# ### 국가 정보 가져오기

# **[15장: 476 ~ 477페이지]**

# In[ ]:


import requests

url_temp = "https://restcountries.eu/rest/v1/name/"
country = "South Korea"
url = url_temp + country

r = requests.get(url)
print(r.text)


# **[15장: 477페이지]**

# In[ ]:


json_to_list = requests.get(url).json()
json_to_list


# **[15장: 478페이지]**

# In[ ]:


json_to_list[0]["capital"]


# **[15장: 478페이지]**

# In[ ]:


import requests
import json

countries = ["South Korea", "United States of America",
            "United Kingdom", "France", "Germany"]


def country_to_capital(country):
    url_temp = "https://restcountries.eu/rest/v1/name/"
    url = url_temp + country
    json_to_list = requests.get(url).json()
    return json_to_list[0]["capital"]


for country in countries:
    capital = country_to_capital(country)
    print("*{0}: {1}".format(country, capital))


# 트위터 개발자가 키가 없으면 실행 안 됨.
# ## 15.3 트위터에 메시지 작성하고 가져오기

#  ### API 키 및 접속 토큰 생성

# ### Tweepy 설치 및 인증

# **[15장: 485페이지]**

# In[ ]:


import tweepy

# 본인이 신청해서 생성한 문자열을 각각 복사해 넣습니다.
consumer_key = 'YOUR-CONSUMER-KEY'
consumer_secret = 'YOUR-CONSUMER-SECRET'

access_token = 'YOUR-ACCESS-TOKEN'
access_secret = 'YOUR-ACCESS-SECRET'


# **[15장: 485페이지]**

# In[ ]:


auth = tweepy.OAuthHandler(consumer_key, consumer_secret)
auth.set_access_token(access_token, access_secret)


# **[15장: 485페이지]**

# In[ ]:


api = tweepy.API(auth)


# **[15장: 486페이지]**

# In[ ]:


print("name:",api.me().name)


# ### 트윗 작성하기

# **[15장: 487페이지]**

# In[ ]:


tweet_update_status = api.update_status('파이썬에서 Tweepy 라이브러리를 이용한 첫 번째 트윗')


# **[15장: 487페이지]**

# In[ ]:


tweet_media_update_status = api.update_with_media("C:/myPyCode/figures/fig_for_excel1.png", 'tweepy를 이용한 이미지 올리기')


# ### 타임라인에서 메시지 가져오기

# **[15장: 488페이지]**

# In[ ]:


for status in tweepy.Cursor(api.home_timeline).items(2):
    print("*", status.text)


# **[15장: 489페이지]**

# In[ ]:


for status in tweepy.Cursor(api.home_timeline).items(2):
    print("*", status._json['text'])
    print(" ==> Created at", status._json['created_at'])


# ### 키워드를 지정해 데이터 가져오기

# **[15장: 490페이지]**

# In[ ]:


import tweepy

class MyStreamListener(tweepy.StreamListener):
    
    def on_status(self, status):
        print(status.text) # 140자까지 출력


# **[15장: 490페이지]**

# In[ ]:


myStreamListener = MyStreamListener()


# **[15장: 490페이지]**

# In[ ]:


myStream = tweepy.Stream(auth, myStreamListener)


# **[15장: 491페이지]**

# In[ ]:


#myStream.filter(track = ['파이썬', 'python'])


# **[15장: 491페이지]**

# In[ ]:


class MyStreamListener(tweepy.StreamListener):

    def __init__(self):
        super().__init__()
        self.tweet_num = 0

    def on_status(self, status):
        self.tweet_num = self.tweet_num + 1
        if(self.tweet_num <= 5):
            print("***", status.text) # 140자까지 출력
            return True
        else:
            return False


# **[15장: 491페이지]**

# In[ ]:


myStreamListener = MyStreamListener()
myStream = tweepy.Stream(auth, myStreamListener)
myStream.filter(track = ['머신 러닝', 'Machine Learning'])


# **[15장: 492 ~ 493페이지]**

# In[ ]:


import tweepy
 
# 키, 토근, 비밀번호 지정
consumer_key = 'YOUR-CONSUMER-KEY'
consumer_secret = 'YOUR-CONSUMER-SECRET'

access_token = 'YOUR-ACCESS-TOKEN'
access_secret = 'YOUR-ACCESS-SECRET'

# OAuth 인증 진행
auth = tweepy.OAuthHandler(consumer_key, consumer_secret)
auth.set_access_token(access_token, access_secret)
 
# 인증된 auth 변수를 이용해 트위터 API 클래스의 정의
class MyStreamListener2(tweepy.StreamListener):

    def __init__(self, max_num):
        super().__init__()
        self.tweet_num = 0
        self.max_num = max_num
    
    def on_status(self, status):
        self.tweet_num = self.tweet_num + 1
        file_name = 'C:/myPyCode/data/twitter_stream_test.txt'
        if(self.tweet_num <= self.max_num ):
            with open(file_name, 'a', encoding="utf-8") as f:
                write_text = "*** " + status.text + "\n"
                f.write(write_text)
            return True
        else:
            return False
            
    def on_error(self, status):
        print(status) # 오류 메시지 출력
        return False
        
if __name__ == '__main__':  
    myStreamListener = MyStreamListener2(5)
    myStream = tweepy.Stream(auth, myStreamListener)
    myStream.filter(track = ['머신 러닝', 'Machine Learning'])
    print("End of streaming!")


# ## 15.4 정부의 공공 데이터 가져오기

# ### 회원 가입 및 서비스 신청

# ### 주소 및 우편번호 가져오기

# **[15장: 502페이지]**

# In[ ]:


import requests

API_KEY  = 'YOUR-API-KEY' # 자신의 인증키를 복사해서 입력합니다.
API_KEY_decode = requests.utils.unquote(API_KEY)
API_KEY_decode


# **[15장: 503페이지]**

# In[ ]:


req_url = "http://openapi.epost.go.kr/postal/retrieveNewAdressAreaCdService/retrieveNewAdressAreaCdService/getNewAddressListAreaCd"

search_Se = "road" 
srch_wrd = "반포대로 201"

req_parameter = {"ServiceKey":API_KEY_decode, "searchSe":search_Se, "srchwrd":srch_wrd}

r = requests.get(req_url, params = req_parameter)
xml_data = r.text
print(xml_data)


# **[15장: 503페이지]**

# In[ ]:


import xmltodict

dict_data = xmltodict.parse(xml_data)
dict_data


# **[15장: 504페이지]**

# In[ ]:


adress_list = dict_data['NewAddressListResponse']['newAddressListAreaCd']

print("[입력한 도로명 주소]", srch_wrd)
print("[응답 데이터에서 추출한 결과]")
print("- 우편번호:", adress_list['zipNo'])
print("- 도로명 주소:", adress_list['lnmAdres'])
print("- 지번 주소:", adress_list['rnAdres'])


# ### 날씨 정보 가져오기

# #### 날씨 정보를 위한 서비스 신청

# #### 날씨 실황 조회

# **[15장: 509페이지]**

# In[ ]:


import requests

API_KEY  = 'YOUR-API-KEY' # 자신의 인증키를 복사해서 입력합니다.
API_KEY_decode = requests.utils.unquote(API_KEY)
API_KEY_decode


# **[15장: 510 ~ 511페이지]**

# In[ ]:


import json
import datetime

# [날짜 및 시간 설정]
now = datetime.datetime.now() # 현재 날짜 및 시간 반환

# baseDate에 날짜를 입력하기 위해 날짜를 출력 형식을 지정해 변수에 할당
date = "{:%Y%m%d}".format(now) 

# baseTime에 시간(정시)를 입력하기 위해 출력 형식을 지정해 시간만 변수에 할당
time = "{:%H00}".format(now)

# 현재 분이 30분 이전이면 이전 시간(정시)을 설정
if (now.minute >= 30):
    time = "{0}00".format(now.hour)
else:
    time = "{0}00".format(now.hour-1)

# [요청 주소 및 요청 변수 지정]
req_url = "http://newsky2.kma.go.kr/service/SecndSrtpdFrcstInfoService2/ForecastGrib"

baseDate = date # 발표 일자 지정
baseTime = time  # 발표 시간 지정(정시로 지정)

nx_val = 60 # 예보지점 X 좌표(서울시 종로구 사직동)
ny_val = 127 # 예보지점 Y 좌표(서울시 종로구 사직동)

num_of_rows = 6 # 한 페이지에 포함된 결과 수
page_no = 1 # 페이지 번호

output_type = "json" # 응답 데이터 형식 지정

req_parameter = {"ServiceKey":API_KEY_decode, 
                 "nx":nx_val, "ny": ny_val, 
                 "base_date":baseDate, "base_time":baseTime, 
                 "pageNo":page_no, "numOfRows":num_of_rows, 
                 "_type":output_type}

# [데이터 요청]
r = requests.get(req_url, params = req_parameter)

# [JSON 형태로 응답받은 데이터를 딕셔너리 데이터로 변환]
dict_data = r.json()
dict_data


# **[15장: 512 ~ 513페이지]**

# In[ ]:


# [딕셔너리 데이터를 분석해서 원하는 값 추출]

weather_items = dict_data['response']['body']['items']['item']

sky_cond = ["맑음", "구름 조금", "구름 많음", "흐림"]
rain_type = ["없음", "비", "진눈개비", "눈"] 

print("[ 발표 날짜: {} ]".format(weather_items[0]['baseDate']))
print("[ 발표 시간: {} ]".format(weather_items[0]['baseTime']))

for k in range(len(weather_items)):
    weather_item = weather_items[k]
    obsrValue = weather_item['obsrValue']
    if(weather_item['category'] == 'T1H'):
        print("* 기온: {} 도".format(obsrValue))
    elif(weather_item['category'] == 'REH'):
        print("* 습도: {} 퍼센트".format(obsrValue))
    elif(weather_item['category'] == 'SKY'):
        print("* 하늘: {}".format(sky_cond[obsrValue-1]))    
    elif(weather_item['category'] == 'PTY'):
        print("* 강수: {}".format(rain_type[obsrValue])) 


# #### 일기 예보 조회

# **[15장: 513 ~ 515페이지]**

# In[ ]:


import json
import datetime
    
# [날짜 및 시간 설정]
now = datetime.datetime.now() # 현재 날짜 및 시간 반환

# baseDate에 날짜를 입력하기 위해 날짜를 출력 형식을 지정해 변수에 할당
date = "{:%Y%m%d}".format(now) 

# baseTime에 시간(정시)를 입력하기 위해 출력 형식을 지정해 시간만 변수에 할당
time = "{:%H00}".format(now)

# 현재 분이 30분 이전이면 이전 시간(정시)을 설정
if (now.minute >= 30):
    time = "{0}00".format(now.hour)
else:
    time = "{0}00".format(now.hour-1)

    
# [요청 주소 및 요청 변수 지정]
req_url = "http://newsky2.kma.go.kr/service/SecndSrtpdFrcstInfoService2/ForecastTimeData"

baseDate = date # 발표 일자 지정
baseTime = time # time  # 발표 시간 지정(정시로 지정)

nx_val = 60 # 예보지점 X 좌표(서울시 종로구 사직동)
ny_val = 127 # 예보지점 Y 좌표(서울시 종로구 사직동)

num_of_rows = 30 # 한 페이지에 포함된 결과 수
page_no = 1 # 페이지 번호

output_type = "json" # 응답 데이터 형식 지정

req_parameter = {"ServiceKey":API_KEY_decode, 
                 "nx":nx_val, "ny": ny_val, 
                 "base_date":baseDate, "base_time":baseTime, 
                 "pageNo":page_no, "numOfRows":num_of_rows, 
                 "_type":output_type}

# [데이터 요청]
r = requests.get(req_url, params = req_parameter)

# [JSON 형태로 응답받은 데이터를 딕셔너리 데이터로 변환]
dict_data = r.json()

# [딕셔너리 데이터를 분석해서 원하는 값 추출]
weather_items = dict_data['response']['body']['items']['item']

sky_cond = ["맑음", "구름 조금", "구름 많음", "흐림"]
rain_type = ["없음", "비", "진눈개비", "눈"] 

print("[ 발표 날짜: {} ]".format(weather_items[0]['baseDate']))
print("[ 발표 시간: {} ]".format(weather_items[0]['baseTime']))

print("[ 초단기 일기 예보 ]")

for k in range(len(weather_items)):
    weather_item = weather_items[k]
    
    fcstTime = weather_item['fcstTime']
    fcstValue = weather_item['fcstValue']
    
    if(weather_item['category'] == 'T1H'):
        print("* 시간: {0}, 기온: {1} 도".format(fcstTime, fcstValue))
    elif(weather_item['category'] == 'REH'):
        print("* 시간: {0}, 습도: {1} 퍼센트".format(fcstTime, fcstValue))
    elif(weather_item['category'] == 'SKY'):
        print("* 시간: {0}, 하늘: {1}".format(fcstTime, sky_cond[fcstValue-1]))
    elif(weather_item['category'] == 'PTY'):
        print("* 시간: {0}, 강수: {1}".format(fcstTime, rain_type[fcstValue]))


# ### 대기 오염 정보 가져오기

# #### 대기 오염 정보를 위한 서비스 신청

# #### 근접 측정소 목록 조회하기

# **[15장: 519페이지]**

# In[ ]:


import requests

API_KEY  = 'YOUR-API-KEY' # 자신의 인증키를 복사해서 입력합니다.
API_KEY_decode = requests.utils.unquote(API_KEY)
API_KEY_decode


# **[15장: 520페이지]**

# In[ ]:


req_url = "http://openapi.airkorea.or.kr/openapi/services/rest/MsrstnInfoInqireSvc/getTMStdrCrdnt"

umd_name = "논현동" #읍, 면, 동 지정
num_of_rows = 10 # 한 페이지에 포함된 결과 수
page_no = 1 # 페이지 번호

output_type = "json"

req_parameter = {"ServiceKey":API_KEY_decode, "umdName":umd_name, 
                  "pageNo":page_no, "numOfRows":num_of_rows, 
                 "_returnType":output_type}

dict_data = requests.get(req_url, params = req_parameter).json()
dict_data['totalCount'] # 전체 결과의 개수


# **[15장: 520 ~ 521페이지]**

# In[ ]:


print("[입력한 읍/면/동명]", umd_name)
print("[TM 기준 좌표 조회 결과]")

for k in range(dict_data['totalCount']):
    sido = dict_data['list'][k]['sidoName']
    sgg = dict_data['list'][k]['sggName']
    umd = dict_data['list'][k]['umdName']
    tmX = dict_data['list'][k]['tmX']
    tmY = dict_data['list'][k]['tmY']
    
    print("- 위치: {0} {1} {2}".format(sido, sgg, umd))
    print("- k = {0}, TM 좌표(X, Y): {1}, {2}\n".format(k, tmX, tmY))


# **[15장: 521페이지]**

# In[ ]:


k = 0 # 원하는 위치 선택 (여기서는 첫 번째 위치)
TM_X = dict_data['list'][k]['tmX'] # TM X 좌표
TM_Y = dict_data['list'][k]['tmY'] # TM Y 좌표
print("TM 좌표(X, Y): {0}, {1}".format(TM_X, TM_Y))


# **[15장: 522 ~ 523페이지]**

# In[ ]:


req_url = "http://openapi.airkorea.or.kr/openapi/services/rest/MsrstnInfoInqireSvc/getNearbyMsrstnList"

x_value = TM_X # TM 측정방식 X좌표
y_value = TM_Y # TM 측정방식 Y좌표

num_of_rows = 10 # 한 페이지에 포함된 결과 수
page_no = 1 # 페이지 번호

output_type = "json"
req_parameter = {"ServiceKey":API_KEY_decode, 
                 "tmX":x_value, "tmY":y_value,
                 "pageNo":page_no, "numOfRows":num_of_rows, 
                 "_returnType":output_type}

dict_data = requests.get(req_url, params = req_parameter).json()

print("해당 지역 근처에 있는 측정소의 개수:", dict_data['totalCount'])


# **[15장: 523페이지]**

# In[ ]:


print("[측정소 정보]")

for k in range(dict_data['totalCount']):
    
    stationName = dict_data['list'][k]['stationName']
    ditance = dict_data['list'][k]['tm']
    addr = dict_data['list'][k]['addr']
    
    print("- 측정소 이름:{0}, 거리:{1}[km]".format(stationName, ditance))
    print("- 측정소 주소:{0} \n".format(addr))


# #### 측정 정보 가져오기

# **[15장: 525페이지]**

# In[ ]:


req_url = "http://openapi.airkorea.or.kr/openapi/services/rest/ArpltnInforInqireSvc/getMsrstnAcctoRltmMesureDnsty"

station_name = "도산대로"
data_term = "DAILY"
num_of_rows = 10
page_no = 1
version = 1.3
output_type = "json"

req_parameter = {"ServiceKey": API_KEY_decode,
                 "stationName": station_name,
                 "dataTerm":data_term, "ver": version,
                 "pageNo": page_no, "numOfRows" : num_of_rows,
                 "_returnType": output_type}

dict_data = requests.get(req_url,  params = req_parameter).json()
dict_data['list'][0]
# dict_data


# **[15장: 527페이지]**

# In[ ]:


dataTime = dict_data['list'][0]['dataTime'] 

so2Grade = dict_data['list'][0]['so2Grade']
coGrade = dict_data['list'][0]['coGrade']
o3Grade = dict_data['list'][0]['o3Grade']
no2Grade = dict_data['list'][0]['no2Grade']

pm10Grade1h = dict_data['list'][0]['pm10Grade1h']
pm25Grade1h = dict_data['list'][0]['pm25Grade1h']
khaiGrade = dict_data['list'][0]['khaiGrade']

print("[측정소({0})에서 측정된 대기 오염 상태]".format(station_name))
print("- 측정 시간:{0}".format(dataTime))

print("- [지수] ", end='')
print("아황산가스:{0}, 일산화탄소:{1}, 오존:{2}, 이산화질소:{3}".
      format(so2Grade, coGrade, o3Grade, no2Grade))

print("- [등급] ", end='')
print("미세 먼지:{0}, 초미세 먼지:{1}, 통합대기환경:{2}".
      format(pm10Grade1h, pm25Grade1h, khaiGrade))


# **[15장: 527 ~ 528페이지]**

# In[ ]:


gradeNum2Str = {"1":"좋음", "2":"보통", "3":"나쁨", "4":"매우나쁨" }

print("[측정소({0})에서 측정된 대기 오염 상태]".format(station_name))
print("- 측정 시간:{0}".format(dataTime))

print("- 아황산가스:{0}, 일산화탄소:{1}, 오존:{2}, 이산화질소:{3}".
          format(gradeNum2Str[so2Grade], gradeNum2Str[coGrade],
                 gradeNum2Str[o3Grade], gradeNum2Str[no2Grade]))

print("- 미세 먼지:{0}, 초미세 먼지:{1}, 통합대기환경:{2}".
          format(gradeNum2Str[pm10Grade1h],gradeNum2Str[pm25Grade1h],
                 gradeNum2Str[khaiGrade]))


# ## 15.5 정리
