# File name: my_module_test1.py

def func(a):
    print("입력 숫자:", a)
    
func(3)
