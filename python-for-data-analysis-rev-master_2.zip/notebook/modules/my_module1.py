# File name: my_module1.py

def func1():
    print("func1 in  my_module1 ")

def func2():
    print("func2 in  my_module1 ")
